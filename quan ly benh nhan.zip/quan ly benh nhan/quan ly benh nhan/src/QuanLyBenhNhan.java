import benhvien.*;

import java.util.Scanner;

public class QuanLyBenhNhan {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);


        // a. Nhap danh sach hoa don, xuat ra man hinh
        System.out.println("Nhap danh sach hoa don: ");
        int n = Integer.parseInt(sc.nextLine());

        // Khai bao mang chua n hoa don
        HoaDon[] ds_hoa_don = new HoaDon[n];

        // Nhap thong tin cho hoa don
        for (int i = 0; i < n; i++) {
            System.out.println("Hoa don thu " + (i + 1) + " ");
            //ds_hoa_don[i] = new HoaDon("ho ten" + i, 12 + i, "av" + i, "ad" + i, "dc" + i, "tr" + i, 20 + i, 25 + i, "tj" + i, "rt" + i, 123 + i);
            ds_hoa_don[i] = new HoaDon("", 0, "", "", "", "", 0, 0, "", "", 0);
            ds_hoa_don[i].input();
        }
        System.out.println("╔═════════════════════════╗");
        System.out.println("║         M E N U         ║");
        System.out.println("╠═════════════════════════╣");
        System.out.println("║ 1. Nhập vào 1 may       ║");
        System.out.println("║ 2. Nhap vao nhieu may   ║");
        System.out.println("║ 3. In danh sách         ║");
        System.out.println("║ 4. In danh sách may da  ║");
        System.out.println("║    su dung tren 5 nam   ║");
        System.out.println("║ 5. Thong ke cac may     ║");
        System.out.println("║ 6. Danh sach may da kiem║");
        System.out.println("║    ke nam 2023          ║");
        System.out.println("║ 7. Sap xep a->z theo SL ║");
        System.out.println("║ 8. Doc data tu duong dan║");
        System.out.println("║ 9. Ghi data vo duong dan║");
        System.out.println("║ 0. Kết thúc             ║");
        System.out.println("╚═════════════════════════╝");
        while (true) {
            System.out.println("------------------------------------------------------------------------------");
            System.out.println("-------------------------------------MENU-------------------------------------");
            System.out.println("1. In danh sach hoa don vua nhap ra man hinh");
            System.out.println("2. Tim kiem hoa don cho khach hang voi so cmt duoc nhap tu ban phim");
            System.out.println("0. Ket thuc chuong trinh");
            System.out.println("------------------------------------------------------------------------------");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("------------------------------------------------------------------------------");
                    // In ra man hinh danh sach hoa don
                    System.out.println("Danh sach hoa don: ");
                    for (HoaDon hoa_don : ds_hoa_don) {
                        hoa_don.output();
                        System.out.println();
                    }
                    break;
                case 2:
                    System.out.println("------------------------------------------------------------------------------");

                    // b. Tim kiem hoa don cho khach voi so chung minh thu duoc nhap tu ban phim
                    // Nhap so chung minh thu
                    System.out.println("So chung minh thu: ");
                    String soChungMinhThu = sc.next();
                    // In ra hoa don
                    System.out.println("Hoa don: ");
                    for (int i = 0; i < n; i++) {
                        if (ds_hoa_don[i].getSoChungMinhThu().equalsIgnoreCase(soChungMinhThu)) {
                            System.out.println("Ho ten: " + ds_hoa_don[i].getHoTen());
                            System.out.println("Ma hoa don: " + ds_hoa_don[i].getMaHoaDon());
                            System.out.println("So tien thanh toan: " + ds_hoa_don[i].getSoTienThanhToan());
                        }
                    }
                    break;
                case 0:
                    System.out.println("------------------------------------------------------------------------------");
                    System.out.println("Ket thuc chuong trinh");
                    break;
                default:
                    System.out.println("------------------------------------------------------------------------------");
                    System.out.println("Lua chon khong dung, vui long chon lai!");
            }
        }
    }
}
