package benhvien;

import java.util.Scanner;

class BenhNhan {
    private String hoTen;
    private int tuoi;
    private String gioiTinh;
    private String diaChi;
    private String soChungMinhThu;


    // Constructor khong co tham so
    public BenhNhan() {

    }


    // Constructor co tham so
    public BenhNhan(String hoTen, int tuoi, String gioiTinh, String diaChi, String soChungMinhThu) {
        this.hoTen = hoTen;
        this.tuoi = tuoi;
        this.gioiTinh = gioiTinh;
        this.diaChi = diaChi;
        this.soChungMinhThu = soChungMinhThu;
    }


    // get/set
    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public int getTuoi() {
        return tuoi;
    }

    public void setTuoi(int tuoi) {
        this.tuoi = tuoi;
    }

    public String getGioiTinh() {
        return gioiTinh;
    }

    public void setGioiTinh(String gioiTinh) {
        this.gioiTinh = gioiTinh;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    public String getSoChungMinhThu() {
        return soChungMinhThu;
    }

    public void setSoChungMinhThu(String soChungMinh) {
        this.soChungMinhThu = soChungMinhThu;
    }


    // Input
    public void input() {

        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap ho ten: ");
        hoTen = sc.next();
        System.out.println("Nhap tuoi: ");
        tuoi = sc.nextInt();
        System.out.println("Nhap gioi tinh: ");
        gioiTinh = sc.next();
        System.out.println("Nhap so chung minh thu: ");
        soChungMinhThu = sc.next();
    }


    // Output
    public void output() {

        System.out.println("Ho ten: " + hoTen);
        System.out.println("Tuoi: " + tuoi);
        System.out.println("Gioi tinh: " + gioiTinh);
        System.out.println("So chung minh thu: " + soChungMinhThu);
    }
}


// Lop hoa don ke thua lop benh nhan
public class HoaDon extends BenhNhan {
    private String maHoaDon;
    private int ngayNhapVien;
    private int ngayRaVien;
    private String chuanDoanBenh;
    private String bacSyDieuTri;
    private double soTienThanhToan;


    // Constructor khong co tham so
    private HoaDon() {

    }


    // Constructor co tham so
    public HoaDon(String hoTen, int tuoi, String gioiTinh, String diaChi, String soChungMinhThu, String maHoaDon, int ngayNhapVien, int ngayRaVien, String chuanDoanBenh, String bacSyDieuTri, double soTienThanhToan) {
        super(hoTen, tuoi, gioiTinh, diaChi, soChungMinhThu);
        this.maHoaDon = maHoaDon;
        this.ngayNhapVien = ngayNhapVien;
        this.ngayRaVien = ngayRaVien;
        this.chuanDoanBenh = chuanDoanBenh;
        this.bacSyDieuTri = bacSyDieuTri;
        this.soTienThanhToan = soTienThanhToan;
    }


    // get/set
    public String getMaHoaDon() {
        return maHoaDon;
    }

    public void setMaHoaDon(String maHoaDon) {
        this.maHoaDon = maHoaDon;
    }

    public int getNgayNhapVien() {
        return ngayNhapVien;
    }

    public void setNgayNhapVien(int ngayNhapVien) {
        this.ngayNhapVien = ngayNhapVien;
    }

    public int getNgayRaVien() {
        return ngayRaVien;
    }

    public void setNgayRaVien(int ngayRaVien) {
        this.ngayRaVien = ngayRaVien;
    }

    public String getChuanDoanBenh() {
        return chuanDoanBenh;
    }

    public void setChuanDoanBenh(String chuanDoanBenh) {
        this.chuanDoanBenh = chuanDoanBenh;
    }

    public String getBacSyDieuTri() {
        return bacSyDieuTri;
    }

    public void setBacSyDieuTri(String bacSyDieuTri) {
        this.bacSyDieuTri = bacSyDieuTri;
    }

    public double getSoTienThanhToan() {
        return soTienThanhToan;
    }

    public void setSoTienThanhToan(double soTienThanhToan) {
        this.soTienThanhToan = soTienThanhToan;
    }


    // Override input
    @Override
    public void input() {
        super.input();

        Scanner sc = new Scanner(System.in);
        System.out.println("Nhap ma hoa don: ");
        maHoaDon = sc.next();
        System.out.println("Nhap chuan doan benh: ");
        chuanDoanBenh = sc.next();
        System.out.println("Bac sy dieu tri: ");
        bacSyDieuTri = sc.next();
        System.out.println("Nhap so tien thanh toan: ");
        soTienThanhToan = sc.nextDouble();
        /*
        // Kiem tra ngay nhap vien va ngay ra vien
        int a = ngayNhapVien;
        int b = ngayRaVien;
        if (b < a) {
            // Du lieu ngay khong dung
            System.out.println("Ngay nhap vien va ra vien khong hop le. Vui long nhap lai ");
            System.out.println("Ngay nhap vien: ");
            a = sc.nextInt();
            System.out.println("Ngay ra vien: ");
            b = sc.nextInt();

         */

        // Kiem tra ngay nhap vien va ngay ra vien
        while (true){
         try {
             System.out.println("Nhap ngay nhap vien: ");
             ngayNhapVien=sc.nextInt();
             System.out.println("Nhap ngay ra vien: ");
             ngayNhapVien=sc.nextInt();
             if(ngayRaVien< ngayNhapVien){
                 throw new IllegalArgumentException("Ngay ra vien khong duoc nho hon ngay nhap vien!");
             }
        }
         catch (Exception e){
             System.out.println("Gap loi: "+e);
             System.out.println("Nhap lai ngay nhap vien va ngay ra vien!");
             System.out.println("Nhap ngay nhap vien: ");
             ngayNhapVien=sc.nextInt();
             System.out.println("Nhap ngay ra vien: ");
             ngayNhapVien=sc.nextInt();
         }
         break;
        }
    }


    // Override output
    @Override
    public void output () {
        super.output();

        System.out.println("Ma hoa don: " + maHoaDon);
        System.out.println("Ngay nhap vien: " + ngayNhapVien);
        System.out.println("Ngay ra vien: " + ngayRaVien);
        System.out.println("Chuan doan benh: " + chuanDoanBenh);
        System.out.println("Bac sy dieu tri: " + bacSyDieuTri);
        System.out.println("So tien thanh toan: " + soTienThanhToan);
    }
}