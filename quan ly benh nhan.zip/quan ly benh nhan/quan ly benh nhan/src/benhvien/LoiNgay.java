package benhvien;
public class LoiNgay extends Exception{
    public LoiNgay (){
        super();
    }
}
