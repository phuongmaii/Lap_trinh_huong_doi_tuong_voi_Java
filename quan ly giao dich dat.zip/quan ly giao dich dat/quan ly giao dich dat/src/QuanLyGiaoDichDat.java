import quanlydat.*;

import java.util.GregorianCalendar;
import java.util.Scanner;

public class QuanLyGiaoDichDat {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // a. Nhap danh sach giao dich, hien thi danh sach gioa dich
        // Nhap danh sach giao dich
        System.out.println("Nhap danh sach giao dich: ");
        int n = Integer.parseInt(sc.nextLine());

        // Khoi tao mang chua n giao dich
        GiaoDichDat[] dsGD = new GiaoDichDat[n];

        // Nhap thong tin cho cac giao dich
        for (int i = 0; i < n; i++) {
            System.out.println("Giao dich thu " + (i + 1) + " ");
            //dsGD[i] = new GiaoDichDat("abc"+i, "12"+i, 1200000000+i, 3000000+i, 'A');
            dsGD[i] = new GiaoDichDat();
            dsGD[i].input();
        }
        while (true) {
            System.out.println("--------------------------------------------------------");
            System.out.println("--------------------------MENU--------------------------");
            System.out.println("1. In danh sach giao dich vua nhap ra man hinh");
            System.out.println("2. In ra cac giao dich > 2 ty");
            System.out.println("0. KEt thuc chuong trinh");
            System.out.println("--------------------------------------------------------");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("--------------------------------------------------------");
                    // In danh sach ra man hinh
                    System.out.println("Danh sach giao dich: ");
                    for (GiaoDichDat giaodich : dsGD) {
                        giaodich.output();
                        System.out.println();
                    }
                    break;
                case 2:
                    System.out.println("--------------------------------------------------------");
                    // b. Xuat ra cac giao dich hon 2 ty
                    System.out.println("Cac giao dich co gia hon 2 ty: ");
                    for (GiaoDichDat giaodich : dsGD) {
                        if (giaodich.tienDat() > 2000000000) {
                            giaodich.output();
                            System.out.println(giaodich.tienDat());
                        }
                    }
                    break;
                case 0:
                    System.out.println("--------------------------------------------------------");
                    System.out.println("Ket thuc chuong trinh");
                    break;
                default:
                    System.out.println("--------------------------------------------------------");
                    System.out.println("Lua chon khong dung, vui long chon lai!");
            }
        }
    }
}