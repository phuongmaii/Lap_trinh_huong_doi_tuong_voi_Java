package quanlydat;

public class LoiNhapGia {
    public LoiNhapGia() {
        super();
    }
}
