package quanlydat;
// DHT

import java.util.Scanner;

class GiaoDich {
    private String maGiaoDich;
    private String ngayGiaoDich;
    private double donGia;
    private double dienTich;


    // Constructor khong tham so
    public GiaoDich() {

    }


    // Constructor co tham so
    public GiaoDich(String maGiaoDich, String ngayGiaoDich, double donGia, int dienTich) {
        this.maGiaoDich = maGiaoDich;
        this.ngayGiaoDich = ngayGiaoDich;
        this.donGia = donGia;
        this.dienTich = dienTich;
    }


    // get/set

    public String getMaGiaoDich() {
        return maGiaoDich;
    }

    public void setMaGiaoDich(String maGiaoDich) {
        this.maGiaoDich = maGiaoDich;
    }

    public String getNgayGiaoDich() {
        return ngayGiaoDich;
    }

    public void setNgayGiaoDich(String ngayGiaoDich) {
        this.ngayGiaoDich = ngayGiaoDich;
    }

    public double getDonGia() {
        return donGia;
    }

    public void setDonGia(double donGia) {
        this.donGia = donGia;
    }

    public double getDienTich() {
        return dienTich;
    }

    public void setDienTich(double dienTich) {
        this.dienTich = dienTich;
    }

    // Input
    public void input() {

        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap ma giao dich: ");
        maGiaoDich = sc.next();
        System.out.println("Nhap ngay giao dich: ");
        ngayGiaoDich = sc.next();
        System.out.println("Nhap dien tich: ");
        dienTich = sc.nextInt();
        // Kiem tra don gia
        while (true) {
            try {
                System.out.println("Nhap don gia: ");
                donGia = sc.nextDouble();
                if (donGia < 0) {
                    throw new IllegalArgumentException("Don gia khong duoc nho hon 0");
                }
            } catch (Exception e) {
                System.out.println("Gap loi: " + e);
                System.out.println("Nhap lai don gia!");
                System.out.println("Nhap don gia: ");
                donGia = sc.nextInt();
            }
            break;
        }
    }


    // Output
    public void output() {

        System.out.println("Ma giao dich: " + maGiaoDich);
        System.out.println("Ngay giao dich: " + ngayGiaoDich);
        System.out.println("Don gia: " + donGia);
        System.out.println("Dien tich: " + dienTich);
    }
}


// Lop giao dich dat ke thua lop giao dich
public class GiaoDichDat extends GiaoDich {
    private char loaiDat;

    // Constructor khong tham so
    public GiaoDichDat() {

    }


    // Constructor co tham so
    public GiaoDichDat(String maGiaoDich, String ngayGiaoDich, int donGia, int dienTich, char loaiDat) {
        super(maGiaoDich, ngayGiaoDich, donGia, dienTich);
        this.loaiDat = loaiDat;
    }


    // get/set


    public char getLoaiDat() {
        return loaiDat;
    }

    public void setLoaiDat(char loaiDat) {
        this.loaiDat = loaiDat;
    }

    // Override input
    @Override
    public void input() {
        super.input();

        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap loai dat: ");
        loaiDat = sc.next().charAt(0);
    }


    // Override ouput
    @Override
    public void output() {
        super.output();

        System.out.println("Loai dat: " + loaiDat);
    }


    // Cong thuc tính tien dat
    public double tienDat() {
        if (loaiDat == 'A') {
            double thanhTien = getDienTich() * getDonGia() * 1.5;
            return thanhTien;
        } else {
            double thanhTien = getDienTich() * getDonGia();
            return thanhTien;
        }
    }
}

