package hoadon;

public class LoiCongTo {
    public LoiCongTo() {
        super();
    }
}
