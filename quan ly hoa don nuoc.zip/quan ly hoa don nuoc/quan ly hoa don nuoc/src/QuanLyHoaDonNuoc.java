import hoadon.*;

import java.util.Scanner;

public class QuanLyHoaDonNuoc {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // a. Nhap danh sach hoa don va hien thi thong tin ve hoa don
        System.out.println("Nhap danh sach hoa don: ");
        int n = Integer.parseInt(sc.nextLine());

        // khai bao mang chua n hoa don
        HoaDon[] ds_hoa_don = new HoaDon[n];

        // Nhap thong tin cho hoa don
        for (int i = 0; i < n; i++) {
            System.out.println("Hoa don thu " + (i + 1) + " ");
            //ds_hoa_don[i] = new HoaDon("acb" + i, "vcb" + i, 12 + i, "a" + i, 32 + i, 12 + i, 6 + i);
            ds_hoa_don[i] = new HoaDon();
            ds_hoa_don[i].input();
        }
        while (true) {
            System.out.println("------------------------------------------------------------------");
            System.out.println("-------------------------------MENU-------------------------------");
            System.out.println("1. In danh sach hoa don vua nhap ra man hinh");
            System.out.println("2. Tim kiem bien lai cho khach hang voi ma khach hang nhap tu ban phim");
            System.out.println("0. Ket thuc chuong trinh");
            System.out.println("------------------------------------------------------------------");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("------------------------------------------------------------------");
                    // In danh sach ra man hinh
                    System.out.println("Danh sach hoa don: ");
                    for (HoaDon hoa_don : ds_hoa_don) {
                        hoa_don.output();
                        System.out.println();
                    }
                    break;
                case 2:
                    System.out.println("------------------------------------------------------------------");

                    // b. Tim kiem bien lai cho khach hang voi ma khach hang nhap tu ban phim
                    // Nhap ma khach hang
                    System.out.println("Ma khach hang: ");
                    String maKhachHang = sc.next();
                    // Tim kiem bien lai
                    System.out.println("Bien lai: ");
                    for (int i = 0; i < n; i++) {
                        if (ds_hoa_don[i].getMaKhachHang().equalsIgnoreCase(maKhachHang)) {
                            System.out.println("Ho ten: " + ds_hoa_don[i].getHoTenChuHo());
                            System.out.println("So tien can thanh toan: " + ds_hoa_don[i].TinhGiaTien() + "VND");
                        }
                    }
                    break;
                case 0:
                    System.out.println("------------------------------------------------------------------");
                    System.out.println("Ket thuc chuong trinh");
                    break;
                default:
                    System.out.println("------------------------------------------------------------------");
                    System.out.println("Lua chon khong dung, vui long chon lai!");
            }
        }
    }
}