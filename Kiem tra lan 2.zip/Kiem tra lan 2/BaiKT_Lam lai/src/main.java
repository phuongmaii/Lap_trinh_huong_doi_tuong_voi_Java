import BaiKT_NguyenThiPhuongMai.MayChu;

import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("so luong may tinh: ");
        int n = Integer.parseInt(sc.nextLine());

        MayChu dsMT[] = new MayChu[n];
        for (int i = 0; i < n; i++) {
            System.out.println("may chu thu " + (i + 1) + " ");
            dsMT[i] = new MayChu("", "", "", 0, 0, "", "");
            dsMT[i].input();
        }

        while (true) {
            System.out.println("---------------------------------MENU---------------------------------");
            System.out.println("1. in ra danh sach cac may theo ten hang san xuat (ten hang nhap tu ban phim)");
            System.out.println("2. in ra danh sach may chu co nam san xuat sau nam 2022");
            System.out.println("3. sap xep danh sach theo thu tu giam dan nam san xuat");
            System.out.println("0. ket thuc chuong trinh");
            System.out.println("----------------------------------------------------------------------");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("in ra danh sach cac may theo ten hang (ten hang nhap tu ban phim)");
                    System.out.println("nhap ten hang: ");
                    String hangSanXuat = sc.next();
                    for (int i = 0; i < n; i++) {
                        if (dsMT[i].getTenHangSanXuat().equals(hangSanXuat)) {
                            dsMT[i].output();
                            System.out.println();
                        }
                    }
                    System.out.println("----------------------------------------------------------------------");
                    break;
                case 2:
                    System.out.println("danh sach may co nam san xuat sau nam 2022");
                    for (int i = 0; i < n; i++) {
                        if (dsMT[i].getNamSanXuat() > 2022) {
                            System.out.println("ma may: " + dsMT[i].getMaMay());
                            System.out.println("ten may: " + dsMT[i].getTenMay());
                            System.out.println("ten hang san xuat: " + dsMT[i].getTenHangSanXuat());
                            System.out.println("so luong: " + dsMT[i].getSoLuong());
                            System.out.println("nam san xuat: " + dsMT[i].getNamSanXuat());
                            System.out.println("loai may chu: " + dsMT[i].getLoaiMayChu());
                            System.out.println("chuc nang: " + dsMT[i].getChucNang());
                        }
                    }
                    System.out.println("----------------------------------------------------------------------");
                    break;
                case 3:
                    System.out.println("danh sach may theo thu tu giam dan cua nam san xuat");
                    for (int i = 0; i < n; i++) {
                        for (int j = i; j < n; j++) {
                            if (dsMT[i].getNamSanXuat() < dsMT[j].getNamSanXuat()) {
                                MayChu tempt = dsMT[i];
                                dsMT[i] = dsMT[j];
                                dsMT[j] = tempt;
                            }
                        }
                        System.out.println("ma may: " + dsMT[i].getMaMay());
                        System.out.println("ten may: " + dsMT[i].getTenMay());
                        System.out.println("ten hang san xuat: " + dsMT[i].getTenHangSanXuat());
                        System.out.println("so luong: " + dsMT[i].getSoLuong());
                        System.out.println("nam san xuat: " + dsMT[i].getNamSanXuat());
                        System.out.println("loai may chu: " + dsMT[i].getLoaiMayChu());
                        System.out.println("chuc nang: " + dsMT[i].getChucNang());
                    }
                    System.out.println("----------------------------------------------------------------------");
                    break;
                case 0:
                    System.out.println("ket thuc chuong trinh!");
                    System.out.println("----------------------------------------------------------------------");
                    break;
                default:
                    System.out.println("lua chon khong dung, vui long chon lai!");

            }
        }
    }
}

