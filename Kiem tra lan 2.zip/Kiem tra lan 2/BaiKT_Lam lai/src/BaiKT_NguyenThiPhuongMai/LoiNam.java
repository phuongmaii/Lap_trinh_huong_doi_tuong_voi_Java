package BaiKT_NguyenThiPhuongMai;

public class LoiNam extends Exception{
    public LoiNam(String message){
        super(message);
    }
}
