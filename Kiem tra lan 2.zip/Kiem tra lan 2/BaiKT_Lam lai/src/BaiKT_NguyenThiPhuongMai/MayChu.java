package BaiKT_NguyenThiPhuongMai;

import java.lang.invoke.StringConcatException;
import java.util.Scanner;

public class MayChu extends ThietBi {
    private String loaiMayChu;
    private String chucNang;

    public String getLoaiMayChu() {
        return loaiMayChu;
    }

    public void setLoaiMayChu(String loaiMayChu) {
        this.loaiMayChu = loaiMayChu;
    }

    public String getChucNang() {
        return chucNang;
    }

    public void setChucNang(String chucNang) {
        this.chucNang = chucNang;
    }

    public MayChu(String maMay, String tenMay, String tenHangSanXuat, int soLuong, int namSanXuat, String loaiMayChu, String chucNang) {
        super(maMay, tenMay, tenHangSanXuat, soLuong, namSanXuat);
        this.loaiMayChu = loaiMayChu;
        this.chucNang = chucNang;
    }

    @Override
    public void input() {
        super.input();
        Scanner sc = new Scanner(System.in);
        System.out.println("loai may chu: ");
        loaiMayChu = sc.next();
        System.out.println("chuc nang: ");
        chucNang = sc.next();
    }

    @Override
    public void output() {
        super.output();
        System.out.println("loai may chu: " + loaiMayChu);
        System.out.println("chuc nang: " + chucNang);
    }
}
