package BaiKT_NguyenThiPhuongMai;

import java.util.Scanner;

class ThietBi {
    private String maMay;
    private String tenMay;
    private String tenHangSanXuat;
    private int soLuong;
    private int namSanXuat;

    public String getMaMay() {
        return maMay;
    }

    public String getTenMay() {
        return tenMay;
    }

    public String getTenHangSanXuat() {
        return tenHangSanXuat;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public int getNamSanXuat() {
        return namSanXuat;
    }

    public void setMaMay(String maMay) {
        this.maMay = maMay;
    }

    public void setTenMay(String tenMay) {
        this.tenMay = tenMay;
    }

    public void setTenHangSanXuat(String tenHangSanXuat) {
        this.tenHangSanXuat = tenHangSanXuat;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public void setNamSanXuat(int namSanXuat) {
        this.namSanXuat = namSanXuat;
    }

    public ThietBi(String maMay, String tenMay, String tenHangSanXuat, int soLuong, int namSanXuat) {
        this.maMay = maMay;
        this.tenMay = tenMay;
        this.tenHangSanXuat = tenHangSanXuat;
        this.soLuong = soLuong;
        this.namSanXuat = namSanXuat;
    }

    public void input() {
        Scanner sc = new Scanner(System.in);
        System.out.println("nhap ma may: ");
        maMay = sc.next();
        System.out.println("nhap ten may : ");
        tenMay = sc.next();
        System.out.println("nhap ten hang san xuat: ");
        tenHangSanXuat = sc.next();
        System.out.println("nhap so luong: ");
        soLuong = sc.nextInt();
        while (true) {
            try {
                System.out.println("nhap nam san xuat: ");
                namSanXuat = sc.nextInt();
                if (namSanXuat > 2024) {
                    throw new IllegalArgumentException("nam san xuat khong duoc lon hon nam hien tai!");
                }
            } catch (Exception e) {
                System.out.println("gap loi: "+e);
                System.out.println("nhap lai nam san xuat!");
                System.out.println("nhap nam san xuat: ");
                namSanXuat = sc.nextInt();
            }
            break;
        }
    }

    public void output() {
        System.out.println("ma may: " + maMay);
        System.out.println("ten may: " + tenMay);
        System.out.println("ten hang san xuat: " + tenHangSanXuat);
        System.out.println("so luong: " + soLuong);
        System.out.println("nam san xuat: " + namSanXuat);
    }
}