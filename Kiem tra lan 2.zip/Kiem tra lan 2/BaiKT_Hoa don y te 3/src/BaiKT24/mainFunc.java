package BaiKT24;
import java.util.Scanner;
public class mainFunc {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        DanhSach dssp = new DanhSach();

        int choice = 0;
        do{
            System.out.println("╔═════════════════════════╗");
            System.out.println("║         M E N U         ║");
            System.out.println("╠═════════════════════════╣");
            System.out.println("║ 1. Nhập vào 1 bn        ║");
            System.out.println("║ 2. In danh sách         ║");
            System.out.println("║ 3. Tim benh nhan theo   ║");
            System.out.println("║    ten bac si           ║");
            System.out.println("║ 4. In BN co BHYT nam    ║");
            System.out.println("║    nam vien tren 5 ngay ║");
            System.out.println("║ 5. Sap xep giam  dan    ║");
            System.out.println("║    theo tuoi            ║");
            System.out.println("║ 0. Kết thúc             ║");
            System.out.println("╚═════════════════════════╝");

            choice = sc.nextInt();
            sc.nextLine();

            switch(choice){
                case 1:
                    dssp.themKhachHang();
                    break;

                case 2:
                    dssp.inDanhSach();
                    break;

                case 3:
                    dssp.timBenhNhanTheoBacSy();
                    break;

                case 4:
                    dssp.coBHYTNamVienTren5Ngay();
                    break;

                case 5:
                    dssp.sapXepGiamDanTheoTuoi();
                    dssp.inDanhSach();
                    break;
                case 0:
                    break;

                default:
                    System.out.println("Khong co lua chon tim thay");
                    break;
            }

        }while(choice != 0);
    }
}
