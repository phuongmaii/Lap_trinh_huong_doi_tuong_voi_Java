package BaiKT24;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;
public class DanhSach {
    private ArrayList<BenhNhan> danhSach;

    public DanhSach(){
        this.danhSach = new ArrayList<BenhNhan>();
    }

    public DanhSach(ArrayList<BenhNhan> danhSach){
        this.danhSach = danhSach;
    }

    public void themKhachHang(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhap ho ten: ");
        String hoTen = sc.nextLine();
        int tuoi;
        while (true) {
            System.out.println("Nhap vao tuoi benh nhan: ");
            try {
                tuoi = Integer.parseInt(sc.nextLine());
                break; // Thoát khỏi vòng lặp nếu nhập đúng định dạng
            } catch (NumberFormatException e) {
                System.out.println("Nhap sai dinh dang tuoi. Vui long nhap lai.");
            }
        }
        System.out.println("Nhap gioi tinh:");
        String gioiTinh = sc.nextLine();
        System.out.println("Nhap vao so CMND: ");
        String CMND = sc.nextLine();

        boolean bhyt = false; // Giá trị mặc định là false
        while (true) {

            System.out.println("Benh nhan co bao hiem y te khong? (Yes/No): ");
            String bhytInput = sc.nextLine().trim().toLowerCase(); // Chuyển đổi sang chữ thường và loại bỏ khoảng trắng
            if (bhytInput.equals("yes")) {
                bhyt = true;
                break; // Thoát khỏi vòng lặp nếu người dùng nhập đúng
            } else if (bhytInput.equals("no")) {
                break; // Thoát khỏi vòng lặp nếu người dùng nhập đúng
            } else {
                System.out.println("Nhap sai! Vui long nhap lai.");
            }
        }

        System.out.println("Nhap vao ma hoa don:");
        String diaChi = sc.nextLine();
        //Thiet lap lai dinh dang nhap vao
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate ngayNhapVien = null, ngayRaVien = null;
        boolean validDate = false;

        do {
            try {
                System.out.println("Nhap vao ngay nhap vien (dd/MM/yyyy): ");
                String ngayNVInput = sc.nextLine();
                ngayNhapVien = LocalDate.parse(ngayNVInput, formatter);

                System.out.println("Nhap ngay ra vien (dd/MM/yyyy): ");
                String ngayRVInput = sc.nextLine();
                ngayRaVien = LocalDate.parse(ngayRVInput, formatter);
                // Phần kiểm soát ngày ra lớn hơn ngày vào
                if (ngayRaVien.isBefore(ngayNhapVien)) {
                    System.out.println("Ngay ra vien phai lon hon ngay nhap vien!");
                } else validDate = true;
            } catch (DateTimeParseException e) {
                System.out.println("Nhap sai dinh dang ngay thang. Dinh dang phai la dd/MM/yyyy. Vui long nhap lai.");
            }
        } while (!validDate);

        System.out.println("Chuan doan benh: ");
        String chuanDoan = sc.nextLine();
        System.out.println("Bac si dieu tri: ");
        String bacSy = sc.nextLine();
        double tien;
        while (true) {
            System.out.println("Nhap vao tien vien phi: ");
            try {
                tien = Double.parseDouble(sc.nextLine());
                break; // Thoát khỏi vòng lặp nếu nhập đúng định dạng
            } catch (NumberFormatException e) {
                System.out.println("Nhap sai dinh dang tien. Vui long nhap lai.");
            }
        }

        BenhNhan n = new HoaDon(hoTen, tuoi, gioiTinh, CMND, bhyt, diaChi, ngayNhapVien, ngayRaVien, chuanDoan, bacSy, tien);
        danhSach.add(n);
    }

    public void inDanhSach(){
        System.out.println("╔═════╦════════════════════╦═════╦══════════╦════════════╦══════════════╦══════════╦══════════════╦════════════╦════════════╦════════════╦════════════╗");
        System.out.printf("║%-5s║%-20s║%-5s║%-10s║%-12s║%-14s║%-10s║%-14s║%-12s║%-12s║%-12s║%-12s║\n", "STT", "Ho Ten", "Tuoi", "Gioi Tinh", "CMND", "BHYT", "Ma Hoa Don", "Ngay Nhap Vien"
                , "Ngay Ra Vien", "Chuan Doan", "Bac Sy", "Vien Phi");
        System.out.println("╠═════╬════════════════════╬═════╬══════════╬════════════╬══════════════╬══════════╬══════════════╬════════════╬════════════╬════════════╬════════════╣");

        for (int i = 0; i < danhSach.size(); i++) {
            BenhNhan sv = danhSach.get(i);
            System.out.printf("║%-5s║%-20s║%-5s║%-10s║%-12s║%-14s║%-10s║%-14s║%-12s║%-12s║%-12s║%-12s║\n", i + 1, sv.getHoTen(), sv.getTuoi(), sv.getGioiTinh(), sv.getCCCD(), sv.isBHYT(),
                    ((HoaDon)sv).getMaHoaDon(), ((HoaDon)sv).getNgayNhapVien(),((HoaDon)sv).getNgayRaVien(), ((HoaDon)sv).getChuanDoan(), ((HoaDon)sv).getBacSyDieuTri(), ((HoaDon)sv).getSoTienThanhToan());
        }
        System.out.println("╚═════╩════════════════════╩═════╩══════════╩════════════╩══════════════╩══════════╩══════════════╩════════════╩════════════╩════════════╩════════════╝");
        System.out.println();
    }
    public void timBenhNhanTheoBacSy(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhap ten Bac Sy kham cho benh nhan can tim kiem: ");
        String timCMND = sc.nextLine();
        for (BenhNhan sv : danhSach) {
            if ( ((HoaDon)sv).getBacSyDieuTri().equals(timCMND) ){
                System.out.printf("║%-20s║%-5s║%-10s║%-12s║%-14s║%-10s║%-14s║%-12s║%-12s║%-12s║%-12s║\n", sv.getHoTen(), sv.getTuoi(), sv.getGioiTinh(), sv.getCCCD(), sv.isBHYT(),
                        ((HoaDon)sv).getMaHoaDon(), ((HoaDon)sv).getNgayNhapVien(),((HoaDon)sv).getNgayRaVien(), ((HoaDon)sv).getChuanDoan(), ((HoaDon)sv).getBacSyDieuTri(), ((HoaDon)sv).getSoTienThanhToan());
            }
        }
    }

    public void coBHYTNamVienTren5Ngay() {
        System.out.println("Danh sach benh nhan co BHYT nam vien duoi 5 ngay");

        for (BenhNhan sv : danhSach) {
            LocalDate ngayNhapVien = ((HoaDon)sv).getNgayNhapVien();
            LocalDate ngayRaVien = ((HoaDon)sv).getNgayRaVien();
            boolean bhyt = sv.isBHYT(); // Sử dụng isBHYT() của đối tượng sv

            // Tính số ngày nằm viện
            long soNgayNamVien = ChronoUnit.DAYS.between(ngayNhapVien, ngayRaVien);

            if (bhyt && soNgayNamVien < 5) {
                System.out.printf("║%-20s║%-5s║%-10s║%-12s║%-14s║%-10s║%-14s║%-12s║%-12s║%-12s║%-12s║\n", sv.getHoTen(), sv.getTuoi(), sv.getGioiTinh(), sv.getCCCD(), sv.isBHYT(),
                        ((HoaDon)sv).getMaHoaDon(), ((HoaDon)sv).getNgayNhapVien(),((HoaDon)sv).getNgayRaVien(), ((HoaDon)sv).getChuanDoan(), ((HoaDon)sv).getBacSyDieuTri(), ((HoaDon)sv).getSoTienThanhToan());
            }
        }
    }

    public void sapXepGiamDanTheoTuoi() {
        System.out.println("Sap xep giam dan theo tuoi cua benh nhan");
        ArrayList<BenhNhan> sortedList = new ArrayList<>(this.danhSach);
        Collections.sort(sortedList, new Comparator<BenhNhan>() {
            @Override
            public int compare(BenhNhan tb1, BenhNhan tb2) {
                if ( tb1.getTuoi() > tb2.getTuoi()) {
                    return -1;
                } else if ( tb1.getTuoi() < tb2.getTuoi()) {
                    return 1;
                } else {
                    return 0;
                }
            }
        });
        this.danhSach = sortedList;
    }
}
