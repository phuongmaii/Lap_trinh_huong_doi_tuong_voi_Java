package BaiKT24;
import java.time.LocalDate;
public class HoaDon extends BenhNhan{
    private String maHoaDon;
    private LocalDate ngayNhapVien;
    private LocalDate ngayRaVien;
    private String chuanDoan;
    private String bacSyDieuTri;
    private Double soTienThanhToan;

    public HoaDon(String hoTen, int tuoi, String gioiTinh, String cCCD, boolean bHYT, String maHoaDon,
                  LocalDate ngayNhapVien, LocalDate ngayRaVien, String chuanDoan, String bacSyDieuTri, Double soTienThanhToan) {
        super(hoTen, tuoi, gioiTinh, cCCD, bHYT);
        this.maHoaDon = maHoaDon;
        this.ngayNhapVien = ngayNhapVien;
        this.ngayRaVien = ngayRaVien;
        this.chuanDoan = chuanDoan;
        this.bacSyDieuTri = bacSyDieuTri;
        this.soTienThanhToan = soTienThanhToan;
    }

    public String getMaHoaDon() {
        return maHoaDon;
    }

    public void setMaHoaDon(String maHoaDon) {
        this.maHoaDon = maHoaDon;
    }

    public LocalDate getNgayNhapVien() {
        return ngayNhapVien;
    }

    public void setNgayNhapVien(LocalDate ngayNhapVien) {
        this.ngayNhapVien = ngayNhapVien;
    }

    public LocalDate getNgayRaVien() {
        return ngayRaVien;
    }

    public void setNgayRaVien(LocalDate ngayRaVien) {
        this.ngayRaVien = ngayRaVien;
    }

    public String getChuanDoan() {
        return chuanDoan;
    }

    public void setChuanDoan(String chuanDoan) {
        this.chuanDoan = chuanDoan;
    }

    public String getBacSyDieuTri() {
        return bacSyDieuTri;
    }

    public void setBacSyDieuTri(String bacSyDieuTri) {
        this.bacSyDieuTri = bacSyDieuTri;
    }

    public Double getSoTienThanhToan() {
        return soTienThanhToan;
    }

    public void setSoTienThanhToan(Double soTienThanhToan) {
        this.soTienThanhToan = soTienThanhToan;
    }

    @Override
    public String toString() {
        return "HoaDon [maHoaDon=" + maHoaDon + ", ngayNhapVien=" + ngayNhapVien + ", ngayRaVien=" + ngayRaVien
                + ", chuanDoan=" + chuanDoan + ", bacSyDieuTri=" + bacSyDieuTri + ", soTienThanhToan=" + soTienThanhToan
                + "]";
    }
}
