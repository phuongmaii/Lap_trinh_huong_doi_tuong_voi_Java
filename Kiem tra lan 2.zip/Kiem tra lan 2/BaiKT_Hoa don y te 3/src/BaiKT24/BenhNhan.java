package BaiKT24;

public class BenhNhan {
    private String hoTen;
    private int tuoi;
    private String gioiTinh;
    private String CCCD;
    private boolean BHYT;

    public BenhNhan(String hoTen, int tuoi, String gioiTinh, String cCCD, boolean bHYT) {
        this.hoTen = hoTen;
        this.tuoi = tuoi;
        this.gioiTinh = gioiTinh;
        CCCD = cCCD;
        BHYT = bHYT;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public int getTuoi() {
        return tuoi;
    }

    public void setTuoi(int tuoi) {
        this.tuoi = tuoi;
    }

    public String getGioiTinh() {
        return gioiTinh;
    }

    public void setGioiTinh(String gioiTinh) {
        this.gioiTinh = gioiTinh;
    }

    public String getCCCD() {
        return CCCD;
    }

    public void setCCCD(String cCCD) {
        CCCD = cCCD;
    }

    public boolean isBHYT() {
        return BHYT;
    }

    public void setBHYT(boolean bHYT) {
        BHYT = bHYT;
    }


    @Override
    public String toString() {
        return "BenhNhan [hoTen=" + hoTen + ", tuoi=" + tuoi + ", gioiTinh=" + gioiTinh + ", CCCD=" + CCCD + ", BHYT="
                + BHYT + "]";
    }


}
