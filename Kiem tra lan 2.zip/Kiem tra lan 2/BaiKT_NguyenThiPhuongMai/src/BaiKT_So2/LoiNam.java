package BaiKT_So2;

public class LoiNam extends Exception{
    public LoiNam (String messege){
        super(messege);
    }
}
