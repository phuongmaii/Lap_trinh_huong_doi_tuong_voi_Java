import BaiKT_So2.*;

import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);


        // Nhap vao danh sach n may tinh
        System.out.println("So luong may tinh: ");
        int n = Integer.parseInt(sc.nextLine());
        // Khoi tao mang chua n may
        MayChu[] dsMT = new MayChu[n];
        // Nhap thong tin cho tung may
        for (int i = 0; i < n; i++) {
            System.out.println("May thu " + (i + 1) + " ");
            dsMT[i] = new MayChu("", "", "", 0, 0, "", "");
            dsMT[i].input();
        }


        while (true) {
            System.out.println("--------------------------------------------------------------------------");
            System.out.println("-----------------------------------MENU-----------------------------------");
            System.out.println("1. In ra danh sach cac may cua hang (Nhap ten hang tu ban phim) ");
            System.out.println("2. Liet ke cac may co nam san xuat sau 2022");
            System.out.println("3. Sap xep theo thu tu giam dan cua nam san xuat");
            System.out.println("0. Ket thuc chuong trinh");
            System.out.println("--------------------------------------------------------------------------");

            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("--------------------------------------------------------------------------");
                    System.out.println("Danh sach cac may cua hang (Nhap ten hang tu ban phim) ");
                    String hangSanXuat = sc.next();
                    for (int i = 0; i < n; i++) {
                        if (dsMT[i].getHangSanXuat().equals(hangSanXuat)) {
                            dsMT[i].output();
                            System.out.println();
                        }
                    }
                    break;
                case 2:
                    System.out.println("--------------------------------------------------------------------------");
                    System.out.println("May co nam san xuat sau 2022");
                    for (int i = 0; i < n; i++) {
                        if (dsMT[i].getNamSanXuat() > 2022) {
                            System.out.println("Ma may: " + dsMT[i].getMaMay());
                            System.out.println("Tan may: " + dsMT[i].getTenMay());
                            System.out.println("Hang san xuat: " + dsMT[i].getHangSanXuat());
                            System.out.println("So luong: " + dsMT[i].getSoLuong());
                            System.out.println("Nam san xuat: " + dsMT[i].getNamSanXuat());
                            System.out.println("Loai may chu: " + dsMT[i].getLoaiMayChu());
                            System.out.println("Chuc nang: " + dsMT[i].getChucNang());
                        }
                    }
                    break;
                case 3:
                    System.out.println("--------------------------------------------------------------------------");
                    System.out.println("Sap xep danh sach thiet bi theo thu tu giam dan nam san xuat");
                    for (int i = 0; i < n; i++) {
                        for (int j = i; j < n; j++) {
                            if (dsMT[i].getNamSanXuat() < dsMT[j].getNamSanXuat()) {
                                /*

                                MayChu mt = dsMT[i];
                                dsMT[i]=dsMT[j];
                                dsMT[j] = mt;

                                 */
                                MayChu tempt = dsMT[i];
                                dsMT[i]=dsMT[j];
                                dsMT[j]=tempt;
                            }
                        }
                                System.out.println("Ma may: " + dsMT[i].getMaMay());
                                System.out.println("Tan may: " + dsMT[i].getTenMay());
                                System.out.println("Hang san xuat: " + dsMT[i].getHangSanXuat());
                                System.out.println("So luong: " + dsMT[i].getSoLuong());
                                System.out.println("Nam san xuat: " + dsMT[i].getNamSanXuat());
                                System.out.println("Loai may chu: " + dsMT[i].getLoaiMayChu());
                                System.out.println("Chuc nang: " + dsMT[i].getChucNang());
                        }
                    break;
                case 0:
                    System.out.println("--------------------------------------------------------------------------");
                    System.out.println("Ket thuc chuong trinh");
                    break;
                default:
                    System.out.println("Lua chon khong dung, vui long chon lai");

            }
        }
    }
}
