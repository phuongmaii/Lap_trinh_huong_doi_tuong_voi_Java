package BaiKT__NguyenThiPhuongMai;

import java.util.Date;
import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("nhap so benh nhan: ");
        int n = Integer.parseInt(sc.nextLine());

        HoaDon dsHD[] = new HoaDon[n];

        for (int i = 0; i < n; i++) {
            System.out.println("hoa don thu " + (i + 1) + " ");
            dsHD[i] = new HoaDon("", 0, "", "", "", "", new Date(), new Date(), "", "", 0);
            dsHD[i].input();
        }

        while (true) {
            System.out.println("------------------------------------MENU------------------------------------");
            System.out.println("1. xuat danh sach hoa don ra man hinh");
            System.out.println("2. tim va in ra danh sach benh nhan kham bs (ten bs nhap tu ban phim)");
            System.out.println("3. in ra danh sach benh nha co BHYT va co ngay nam vien < 5 ngay");
            System.out.println("4. sap xep benh nhan theo giam dan cua tuoi");
            System.out.println("0. ket thuc chuong trinh");
            System.out.println("----------------------------------------------------------------------------");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("xuat danh sach hoa don ra man hinh");
                    for (int i = 0; i < n; i++) {
                        dsHD[i].output();
                        System.out.println();
                    }
                    System.out.println("----------------------------------------------------------------------------");
                    break;
                case 2:
                    System.out.println(" tim va in ra danh sach benh nha kham bs (ten bs nhap tu ban phim)");
                    String bsDieuTri = sc.next();
                    for (int i = 0; i < n; i++) {
                        if (dsHD[i].getBsDieuTri().equals(bsDieuTri)) {
                            System.out.println("ho va ten: " + dsHD[i].getHoTen());
                            System.out.println("tuoi: " + dsHD[i].getTuoi());
                            System.out.println("gioi tinh: " + dsHD[i].getGioiTinh());
                            System.out.println("so CCCD: " + dsHD[i].getSoCCCD());
                            System.out.println("the BHYT: " + dsHD[i].getBHYT());
                            System.out.println("ma hoa don: " + dsHD[i].getMaHoaDon());
                            System.out.println("ngay nhap vien: " + dsHD[i].getNgayNhapVien());
                            System.out.println("ngay ra vien: " + dsHD[i].getNgayRaVien());
                            System.out.println("chuan doan benh: " + dsHD[i].getChuanDoanBenh());
                            System.out.println("bac sy dieu tri: " + dsHD[i].getBsDieuTri());
                            System.out.println("so tien thanh toan: " + dsHD[i].getSoTienThanhToan() + "VND");
                            System.out.println();
                        }
                    }
                    System.out.println("----------------------------------------------------------------------------");
                    break;
                case 3:
                    System.out.println("3. in ra danh sach benh nhan co BHYT va ngay nam vien < 5 ngay");
                    for (int i = 0; i < n; i++) {
                        long soNgayNamVien = (dsHD[i].getNgayRaVien().getTime() - dsHD[i].getNgayNhapVien().getTime()) / (1000 * 60 * 60 * 24);
                        if (dsHD[i].getBHYT().equals("yes") && soNgayNamVien < 5) {
                            System.out.println("ho va ten benh nhan: " + dsHD[i].getHoTen());
                            System.out.println();
                        }
                    }
                    System.out.println("----------------------------------------------------------------------------");
                    break;
                case 4:
                    System.out.println("4. danh sach benh nhan giam dan theo tuoi");
                    for (int i = 0; i < n; i++) {
                        for (int j = i; j < n; j++) {
                            if(dsHD[i].getTuoi()<dsHD[j].getTuoi()) {
                                HoaDon tempt = dsHD[i];
                                dsHD[i] = dsHD[j];
                                dsHD[j] = dsHD[i];
                            }
                        }
                        System.out.println("ho va ten benh nhan: " + dsHD[i].getHoTen());
                        System.out.println("tuoi: " + dsHD[i].getTuoi());
                    }
                    System.out.println("----------------------------------------------------------------------------");
                    break;
                case 0:
                    System.out.println("ket thuc chuong trinh!");
                    System.out.println("----------------------------------------------------------------------------");
                    break;
                default:
                    System.out.println("lua chon khong dung, vui long chon lai!");
                    System.out.println("----------------------------------------------------------------------------");
            }
        }
    }
}