package BaiKT__NguyenThiPhuongMai;

import java.util.Scanner;

public class BenhNhan {
    private String hoTen;
    private int tuoi;
    private String gioiTinh;
    private String soCCCD;
    private String BHYT;

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public int getTuoi() {
        return tuoi;
    }

    public void setTuoi(int tuoi) {
        this.tuoi = tuoi;
    }

    public String getGioiTinh() {
        return gioiTinh;
    }

    public void setGioiTinh(String gioiTinh) {
        this.gioiTinh = gioiTinh;
    }

    public String getSoCCCD() {
        return soCCCD;
    }

    public void setSoCCCD(String soCCCD) {
        this.soCCCD = soCCCD;
    }

    public String getBHYT() {
        return BHYT;
    }

    public void setBHYT(String BHYT) {
        this.BHYT = BHYT;
    }

    public BenhNhan() {

    }

    public BenhNhan(String hoTen, int tuoi, String gioiTinh, String soCCCD, String BHYT) {
        this.hoTen = hoTen;
        this.tuoi = tuoi;
        this.gioiTinh = gioiTinh;
        this.soCCCD = soCCCD;
        this.BHYT = BHYT;
    }

    public void input() {
        Scanner sc = new Scanner(System.in);
        System.out.println("nhap ho va ten: ");
        hoTen=sc.next();
        System.out.println("nhap tuoi: ");
        tuoi=sc.nextInt();
        System.out.println("nhap gioi tinh (nam/nu): ");
        gioiTinh=sc.next();
        System.out.println("nhap so CCCD: ");
        soCCCD=sc.next();
        System.out.println("nhap the BHYT (yes/no): ");
        BHYT=sc.next();
    }

    public void output(){
        System.out.println("ho va ten: " + hoTen);
        System.out.println("tuoi: " + tuoi);
        System.out.println("gioi tinh: " + gioiTinh);
        System.out.println("so CCCD: " + soCCCD);
        System.out.println("the BHYT: " + BHYT);
    }
}
