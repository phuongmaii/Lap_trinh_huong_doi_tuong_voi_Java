package BaiKT__NguyenThiPhuongMai;

import java.time.LocalDate;
import java.util.Date;
import java.util.Scanner;

public class HoaDon extends BenhNhan {
    private String maHoaDon;
    private LocalDate ngayNhapVien;
    private LocalDate ngayRaVien;
    private String chuanDoanBenh;
    private String bsDieuTri;
    private double soTienThanhToan;

    public String getMaHoaDon() {
        return maHoaDon;
    }

    public void setMaHoaDon(String maHoaDon) {
        this.maHoaDon = maHoaDon;
    }

    public Date getNgayNhapVien() {
        return ngayNhapVien;
    }

    public void setNgayNhapVien(Date ngayNhapVien) {
        this.ngayNhapVien = ngayNhapVien;
    }

    public Date getNgayRaVien() {
        return ngayRaVien;
    }

    public void setNgayRaVien(Date ngayRaVien) {
        this.ngayRaVien = ngayRaVien;
    }

    public String getChuanDoanBenh() {
        return chuanDoanBenh;
    }

    public void setChuanDoanBenh(String chuanDoanBenh) {
        this.chuanDoanBenh = chuanDoanBenh;
    }

    public String getBsDieuTri() {
        return bsDieuTri;
    }

    public void setBsDieuTri(String bsDieuTri) {
        this.bsDieuTri = bsDieuTri;
    }

    public double getSoTienThanhToan() {
        return soTienThanhToan;
    }

    public void setSoTienThanhToan(double soTienThanhToan) {
        this.soTienThanhToan = soTienThanhToan;
    }

    public HoaDon() {

    }

    public HoaDon(String hoTen, int tuoi, String gioiTinh, String soCCCD, String BHYT, String maHoaDon, Date ngayNhapVien, Date ngayRaVien, String chuanDoanBenh, String bsDieuTri, double soTienThanhToan) {
        super(hoTen, tuoi, gioiTinh, soCCCD, BHYT);
        this.maHoaDon = maHoaDon;
        this.ngayNhapVien = ngayNhapVien;
        this.ngayRaVien = ngayRaVien;
        this.chuanDoanBenh = chuanDoanBenh;
        this.bsDieuTri = bsDieuTri;
        this.soTienThanhToan = soTienThanhToan;
    }

    @Override
    public void input() {
        super.input();
        Scanner sc = new Scanner(System.in);
        System.out.println("nhap ma hoa don: ");
        maHoaDon = sc.next();
        while (true) {
            try {
                System.out.println("nhap ngay nhap vien (yy/dd/mm): ");
                String ngayNhapVien = sc.next();
                System.out.println("nhap ngay ra vien (yy/dd/mm): ");
                String ngayRaVien = sc.next();
                if (ngayNhapVien.equalsIgnoreCase(ngayRaVien)) {
                    throw new IllegalArgumentException("ngay ra vien phai nho hon ngay nhap vien!");
                }
            } catch (Exception e) {
                System.out.println("gap loi: " + e);
                System.out.println("nhap lai ngay nhap vien va ngay ra vien!");
                System.out.println("nhap ngay nhap vien (yy/dd/mm): ");
                String ngayNhapVien = sc.next();
                System.out.println("nhap ngay ra vien (yy/dd/mm): ");
                String ngayRaVien = sc.next();
            }
            break;
        }
        System.out.println("nhap chuan doan benh: ");
        chuanDoanBenh = sc.next();
        System.out.println("nhap bac sy dieu tri: ");
        bsDieuTri = sc.next();
        System.out.println("nhap so tien thanh toan: ");
        soTienThanhToan = sc.nextDouble();
    }

    @Override
    public void output() {
        super.output();
        System.out.println("ma hoa don: " + maHoaDon);
        System.out.println("ngay nhap vien: " + ngayNhapVien);
        System.out.println("ngay ra vien: " + ngayRaVien);
        System.out.println("chuan doan benh: " + chuanDoanBenh);
        System.out.println("bac sy dieu tri: " + bsDieuTri);
        System.out.println("so tien thanh toan: " + soTienThanhToan);
    }
}
