package BaiKT__NguyenThiPhuongMai;

public class LoiNgay extends Exception {
    LoiNgay(String messeage) {
        super(messeage);
    }
}
