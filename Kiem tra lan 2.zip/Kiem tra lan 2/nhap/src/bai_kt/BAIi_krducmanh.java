package bai_kt;

import java.util.Scanner;

abstract class chuyenxe {
    private String machuyenxe;

    private String tentaixe;

    private String sdt;

    private String soxe;

    public chuyenxe(String machuyenxe, String tentaixe, String sdt, String soxe) {
        this.machuyenxe = machuyenxe;
        this.tentaixe = tentaixe;
        this.sdt = sdt;
        this.soxe = soxe;
    }

    public String getMachuyenxe() {
        return machuyenxe;
    }

    public String getTentaixe() {
        return tentaixe;
    }

    public String getSdt() {
        return sdt;
    }

    public String getSoxe() {
        return soxe;
    }

    public void setMachuyenxe(String machuyenxe) {
        this.machuyenxe = machuyenxe;
    }

    public void setTentaixe(String tentaixe) {
        this.tentaixe = tentaixe;
    }

    public void setSdt(String sdt) {
        this.sdt = sdt;
    }

    public void setSoxe(String soxe) {
        this.soxe = soxe;
    }


    public void input() {
        Scanner sc = new Scanner(System.in);
        System.out.println("mã chuyến xe : ");
        machuyenxe = sc.nextLine();
        System.out.println("nhập tên tài xế : ");
        tentaixe = sc.nextLine();
        System.out.println("số điện thoại : ");
        sdt = sc.nextLine();
        System.out.println("số xe : ");
        soxe = sc.nextLine();
    }

    public void ontput() {
        System.out.println("nhập mã chuyến xe : " + machuyenxe);
        System.out.println("nhập tên tài xế : " + tentaixe);
        System.out.println("nhập số điện thoại : " + sdt);
        System.out.println("nhập số xe : " + soxe);
    }

    public abstract void inPut();

    public abstract void outPut();
}

class noithanh extends chuyenxe {
    private String sotuyen;
    private int sokm;
    private int dongia1km;
    private String diemtrakhach;
    private String diemdonkhach;


    public noithanh(String machuyenxe, String tentaixe, String sdt, String soxe, String sotuyen, int sokm, int dongia1km, String diemtrakhach, String diemdonkhach) {
        super(machuyenxe, tentaixe, sdt, soxe);
        this.sotuyen = sotuyen;
        this.sokm = sokm;
        this.dongia1km = dongia1km;
        this.diemtrakhach = diemtrakhach;
        this.diemdonkhach = diemdonkhach;
    }

    public String getSotuyen() {
        return sotuyen;
    }

    public int getSokm() {
        return sokm;
    }

    public int getDongia1km() {
        return dongia1km;
    }

    public void setSotuyen(String sotuyen) {
        this.sotuyen = sotuyen;
    }

    public void setSokm(int sokm) {
        this.sokm = sokm;
    }

    public void setDongia1km(int dongia1km) {
        this.dongia1km = dongia1km;
    }

    public String getDiemtrakhach() {
        return diemtrakhach;
    }

    public String getDiemdonkhach() {
        return diemdonkhach;
    }

    public void setDiemtrakhach(String diemtrakhach) {
        this.diemtrakhach = diemtrakhach;
    }

    public void setDiemdonkhach(String diemdonkhach) {
        this.diemdonkhach = diemdonkhach;
    }

    @Override
    public void inPut() {
        super.input();
        Scanner sc = new Scanner(System.in);
        System.out.println("nhập số tuyến : ");
        sotuyen = sc.nextLine();
        System.out.println("nhâp số km : ");
        sokm = Integer.parseInt(sc.nextLine());
        System.out.println("nhâp dơn giá 1km : ");
        dongia1km = Integer.parseInt(sc.nextLine());

        System.out.println("nhâp điêm đón kahcsh : ");
        diemdonkhach = sc.nextLine();

        System.out.print("Nhập điểm trả khách: ");
        diemtrakhach = sc.nextLine();
        try {
            kimtradiemtra(); // Kiểm tra nếu điểm trả khách trùng với điểm đón khách
            // Nếu không trùng, thoát khỏi vòng lặp
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println("Vui lòng nhập lại điểm trả khách.");
            System.out.print("Nhập điểm trả khách: ");
            diemtrakhach = sc.nextLine();

        }
    }


    @Override
    public void outPut() {
        super.ontput();
        System.out.println("số tuyến : " + sotuyen);
        System.out.println("số km : " + sokm);
        System.out.println("dơn gái 1km : " + dongia1km);
        System.out.println("điểm đón " + diemdonkhach);
        System.out.println("diểm trả :" + diemtrakhach);

    }

    public double tinhdoanhtgui() {
        if (sokm <= 5) {
            return 50000;
        } else {
            return sokm * dongia1km;
        }
    }


    public void kimtradiemtra() throws Exception {
        if (diemdonkhach.equalsIgnoreCase(diemtrakhach)) {
            throw new Exception("lỗi");

        }
    }


}


public class BAIi_krducmanh {
    public static void main(String[] args) {

        System.out.println("số lượng : ");
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        noithanh[] a = new noithanh[n];

        for (int i = 0; i < n; i++) {
            System.out.println("thông tin :" + (i + 1) + " : ");
            a[i] = new noithanh("", "", "", "", "", 0, 0, "", "");
            a[i].inPut();
        }

        for (int i = 0; i < n; i++) {
            System.out.println("chuyến xe thứ " + (i + 1) + "");
            System.out.println(" doanh thu chuyến xe :" + a[i].tinhdoanhtgui());
            a[i].outPut();
        }

        double sumdoanhthu = 0;
        System.out.println("in ra danh sách những chuyến xe có doanh thu >=1.000.000");
        for (int i = 0; i < n; i++) {
            if (a[i].tinhdoanhtgui() >= 1000000) {
                a[i].outPut();
                System.out.println("doanh thu chuyến xe :" + a[i].tinhdoanhtgui());
            }
            sumdoanhthu += a[i].tinhdoanhtgui();
        }
        System.out.println("tổng doanh thu : " + sumdoanhthu);

        System.out.println("sắp xếp theo thứ tự giảm dần ");
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                if (a[i].getSokm() < a[j].getSokm()) {
                    noithanh temp = a[i];
                    a[i] = a[j];
                    a[j] = temp;
                }
            }

        }
        for (int i = 0; i < n; i++) {
            System.out.println("chuyến xe thứ " + (i + 1) + "");
            a[i].outPut();
        }


    }


}


