import java.util.*;

class BenhNhan {
    private String hoTen;
    private int tuoi;
    private String gioiTinh;
    private String soCCCD;
    private String BHYT;

    public BenhNhan() {
    }

    public BenhNhan(String hoTen, int tuoi, String gioiTinh, String soCCCD, String BHYT) {
        this.hoTen = hoTen;
        this.tuoi = tuoi;
        this.gioiTinh = gioiTinh;
        this.soCCCD = soCCCD;
        this.BHYT = BHYT;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public int getTuoi() {
        return tuoi;
    }

    public void setTuoi(int tuoi) {
        this.tuoi = tuoi;
    }

    public String getGioiTinh() {
        return gioiTinh;
    }

    public void setGioiTinh(String gioiTinh) {
        this.gioiTinh = gioiTinh;
    }

    public String getSoCCCD() {
        return soCCCD;
    }

    public void setSoCCCD(String soCCCD) {
        this.soCCCD = soCCCD;
    }

    public String getBHYT() {
        return BHYT;
    }

    public void setBHYT(String BHYT) {
        this.BHYT = BHYT;
    }

    public void input() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Nhập họ và tên: ");
        hoTen = scanner.nextLine();
        System.out.print("Nhập tuổi: ");
        tuoi = scanner.nextInt();
        scanner.nextLine(); // Đọc bỏ dòng trống
        System.out.print("Nhập giới tính (Nam/Nữ): ");
        gioiTinh = scanner.nextLine();
        System.out.print("Nhập số CCCD: ");
        soCCCD = scanner.nextLine();
        System.out.print("Có BHYT hay không (Yes/No): ");
        BHYT = scanner.nextLine();
    }

    public void output() {
        System.out.println("Họ và tên: " + hoTen);
        System.out.println("Tuổi: " + tuoi);
        System.out.println("Giới tính: " + gioiTinh);
        System.out.println("Số CCCD: " + soCCCD);
        System.out.println("BHYT: " + BHYT);
    }
}

class HoaDon extends BenhNhan {
    private String maHoaDon;
    private Date ngayNhapVien;
    private Date ngayRaVien;
    private String chuanDoanBenh;
    private String bacSyDieuTri;
    private double soTienThanhToan;

    public HoaDon() {
    }

    public HoaDon(String hoTen, int tuoi, String gioiTinh, String soCCCD, String BHYT,
                  String maHoaDon, Date ngayNhapVien, Date ngayRaVien, String chuanDoanBenh,
                  String bacSyDieuTri, double soTienThanhToan) {
        super(hoTen, tuoi, gioiTinh, soCCCD, BHYT);
        this.maHoaDon = maHoaDon;
        this.ngayNhapVien = ngayNhapVien;
        this.ngayRaVien = ngayRaVien;
        this.chuanDoanBenh = chuanDoanBenh;
        this.bacSyDieuTri = bacSyDieuTri;
        this.soTienThanhToan = soTienThanhToan;
    }

    public String getMaHoaDon() {
        return maHoaDon;
    }

    public void setMaHoaDon(String maHoaDon) {
        this.maHoaDon = maHoaDon;
    }

    public Date getNgayNhapVien() {
        return ngayNhapVien;
    }

    public void setNgayNhapVien(Date ngayNhapVien) {
        this.ngayNhapVien = ngayNhapVien;
    }

    public Date getNgayRaVien() {
        return ngayRaVien;
    }

    public void setNgayRaVien(Date ngayRaVien) {
        this.ngayRaVien = ngayRaVien;
    }

    public String getChuanDoanBenh() {
        return chuanDoanBenh;
    }

    public void setChuanDoanBenh(String chuanDoanBenh) {
        this.chuanDoanBenh = chuanDoanBenh;
    }

    public String getBacSyDieuTri() {
        return bacSyDieuTri;
    }

    public void setBacSyDieuTri(String bacSyDieuTri) {
        this.bacSyDieuTri = bacSyDieuTri;
    }

    public double getSoTienThanhToan() {
        return soTienThanhToan;
    }

    public void setSoTienThanhToan(double soTienThanhToan) {
        this.soTienThanhToan = soTienThanhToan;
    }

    @Override
    public void input() {
        super.input();
        Scanner scanner = new Scanner(System.in);
        System.out.print("Nhập mã hoá đơn: ");
        maHoaDon = scanner.nextLine();
        System.out.print("Nhập ngày nhập viện (yyyy-MM-dd): ");
        String ngayNhap = scanner.nextLine();
        System.out.print("Nhập ngày ra viện (yyyy-MM-dd): ");
        String ngayRa = scanner.nextLine();
        while (true) {
            try {
                ngayNhapVien = new Date("yyyy-MM-dd");
                ngayRaVien = new Date("yyyy-MM-dd");
            } catch (Exception e) {
                System.out.println("Ngày không hợp lệ!");
                e.printStackTrace();
            }
            break;
        }
        System.out.print("Nhập chuẩn đoán bệnh: ");
        chuanDoanBenh = scanner.nextLine();
        System.out.print("Nhập tên bác sỹ điều trị: ");
        bacSyDieuTri = scanner.nextLine();
        System.out.print("Nhập số tiền thanh toán: ");
        soTienThanhToan = scanner.nextDouble();
    }

    @Override
    public void output() {
        super.output();
        System.out.println("Mã hoá đơn: " + maHoaDon);
        System.out.println("Ngày nhập viện: " + ngayNhapVien);
        System.out.println("Ngày ra viện: " + ngayRaVien);
        System.out.println("Chuẩn đoán bệnh: " + chuanDoanBenh);
        System.out.println("Bác sỹ điều trị: " + bacSyDieuTri);

    }
}

class LoiNgay extends Exception {
    public LoiNgay(String message) {
        super(message);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("nhap so luong hoa don: ");
        int n = Integer.parseInt(scanner.nextLine());
        ArrayList<HoaDon> danhSachHoaDon = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            System.out.println("Nhập thông tin hoá đơn thứ " + (i + 1) + ":");
            HoaDon hoaDon = new HoaDon();
            try {
                hoaDon.input();
                danhSachHoaDon.add(hoaDon);
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }

        System.out.println("Danh sách hoá đơn:");
        for (HoaDon hoaDon : danhSachHoaDon) {
            hoaDon.output();
            System.out.println("--------------------");
        }

        System.out.print("Nhập tên bác sĩ để tìm kiếm: ");
        String tenBacSy = scanner.nextLine();
        System.out.println("Danh sách bệnh nhân khám bác sĩ " + tenBacSy + ":");
        for (HoaDon hoaDon : danhSachHoaDon) {
            if (hoaDon.getBacSyDieuTri().equalsIgnoreCase(tenBacSy)) {
                hoaDon.output();
                System.out.println("--------------------");
            }
        }

        System.out.println("Danh sách bệnh nhân có BHYT và số ngày nằm viện < 5 ngày:");
        for (HoaDon hoaDon : danhSachHoaDon) {
            long soNgayNamVien = (hoaDon.getNgayRaVien().getTime() - hoaDon.getNgayNhapVien().getTime()) / (1000 * 60 * 60 * 24);
            if (hoaDon.getBHYT().equalsIgnoreCase("Yes") && soNgayNamVien < 5) {
                hoaDon.output();
                System.out.println("--------------------");
            }
        }

        Collections.sort(danhSachHoaDon, new Comparator<HoaDon>() {
            @Override
            public int compare(HoaDon hoaDon1, HoaDon hoaDon2) {
                return hoaDon2.getTuoi() - hoaDon1.getTuoi();
            }
        });

        System.out.println("Danh sách bệnh nhân sau khi sắp xếp theo tuổi giảm dần:");
        for (HoaDon hoaDon : danhSachHoaDon) {
            hoaDon.output();
            System.out.println("--------------------");
        }
    }
}
