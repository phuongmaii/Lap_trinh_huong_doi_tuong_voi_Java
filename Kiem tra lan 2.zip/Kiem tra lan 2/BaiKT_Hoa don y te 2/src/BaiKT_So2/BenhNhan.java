package BaiKT_So2;

import java.util.Scanner;

public class BenhNhan {
    private String hoTen;
    private int tuoi;
    private String gioiTinh;
    private String CCCD;
    private boolean BHYT;

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public int getTuoi() {
        return tuoi;
    }

    public void setTuoi(int tuoi) {
        this.tuoi = tuoi;
    }

    public String getGioiTinh() {
        return gioiTinh;
    }

    public void setGioiTinh(String gioiTinh) {
        this.gioiTinh = gioiTinh;
    }

    public String getCCCD() {
        return CCCD;
    }

    public void setCCCD(String CCCD) {
        this.CCCD = CCCD;
    }

    public boolean isBHYT() {
        return BHYT;
    }

    public void setBHYT(boolean BHYT) {
        this.BHYT = BHYT;
    }

    public BenhNhan() {

    }

    public BenhNhan(String hoTen, int tuoi, String gioiTinh, String CCCD, boolean BHYT) {
        this.hoTen = hoTen;
        this.tuoi = tuoi;
        this.gioiTinh = gioiTinh;
        this.CCCD = CCCD;
        this.BHYT = BHYT;
    }

    public void input() {
        Scanner sc = new Scanner(System.in);
        System.out.println("nhap ho va ten: ");
        hoTen = sc.next();
        System.out.println("nhap tuoi: ");
        tuoi = sc.nextInt();
        System.out.println("nhap gioi tinh: ");
        gioiTinh = sc.next();
        System.out.println("nhap so CCCD: ");
        CCCD = sc.next();
        //System.out.println("benh nhan co bhyt khong (yes/no): ");
        boolean bhyt = false;
        while (true) {
            System.out.println("benh nhan co bhyt khong (yes/no): ");
            var temp = sc.next();
            String bhytInput = temp.trim().toLowerCase();
            if (bhytInput.equals("yes")) {
                bhyt = true;
                break;
            } else if (bhytInput.equals("no")) {
                break;
            } else {
                System.out.println("nhap sai, vui long nhap lai!");
            }
        }
    }

    public void output() {
        System.out.println("ho va ten: " + hoTen);
        System.out.println("tuoi: " + tuoi);
        System.out.println("gioi tinh: " + gioiTinh);
        System.out.println("so CCCD: " + CCCD);
        System.out.println("bao hiem y te: " + BHYT);
    }
}
