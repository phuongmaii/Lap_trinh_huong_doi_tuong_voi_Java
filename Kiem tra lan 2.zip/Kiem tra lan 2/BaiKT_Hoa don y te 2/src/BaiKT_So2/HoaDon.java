package BaiKT_So2;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;


public class HoaDon extends BenhNhan {
    private String maHoaDon;
    private LocalDate ngayNhapVien;
    private LocalDate ngayRaVien;
    private String chuanDoanBenh;
    private String bacSyDieuTri;
    private double soTienThanhToan;

    public String getMaHoaDon() {
        return maHoaDon;
    }

    public void setMaHoaDon(String maHoaDon) {
        this.maHoaDon = maHoaDon;
    }

    public LocalDate getNgayNhapVien() {
        return ngayNhapVien;
    }

    public void setNgayNhapVien(LocalDate ngayNhapVien) {
        this.ngayNhapVien = ngayNhapVien;
    }

    public LocalDate getNgayRaVien() {
        return ngayRaVien;
    }

    public void setNgayRaVien(LocalDate ngayRaVien) {
        this.ngayRaVien = ngayRaVien;
    }

    public String getChuanDoanBenh() {
        return chuanDoanBenh;
    }

    public void setChuanDoanBenh(String chuanDoanBenh) {
        this.chuanDoanBenh = chuanDoanBenh;
    }

    public String getBacSyDieuTri() {
        return bacSyDieuTri;
    }

    public void setBacSyDieuTri(String bacSyDieuTri) {
        this.bacSyDieuTri = bacSyDieuTri;
    }

    public double getSoTienThanhToan() {
        return soTienThanhToan;
    }

    public void setSoTienThanhToan(double soTienThanhToan) {
        this.soTienThanhToan = soTienThanhToan;
    }

    public HoaDon() {

    }

    public HoaDon(String hoTen, int tuoi, String gioiTinh, String CCCD, boolean BHYT, String maHoaDon, LocalDate ngayNhapVien, LocalDate ngayRaVien, String chuanDoanBenh, String bacSyDieuTri, double soTienThanhToan) {
        super(hoTen, tuoi, gioiTinh, CCCD, BHYT);
        this.maHoaDon = maHoaDon;
        this.ngayNhapVien = ngayNhapVien;
        this.ngayRaVien = ngayRaVien;
        this.chuanDoanBenh = chuanDoanBenh;
        this.bacSyDieuTri = bacSyDieuTri;
        this.soTienThanhToan = soTienThanhToan;
    }

    @Override
    public void input() {
        super.input();
        Scanner sc = new Scanner(System.in);
        System.out.println("nhap ma hoa don: ");
        maHoaDon = sc.next();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate ngayNhapVien = null, ngayRaVien = null;
        boolean validDate = false;
        do {
            try {
                System.out.println("nhap vao ngay nhap vien (dd/MM/yyyy): ");
                String ngayNVInput = sc.next();
                ngayNhapVien = LocalDate.parse(ngayNVInput, formatter);

                System.out.println("nhap ngay ra vien (dd/MM/yyyy): ");
                String ngayRVInput = sc.next();
                ngayRaVien = LocalDate.parse(ngayRVInput, formatter);
                // Phần kiểm soát ngày ra lớn hơn ngày vào
                if (ngayRaVien.isBefore(ngayNhapVien)) {
                    System.out.println("ngay ra vien phai lon hon ngay nhap vien!");
                } else validDate = true;
            } catch (DateTimeParseException e) {
                System.out.println("nhap sai dinh dang ngay thang. dinh dang phai la dd/MM/yyyy. vui long nhap lai.");
            }
        } while (!validDate);
        System.out.println("nhap chuan doan benh: ");
        chuanDoanBenh = sc.next();
        System.out.println("nhap bac sy dieu tri: ");
        bacSyDieuTri = sc.next();
        System.out.println("nhap so tien thanh toan: ");
        soTienThanhToan = sc.nextDouble();
    }

    @Override
    public void output() {
        super.output();
        System.out.println("ma hoa don: " + maHoaDon);
        System.out.println("ngay nhap vien: " + ngayNhapVien);
        System.out.println("ngay ra vien: " + ngayRaVien);
        System.out.println("bac sy dieu tri: " + bacSyDieuTri);
        System.out.println("so tien thanh toan: " + soTienThanhToan);
    }

}
