package BaiKT_So2;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // khai bao so luong hoa don
        System.out.println("so luong hoa don: ");
        int n = Integer.parseInt(sc.nextLine());
        // khoi tao mang chua n hoa don
        HoaDon[] dsHD = new HoaDon[n];
        // nhap du lieu
        for (int i = 0; i < n; i++) {
            System.out.println("hoa don thu " + (i + 1) + " ");

            LocalDate nnv = LocalDate.now();
            // khai bao/gan gia tri

            dsHD[i] = new HoaDon("", 0, "", "", false, "", nnv, null, "", "", 0);
            //dsHD[i] = new HoaDon();
            dsHD[i].input();
        }

        // yeu cau de bai
        while (true) {
            System.out.println("--------------------------------------MENU--------------------------------------");
            System.out.println("1. in danh sach hoa don vua nhap ra man hinh");
            System.out.println("2. in ra danh sach benh nhan kham theo ten bac sy (ten bac sy nhap tu ban phim)");
            System.out.println("3. in ra danh sach benh nhan co bhyt va nam vien < 5 ngay");
            System.out.println("4. sap xep danh sach benh nhan theo chieu giam dan cua tuoi");
            System.out.println("0. ket thuc chuong trinh");
            System.out.println("--------------------------------------------------------------------------------");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("in danh sach hoa don");
                    for (int i = 0; i < n; i++) {
                        dsHD[i].output();
                        System.out.println();
                    }
                    System.out.println("--------------------------------------------------------------------------------");
                    break;
                case 2:
                    System.out.println("danh sach benh nhan kham theo ten bac sy (ten bac sy nhap tu ban phim)");
                    String tenBSy = sc.next();
                    for (int i = 0; i < n; i++) {
                        if (dsHD[i].getBacSyDieuTri().equals(tenBSy)) {
                            System.out.println("ho ten benh nhan: " + dsHD[i].getHoTen());
                            System.out.println("tuoi: " + dsHD[i].getTuoi());
                            System.out.println("so CCCD: " + dsHD[i].getCCCD());
                            System.out.println();
                        }
                    }
                    System.out.println("--------------------------------------------------------------------------------");
                    break;
                case 3:
                    System.out.println("danh sach benh nhan co bhyt va nam vien < 5 ngay");
                    for (int i = 0; i < n; i++) {
                        boolean bhyt = dsHD[i].isBHYT();
                        LocalDate ngayNhapVien = dsHD[i].getNgayNhapVien();
                        LocalDate ngayRaVien = dsHD[i].getNgayRaVien();
                        long soNgayNamVien = ChronoUnit.DAYS.between(ngayNhapVien, ngayRaVien);
                        if (bhyt && soNgayNamVien < 5) {
                            System.out.println("ho ten benh nhan: " + dsHD[i].getHoTen());
                            System.out.println("tuoi: " + dsHD[i].getTuoi());
                            System.out.println("so CCCD: " + dsHD[i].getCCCD());
                            System.out.println();
                        }
                    }
                    System.out.println("--------------------------------------------------------------------------------");
                    break;
                case 4:
                    System.out.println("danh sach benh nhan theo thu tu giam dan tuoi");
                    for (int i = 0; i < n; i++) {
                        for (int j = i; j < n; j++) {
                            if (dsHD[i].getTuoi() < dsHD[j].getTuoi()) {
                                HoaDon tempt = dsHD[i];
                                dsHD[i] = dsHD[j];
                                dsHD[j] = tempt;
                            }
                        }
                        System.out.println("ho ten benh nhan: " + dsHD[i].getHoTen());
                        System.out.println("tuoi: " + dsHD[i].getTuoi());
                        System.out.println("so CCCD: " + dsHD[i].getCCCD());
                    }
                    System.out.println("--------------------------------------------------------------------------------");
                    break;
                case 0:
                    System.out.println("ket thuc chuong trinh!");
                    System.out.println("--------------------------------------------------------------------------------");
                    break;
                default:
                    System.out.println("lua chon khong dung, vui long chon lai!");
            }
        }
    }
}
