import BaiKT_NguyenThiPhuongMai.NoiThanh;
// bắt lỗi ngoại lệ
import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("nhap so chuyen xe: ");
        int n = Integer.parseInt(sc.nextLine());

        NoiThanh dsQuanLy[] = new NoiThanh[n];

        for (int i = 0; i < n; i++) {
            System.out.println("chuyen xe noi thanh thu " + (i + 1) + " ");
            dsQuanLy[i] = new NoiThanh("", "", 0, 0, "", "", "", 0, 0);
            dsQuanLy[i].input();
        }

        while (true) {
            System.out.println("-----------------------------------MENU-----------------------------------");
            System.out.println("1. danh sach cac chuyen xe noi thanh");
            System.out.println("2. tong doanh thu cac chuyen xe noi thanh");
            System.out.println("3. danh sach cac chuyen co doanh thu >= 1.000.000d");
            System.out.println("4. danh sach xe theo thu tu giam dan so km di duoc");
            System.out.println("0. ket thuc chuong trinh");
            System.out.println("--------------------------------------------------------------------------");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("danh sach cac chuyen xe noi thanh");
                    for (int i = 0; i < n; i++) {
                        dsQuanLy[i].output();
                        System.out.println();
                    }
                    System.out.println("--------------------------------------------------------------------------");
                    break;
                case 2:
                    double tong = 0;
                    for (int i = 0; i < n; i++) {
                        if (dsQuanLy[i] instanceof NoiThanh) {
                            tong += ((NoiThanh) (dsQuanLy[i])).tongDoanhThu();
                        }
                    }
                    System.out.println("tong doanh thu cac chuyen xe noi thanh " + tong + "VND");
                    System.out.println("--------------------------------------------------------------------------");
                    break;
                case 3:
                    System.out.println("cac chuyen xe co tong doanh thu >= 1.000.000.000d");
                    for (int i = 0; i < n; i++) {
                        if (dsQuanLy[i].tongDoanhThu() > 1000000 || dsQuanLy[i].tongDoanhThu() == 1000000) {
                            System.out.println("ma so chuyen: " + dsQuanLy[i].getMaSoChuyen());
                            System.out.println("ho ten tai xe: " + dsQuanLy[i].getHoTenTaiXe());
                            System.out.println("so dien thoai: " + dsQuanLy[i].getSoDienThoai());
                            System.out.println("so xe: " + dsQuanLy[i].getSoXe());
                            System.out.println("diem don: " + dsQuanLy[i].getDiemDon());
                            System.out.println("diem tra: " + dsQuanLy[i].getDiemTra());
                            System.out.println("so tuyen: " + dsQuanLy[i].getSoTuyen());
                            System.out.println("so km di duoc: " + dsQuanLy[i].getSoKmDiDuoc());
                            System.out.println("don gia 1 km: " + dsQuanLy[i].getDonGia1Km());
                            System.out.println();
                        } else {
                            System.out.println("khong co chuyen xe nao co gia >= 1.000.000 VND");
                        }
                    }
                    System.out.println("--------------------------------------------------------------------------");
                    break;
                case 4:
                    System.out.println("danh sach xe xep theo thu tu giam dan km di duoc");
                    for (int i = 0; i < n; i++) {
                        for (int j = i; j < n; j++) {
                            if (dsQuanLy[i].getSoKmDiDuoc() < dsQuanLy[j].getSoKmDiDuoc()) {
                                NoiThanh tempt = dsQuanLy[i];
                                dsQuanLy[i] = dsQuanLy[j];
                                dsQuanLy[j] = tempt;
                            }
                        }
                        System.out.println("ma so chuyen: " + dsQuanLy[i].getMaSoChuyen());
                        System.out.println("ho ten tai xe: " + dsQuanLy[i].getHoTenTaiXe());
                        System.out.println("so dien thoai: " + dsQuanLy[i].getSoDienThoai());
                        System.out.println("so xe: " + dsQuanLy[i].getSoXe());
                        System.out.println("diem don: " + dsQuanLy[i].getDiemDon());
                        System.out.println("diem tra: " + dsQuanLy[i].getDiemTra());
                        System.out.println("so tuyen: " + dsQuanLy[i].getSoTuyen());
                        System.out.println("so km di duoc: " + dsQuanLy[i].getSoKmDiDuoc());
                        System.out.println("don gia 1 km: " + dsQuanLy[i].getDonGia1Km());
                        System.out.println();
                    }
                    System.out.println("--------------------------------------------------------------------------");
                    break;
                case 0:
                    System.out.println("ket thuc chuong trinh!");
                    System.out.println("--------------------------------------------------------------------------");
                    System.out.println();
                    break;
                default:
                    System.out.println("lua chon khong dung, vui long chon lai!");
            }
        }
    }
}
