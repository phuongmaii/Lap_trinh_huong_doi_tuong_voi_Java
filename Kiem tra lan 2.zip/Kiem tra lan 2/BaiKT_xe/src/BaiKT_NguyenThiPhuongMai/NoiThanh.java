package BaiKT_NguyenThiPhuongMai;

import java.util.Scanner;

public class NoiThanh extends ChuyenXe {
    private String soTuyen;
    private double soKmDiDuoc;
    private double donGia1Km;

    public String getSoTuyen() {
        return soTuyen;
    }

    public void setSoTuyen(String soTuyen) {
        this.soTuyen = soTuyen;
    }

    public double getSoKmDiDuoc() {
        return soKmDiDuoc;
    }

    public void setSoKmDiDuoc(double soKmDiDuoc) {
        this.soKmDiDuoc = soKmDiDuoc;
    }

    public double getDonGia1Km() {
        return donGia1Km;
    }

    public void setDonGia1Km(double donGia1Km) {
        this.donGia1Km = donGia1Km;
    }

    public NoiThanh(String maSoChuyen, String hoTenTaiXe, int soDienThoai, int soXe, String diemDon, String diemTra, String soTuyen, double soKmDiDuoc, double donGia1Km) {
        super(maSoChuyen, hoTenTaiXe, soDienThoai, soXe, diemDon, diemTra);
        this.soTuyen = soTuyen;
        this.soKmDiDuoc = soKmDiDuoc;
        this.donGia1Km = donGia1Km;
    }

    @Override
    public void input() {
        super.input();
        Scanner sc = new Scanner(System.in);
        System.out.println("nhap so tuyen: ");
        soTuyen = sc.next();
        System.out.println("nhap so km di duoc: ");
        soKmDiDuoc = sc.nextDouble();
        System.out.println("nhap don gia 1 km: ");
        donGia1Km = sc.nextDouble();
    }

    @Override
    public void output() {
        super.output();
        System.out.println("so tuyen: " + soTuyen);
        System.out.println("so km di duoc: " + soKmDiDuoc);
        System.out.println("don gia 1 km: " + donGia1Km);
    }

    public double tongDoanhThu() {
        double giaTien =0;
        if (soKmDiDuoc < 5 || soKmDiDuoc == 5) {
            giaTien = 50000;
        } else
            giaTien = soKmDiDuoc * donGia1Km;
        return giaTien;
    }
}
