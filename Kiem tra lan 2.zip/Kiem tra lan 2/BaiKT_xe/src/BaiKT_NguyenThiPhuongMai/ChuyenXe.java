package BaiKT_NguyenThiPhuongMai;

import java.util.Scanner;

public class ChuyenXe {
    private String maSoChuyen;
    private String hoTenTaiXe;
    private int soDienThoai;
    private int soXe;
    public String diemDon;
    public String diemTra;

    public String getMaSoChuyen() {
        return maSoChuyen;
    }

    public void setMaSoChuyen(String maSoChuyen) {
        this.maSoChuyen = maSoChuyen;
    }

    public String getHoTenTaiXe() {
        return hoTenTaiXe;
    }

    public void setHoTenTaiXe(String hoTenTaiXe) {
        this.hoTenTaiXe = hoTenTaiXe;
    }

    public int getSoDienThoai() {
        return soDienThoai;
    }

    public void setSoDienThoai(int soDienThoai) {
        this.soDienThoai = soDienThoai;
    }

    public int getSoXe() {
        return soXe;
    }

    public void setSoXe(int soXe) {
        this.soXe = soXe;
    }

    public String getDiemDon() {
        return diemDon;
    }

    public void setDiemDon(String diemDon) {
        this.diemDon = diemDon;
    }

    public String getDiemTra() {
        return diemTra;
    }

    public void setDiemTra(String diemTra) {
        this.diemTra = diemTra;
    }

    public ChuyenXe(String maSoChuyen, String hoTenTaiXe, int soDienThoai, int soXe, String diemDon, String diemTra) {
        this.maSoChuyen = maSoChuyen;
        this.hoTenTaiXe = hoTenTaiXe;
        this.soDienThoai = soDienThoai;
        this.soXe = soXe;
        this.diemDon = diemDon;
        this.diemTra = diemTra;
    }

    public void input() {
        Scanner sc = new Scanner(System.in);
        System.out.println("nhap ma so chuyen: ");
        maSoChuyen = sc.next();
        System.out.println("nhap ho ten tai xe: ");
        hoTenTaiXe = sc.next();
        System.out.println("nhap so dien thoai: ");
        soDienThoai = sc.nextInt();
        System.out.println("nhap so xe: ");
        soXe = sc.nextInt();
        /*
        System.out.println("nhap diem don: ");
        diemDon = sc.next();
        System.out.println("nhap diem tra: ");
        diemTra = sc.next();
        while (true) {
            try {
                kimtradiemtra(); // Kiểm tra nếu điểm trả khách trùng với điểm đón khách
                // Nếu không trùng, thoát khỏi vòng lặp
            } catch (Exception e) {
                System.out.println("Gap loi: "+e);
                System.out.println("Vui lòng nhập lại điểm trả khách.");
                System.out.print("Nhập điểm trả khách: ");
                diemTra = sc.nextLine();
            }
            try {
                System.out.println("nhap diem don: ");
                diemDon = sc.next();
                System.out.println("nhap diem tra: ");
                diemTra = sc.next();
            } catch (Exception e) {
                System.out.println("gap loi: " + e);
                System.out.println("nhap lai diem tra khach!");
                System.out.println("nhap diem tra khach: ");
                diemTra = sc.next();
            }
            break;
             */
        while (true) {
            try {
                System.out.println("nhap diem don: ");
                diemDon = sc.next();
                System.out.println("nhap diem tra: ");
                diemTra = sc.next();
                if (diemDon.equalsIgnoreCase(diemTra)) {
                    throw new IllegalArgumentException("diem don va tra khach khong duoc trung nhau!");
                }
            } catch (Exception e) {
                System.out.println("gap loi: " + e);
                System.out.println("nhap lai diem tra khach!");
                System.out.println("nhap diem tra: ");
                diemTra = sc.next();
            }
            break;
        }
    }

    public void output() {
        System.out.println("ma so chuyen: " + maSoChuyen);
        System.out.println("ho ten tai xe: " + hoTenTaiXe);
        System.out.println("so dien thoai: " + soDienThoai);
        System.out.println("so xe: " + soXe);
        System.out.println("diem don: " + diemDon);
        System.out.println("diem tra: " + diemTra);
    }

        /*
    public class LoiDiemTraKhach extends Exception {
        public void KiemTraDiemTra() throws LoiDiemTraKhach {
            Scanner sc = new Scanner(System.in);
            while (true) {
                try {
                    System.out.println("nhap diem don: ");
                    diemDon = sc.next();
                    System.out.println("nhap diem tra: ");
                    diemTra = sc.next();
                    if (diemDon.equalsIgnoreCase(diemTra)) {
                        throw new IllegalArgumentException("diem don va tra khach khong duoc trung nhau!");
                    }
                } catch (Exception e) {
                    System.out.println("gap loi: " + e);
                    System.out.println("nhap lai diem tra khach!");
                    System.out.println("nhap diem tra khach: ");
                    diemTra = sc.next();
                }
            }
        }

         */
}