package BaiKT_NguyenThiPhuongMai;

public class LoiDiemTraKhach extends Exception {
    public LoiDiemTraKhach (String message){
        super(message);
    }
}
