
import java.util.Scanner;
import java.util.Arrays;

public class bai_1i {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Khai báo biến
        int i = 0;
        int n;


        // Nhập vào số phần tử của mảng
        System.out.println("Nhập vào số phần tử của mảng: ");

        n = sc.nextInt();


        // Khai báo mảng chứa n phần tử
        double[] a = new double[n];


        // Nhập dãy số
        System.out.println("Nhập vào các số thực của dãy");
        for (i = 0; i < n; i++) {
            System.out.println("Nhập vào phần tử thứ " + (i + 1) + ": ");
            a[i] = sc.nextDouble();
        }


        // Tìm các số có tổng bằng 2 số khác trong dãy
        double[] ket_qua = new double[n];
        for (i = 0; i < n; i++) {
            double tong = a[i];
            // Giả sử tổng = b + c, thử từng giá trị trong mảng để gán cho b và c
            for (int j = 0; j < n; j++) {
                if (j != i) {
                    double b = a[j];
                    // Tìm xem c có trong mảng hay không
                    for (int k = 0; k < n; k++) {
                        if (k != j && k != i) {
                            double c = a[k];
                            if (tong == b + c) {
                                // Lưu lại a[i]
                                ket_qua[i] = 1;
                            }
                        }
                    }
                }
            }
        }
        // In kết quả
        System.out.println("Kết quả theo yêu cầu đề bài: ");
        for (i = 0; i < n; i++) {
            if (ket_qua[i] == 1)
                System.out.println(a[i] + " ");
        }
    }
}
