import java.util.Scanner;
// xem lại phần tinh trung bình cộng

public class bai_2b {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Nhập vào số lượng phần tử của dãy
        System.out.print("Nhập số lượng phần tử của dãy: ");
        int n = sc.nextInt();

        int[] array = new int[n];

        // Nhập vào dãy số nguyên
        System.out.println("Nhập vào dãy số nguyên:");
        for (int i = 0; i < n; i++) {
            array[i] = sc.nextInt();
        }

        // Tính trung bình cộng các số chẵn và đếm số lượng số lẻ
        int sumEven = 0;
        int countOdd = 0;

        for (int i = 0; i < n; i++) {
            if (array[i] % 2 == 0) {
                sumEven += array[i];
            } else {
                countOdd++;
            }
        }

        // Tính trung bình cộng các số chẵn
        double averageEven = 0;
        if (n > 0) {
            averageEven = (double) sumEven / n;
        }

        System.out.println("Trung bình cộng các số chẵn: " + averageEven);
        System.out.println("Số lượng các số lẻ: " + countOdd);

    }
}
