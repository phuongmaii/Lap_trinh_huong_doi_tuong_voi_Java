import java.util.Scanner;

public class bai_2d {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Nhập vào số lượng phần tử của dãy
        System.out.print("Nhập số lượng phần tử của dãy: ");
        int n = sc.nextInt();

        int[] array = new int[n];

        // Nhập vào dãy số nguyên
        System.out.println("Nhập vào dãy số nguyên:");
        for (int i = 0; i < n; i++) {
            array[i] = sc.nextInt();
        }

        // Kiểm tra xem trong dãy có cấp số cộng hay không
        boolean found = false;
        for (int i = 0; i < n - 2; i++) {
            if (array[i + 2] - array[i + 1] == array[i + 1] - array[i]) {
                found = true;
                System.out.println("Cấp số cộng: " + array[i] + ", " + array[i + 1] + ", " + array[i + 2]);
                break;
            }
        }

        if (!found) {
            System.out.println("Không tìm thấy cấp số cộng trong dãy.");
        }

    }
}