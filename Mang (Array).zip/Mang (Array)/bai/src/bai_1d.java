import java.util.Scanner;

public class bai_1d {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Khai báo biến
        int n;
        int i;
        int so_luong_so_am = 0;


        // Nhập số các phẩn tử của mảng
        System.out.println("Nhập số phần tử của dãy: ");
        n = sc.nextInt();


        // Khai báo mảng lưu trữ n phần tử của mảng
        double[] a = new double[n];


        // Nhập dãy số
        System.out.println("Nhập vào các số thực của dãy ");
        for (i = 0; i < n; i++) {
            System.out.println("Phần tử thứ" + (i + 1) + ": ");
            a[i] = sc.nextDouble();
        }
        // Đếm và in các số lượng số âm trong dãy
        for (i = 0; i < n; i++) {
            if (a[i] < 0) {
                so_luong_so_am++;
            }
        }


        // Hiển thị kết quả
        System.out.println("Số lượng các số âm trong dãy: " + so_luong_so_am);
    }
}
