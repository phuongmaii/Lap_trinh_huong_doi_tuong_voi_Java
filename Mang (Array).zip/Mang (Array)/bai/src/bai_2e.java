import java.util.Arrays;
import java.util.Scanner;

public class bai_2e {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Nhập vào số lượng phần tử của dãy
        System.out.print("Nhập số lượng phần tử của dãy: ");
        int n = sc.nextInt();

        int[] array = new int[n];

        // Nhập vào dãy số nguyên
        System.out.println("Nhập vào dãy số nguyên:");
        for (int i = 0; i < n; i++) {
            array[i] = sc.nextInt();
        }

        // Kiểm tra xem dãy đã được sắp xếp chưa
        boolean isSorted = true;
        boolean isIncreasing = true;

        for (int i = 0; i < n - 1; i++) {
            if (array[i] > array[i + 1]) {
                isIncreasing = false;
            }

            if (array[i] != array[i + 1]) {
                isSorted = false;
            }
        }

        if (isSorted) {
            if (isIncreasing) {
                System.out.println("Dãy đã được sắp xếp tăng dần.");
            } else {
                System.out.println("Dãy đã được sắp xếp giảm dần.");
            }
        } else {
            // Sắp xếp lại dãy theo thứ tự tăng dần
            Arrays.sort(array);
            System.out.println("Dãy sau khi được sắp xếp tăng dần:");
            for (int i = 0; i < n; i++) {
                System.out.print(array[i] + " ");
            }
            System.out.println();
        }

    }
}