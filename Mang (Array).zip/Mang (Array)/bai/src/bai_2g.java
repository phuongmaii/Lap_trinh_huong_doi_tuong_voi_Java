import java.util.Scanner;

public class bai_2g {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Nhập vào số lượng phần tử của dãy
        System.out.print("Nhập số lượng phần tử của dãy: ");
        int n = sc.nextInt();

        int[] array = new int[n];

        // Nhập vào dãy số nguyên
        System.out.println("Nhập vào dãy số nguyên:");
        for (int i = 0; i < n; i++) {
            array[i] = sc.nextInt();
        }

        // Tìm giá trị chẵn nhỏ nhất và giá trị âm lớn nhất
        int minEven = Integer.MAX_VALUE;
        int maxNegative = Integer.MIN_VALUE;

        for (int i = 0; i < n; i++) {
            if (array[i] % 2 == 0 && array[i] < minEven) {
                minEven = array[i];
            }
            if (array[i] < 0 && array[i] > maxNegative) {
                maxNegative = array[i];
            }
        }

        if (minEven == Integer.MAX_VALUE) {
            System.out.println("Không có số chẵn trong dãy.");
        } else {
            System.out.println("Giá trị chẵn nhỏ nhất trong dãy: " + minEven);
        }

        if (maxNegative == Integer.MIN_VALUE) {
            System.out.println("Không có số âm trong dãy.");
        } else {
            System.out.println("Giá trị âm lớn nhất trong dãy: " + maxNegative);
        }

    }
}