import java.util.*;

public class bai_4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Nhập vào số lượng phần tử của dãy
        System.out.print("Nhập số lượng phần tử của dãy: ");
        int n = sc.nextInt();

        // Khởi tạo mảng
        int[] array = new int[n];

        // Nhập vào dãy số nguyên theo thứ tự tăng
        System.out.println("Nhập vào dãy số nguyên theo thứ tự tăng:");
        for (int i = 0; i < n; i++) {
            if (i == 0) {
                // Nhập phần tử đầu tiên
                System.out.print("Nhập số thứ " + (i + 1) + ": ");
                array[i] = sc.nextInt();
            } else {
                // Nhập các phần tử tiếp theo, kiểm tra điều kiện thứ tự tăng
                do {
                    System.out.print("Nhập số thứ " + (i + 1) + " (lớn hơn " + array[i - 1] + "): ");
                    array[i] = sc.nextInt();
                } while (array[i] <= array[i - 1]);
            }
        }

        // In dãy số đã nhập
        System.out.println("Dãy số sau khi đã nhập xong:");
        printArray(array);

        // Nhập vào số mới
        System.out.print("Nhập vào số mới: ");
        int newNumber = sc.nextInt();

        // Tìm vị trí chèn số mới vào dãy sao cho vẫn đảm bảo thứ tự tăng
        int insertIndex = 0;
        while (insertIndex < n && array[insertIndex] < newNumber) {
            insertIndex++;
        }

        // Chèn số mới vào dãy
        int[] newArray = new int[n + 1];
        for (int i = 0, j = 0; i < n + 1; i++) {
            if (i == insertIndex) {
                newArray[i] = newNumber;
            } else {
                newArray[i] = array[j++];
            }
        }

        // In lại dãy số để kiểm tra
        System.out.println("Dãy số sau khi đã chèn số mới:");
        printArray(newArray);

    }

    // Phương thức in ra dãy số
    private static void printArray(int[] array) {
        for (int num : array) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}