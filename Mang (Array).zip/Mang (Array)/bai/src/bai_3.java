import java.util.*;

public class bai_3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Nhập vào số lượng phần tử của dãy
        System.out.print("Nhập số lượng phần tử của dãy: ");
        int n = sc.nextInt();

        // Khởi tạo mảng
        int[] array = new int[n];

        // Nhập vào dãy số nguyên
        System.out.println("Nhập vào dãy số nguyên:");
        for (int i = 0; i < n; i++) {
            array[i] = sc.nextInt();
        }

        // Sử dụng HashSet để loại bỏ các phần tử trùng lặp
        Set<Integer> set = new HashSet<>();
        for (int num : array) {
            set.add(num);
        }

        // Chuyển các phần tử từ HashSet về mảng
        int[] uniqueArray = new int[set.size()];
        int index = 0;
        for (int num : set) {
            uniqueArray[index++] = num;
        }

        // Sắp xếp mảng đã loại bỏ các phần tử trùng lặp
        Arrays.sort(uniqueArray);

        // In ra mảng đã sắp xếp
        System.out.println("Mảng sau khi loại bỏ phần tử trùng lặp và sắp xếp:");
        for (int num : uniqueArray) {
            System.out.print(num + " ");
        }
    }
}