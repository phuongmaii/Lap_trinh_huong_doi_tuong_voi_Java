import java.util.Scanner;

public class bai_5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Nhập vào số hàng và số cột của ma trận
        System.out.print("Nhập số hàng của ma trận: ");
        int rows = sc.nextInt();
        System.out.print("Nhập số cột của ma trận: ");
        int cols = sc.nextInt();

        // Khởi tạo ma trận
        double[][] matrix = new double[rows][cols];

        // Nhập vào các phần tử của ma trận
        System.out.println("Nhập vào các phần tử của ma trận:");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                System.out.print("Nhập phần tử thứ [" + i + "][" + j + "]: ");
                matrix[i][j] = sc.nextDouble();
            }
        }

        // Tìm giá trị lớn nhất trong ma trận và vị trí của nó
        double max = matrix[0][0];
        int maxRow = 0;
        int maxCol = 0;

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                if (matrix[i][j] > max) {
                    max = matrix[i][j];
                    maxRow = i;
                    maxCol = j;
                }
            }
        }

        // In ra vị trí của các phần tử có giá trị lớn nhất
        System.out.println("Các phần tử có giá trị lớn nhất là:");
        System.out.println("Giá trị lớn nhất: " + max);
        System.out.println("Vị trí: hàng " + maxRow + ", cột " + maxCol);

    }
}