import java.util.Scanner;

public class bai_1c {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Khai báo biến
        int n;
        int i;
        int so_luong_so_duong = 0;
        double tong_cac_so_duong = 0;
        double trung_binh_cong = 0;


        // Nhập số phần tử của dãy
        System.out.println("Nhập số phần tử của dãy: ");
        n = sc.nextInt();


        // Khởi tạo mảng có n phần tử
        double[] a = new double[n];


        // Nhập dãy số
        System.out.println("Nhập vào các số thực của dãy ");

        for (i = 0; i < n; i++) {
            System.out.println("Phần tử thứ" + (i + 1) + ": ");
            a[i] = sc.nextDouble();
        }


        // Tính trung bình cộng các số dương trong dãy
        for (i = 0; i < n; i++) {
            if (a[i] > 0) {
                tong_cac_so_duong += a[i];
                so_luong_so_duong++;
            }
        }


        // Kiểm tra dãy số để tìm số dương
        if (so_luong_so_duong == 0) {
            System.out.println("Không có số dương trong dãy!");
        } else {
            trung_binh_cong = tong_cac_so_duong / so_luong_so_duong;
            System.out.println("Trung bình cộng các số dương trong dãy: " + trung_binh_cong);
        }
    }
}
