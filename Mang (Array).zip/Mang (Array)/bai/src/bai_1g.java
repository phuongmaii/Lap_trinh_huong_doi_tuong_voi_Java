import java.util.Scanner;

public class bai_1g {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Khai báo biến
        int n;
        int i;
        int k;


        // Nhâp số phần tử của dãy
        System.out.println("Nhập số phần tử của dãy: ");
        n = sc.nextInt();


        // Khởi tạo mảng chứa n phần tử
        double[] a = new double[n];


        // Nhập dãy số
        System.out.println("Nhập các số thực của dãy ");
        for (i = 0; i < n; i++) {
            System.out.println("Phần tử thứ" + (i + 1) + ": ");
            a[i] = sc.nextDouble();
        }


        // Nhập giá trị k từ người dùng
        System.out.println("Nhập giá trị của k: ");
        k = sc.nextInt();


        // Kiểm tra tồn tại k số dương đứng cạnh nhau
        boolean ton_tai_k_so_duong_dung_canh_nhau = false;
        for (i = 0; i <= n - k; i++) {
            boolean co_k_so_duong_dung_canh_nhau = true;
            for (int j = i; j <= j + k; j++) {
                if (a[j] <= 0) {
                    co_k_so_duong_dung_canh_nhau = false;
                    break;
                }
            }
            // In kết quả ra màn hình
            if (ton_tai_k_so_duong_dung_canh_nhau) {
                System.out.println("Trong dãy có tồn tại" + k + "số dương đứng cạnh nhau");
            } else {
                System.out.println("Trong dãy không tồn tại" + k + "số dương đứng cạnh nhau");
            }
        }
    }
}