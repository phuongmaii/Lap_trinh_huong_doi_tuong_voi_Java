import java.util.Scanner;
import java.util.Arrays;

public class bai_1j {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Khai báo biến
        int i;
        int n;


        // Nhập số phần tử của mảng
        System.out.println("Nhập số phần tử của mảng: ");
        n = sc.nextInt();


        // Khởi tạo mảng chứa n phần tử
        double[] a = new double[n];
        System.out.println("Nhập vào các phần tử của mảng ");
        for (i = 0; i < n; i++) {
            System.out.println("Phần tử thứ " + (i + 1) + ": ");
            a[i] = sc.nextDouble();
        }


        // Tìm các số bằng số trước nó cộng 3
        for (i = 1; i < n; i++) {
            if (a[i] == a[i - 1] + 3) {
                System.out.print("Số cần tìm là: " + a[i] + " ");
            }
        }
    }
}
