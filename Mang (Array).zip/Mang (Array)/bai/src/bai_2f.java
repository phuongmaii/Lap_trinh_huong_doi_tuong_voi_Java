import java.util.Scanner;

public class bai_2f {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Nhập vào số lượng phần tử của dãy
        System.out.print("Nhập số lượng phần tử của dãy: ");
        int n = sc.nextInt();

        int[] array = new int[n];

        // Nhập vào dãy số nguyên
        System.out.println("Nhập vào dãy số nguyên:");
        for (int i = 0; i < n; i++) {
            array[i] = sc.nextInt();
        }

        // Nhập vào khoảng [x, y]
        System.out.print("Nhập vào giá trị x: ");
        int x = sc.nextInt();
        System.out.print("Nhập vào giá trị y: ");
        int y = sc.nextInt();

        // Đảm bảo x < y
        if (x >= y) {
            System.out.println("Giá trị x phải nhỏ hơn giá trị y.");
            return;
        }

        // Tính trung bình cộng các số trong khoảng [x, y]
        double sum = 0;
        int count = 0;

        for (int i = 0; i < n; i++) {
            if (array[i] >= x && array[i] <= y) {
                sum += array[i];
                count++;
            }
        }

        if (count == 0) {
            System.out.println("Không có số nào trong khoảng [" + x + ", " + y + "].");
        } else {
            double average = sum / count;
            System.out.println("Trung bình cộng của các số trong khoảng [" + x + ", " + y + "]: " + average);
        }
    }
}
