import java.util.Scanner;

public class bai_1b {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Khai báo biến
        int n;
        int i;
        double sum = 0;


        // Nhập số phần tử của dãy
        System.out.println("Nhập số phần tử của dãy: ");
        n = sc.nextInt();

        // Khai báo mảng lưu dãy số
        double[] a = new double[n];


        // Nhập vào các phần tử của dãy
        System.out.println("Nhập dãy số thực ");

        for (i = 0; i < n; i++) {
            System.out.println("Phần tử thứ " + (i + 1) + ": ");
            a[i] = sc.nextDouble();
        }


        // Tính tổng các phần tử trong dãy
        for (i = 0; i < n; i++) {
            sum += a[i];
        }


        // Hiển thị kết quả
        System.out.println("Tổng của dãy số trong mảng là: " + sum);
    }
}
