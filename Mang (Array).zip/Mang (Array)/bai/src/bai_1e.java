import java.util.Scanner;

public class bai_1e {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Khai báo biến
        int n;
        int i;


        // Nhập số phần tử của dãy
        System.out.println("Nhập số phần tử của dãy: ");
        n = sc.nextInt();


        // Khởi tạo mảng chứa n phần tử của dãy
        double[] a = new double[n];


        // Nhập dãy số
        System.out.println("Nhập vào các số thực của dãy ");
        for (i = 0; i < n; i++) {
            System.out.println("Phần tử thứ" + (i + 1) + ": ");
            a[i] = sc.nextDouble();
        }


        // Tìm số lớn nhất và nhỏ nhất
        double max = a[0];
        double min = a[0];
        int vi_tri_max = 0;
        for (i = 0; i < n; i++) {
            if (a[i] > max) {
                max = a[i];
                vi_tri_max = i;
            } else if (a[i] < min) {
                min = a[i];
            }


            // In kết quả ra màn hình
            System.out.println("số lớn nhất trong dãy là: " + max);
            System.out.println("Số nhỏ nhất trong dãy là: " + min);
            System.out.println("Số lớn nhất nằm ở vị trí: " + (vi_tri_max + 1));
        }
    }
}
