import java.util.Scanner;
import java.util.Arrays;

public class bai_2a {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Khai báo biến
        int n;
        int i;


        // Nhập vào số phần tử của dãy
        System.out.println("Số phần từ của dãy: ");
        n = sc.nextInt();


        // Khởi tạo mảng chứa n phần tử
        double[] a = new double[n];
        for (i = 0; i < n; i++) {
            System.out.println("Phần tử thứ " + (i + 1) + ": ");
            a[i] = sc.nextDouble();
        }


        // Tìm điều kiện để chọn số chia hết cho 3
        System.out.print("Các số chia hết cho 3: ");
        for (i = 0; i < n; i++) {
            if (a[i] % 3 == 0) {
                // chỉ sử dụng a[i] trong vòng lặp
                System.out.print(a[i] + " ");
            }
        }
        System.out.println();


        // Các số không chia hết cho 3
        System.out.print("Các số không chia hết cho 3: ");
        for (i = 0; i < n; i++) {
            if (a[i] % 3 != 0) {
                System.out.print(a[i] + " ");
            }
        }
        System.out.println();


        // In ra các phần tử của dãy
        System.out.print("Các phần tử của dãy: ");
        for (i = 0; i < n; i++) {
            System.out.print(a[i] + " ");
        }
    }
}
