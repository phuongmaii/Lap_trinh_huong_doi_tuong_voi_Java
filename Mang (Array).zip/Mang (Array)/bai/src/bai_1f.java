import java.util.Scanner;

public class bai_1f {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Khai báo biến
        int n;
        int i;
        double sum = 0;


        // Nhập số phần tử của dãy
        System.out.println("Nhập số phần tử của dãy: ");
        n = sc.nextInt();


        // Khởi tạo mảng chứa n phần tử
        double[] a = new double[n];


        // Nhập dãy số
        System.out.println("Nhập vào các số thực của dãy ");
        for (i = 0; i < n; i++) {
            System.out.println("Phần tử thứ" + (i + 1) + ": ");
            a[i] = sc.nextDouble();
        }


        // Tính tổng theo quy luật a1 - a2 + a3 - ....
        for (i = 0; i < n; i++) {
            if (i % 2 == 0) {
                sum += a[i];
                // Cộng ở vị trí chẵn
            } else {
                sum -= a[i];
            }
        }


        // In kết quả ra màn hình
        System.out.println("Tính tổng theo quy luật a1 - a2 + a3 - ..." + sum);
    }
}
