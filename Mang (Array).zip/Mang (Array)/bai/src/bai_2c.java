import java.util.Scanner;

public class bai_2c {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Nhập vào số lượng phần tử của dãy
        System.out.print("Nhập số lượng phần tử của dãy: ");
        int n = sc.nextInt();

        int[] array = new int[n];

        // Nhập vào dãy số nguyên
        System.out.println("Nhập vào dãy số nguyên:");
        for (int i = 0; i < n; i++) {
            array[i] = sc.nextInt();
        }

        // Số cặp phần tử liên tiếp bằng nhau
        int count = 0;

        // Duyệt qua mảng và kiểm tra các cặp phần tử liên tiếp bằng nhau
        for (int i = 0; i < n - 1; i++) {
            if (array[i] == array[i + 1]) {
                System.out.println(array[i] + " " + array[i + 1]);
                count++;
            }
        }

        System.out.println("Số cặp phần tử liên tiếp bằng nhau: " + count);

        // Kiểm tra số cặp là chẵn hay lẻ
        if (count % 2 == 0) {
            System.out.println("Số cặp tìm được là số chẵn.");
        } else {
            System.out.println("Số cặp tìm được là số lẻ.");
        }

    }
}