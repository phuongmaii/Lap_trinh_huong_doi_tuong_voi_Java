import java.util.Scanner;

public class bai_1a {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Khai báo biến
        int n;
        int i;


        // Nhập số phần tử của dãy
        System.out.println("Nhập số phần tử của dãy: ");
        n = sc.nextInt();


        // Khởi tạo mảng có n phần tử
        double[] a = new double[n];


        // Nhập dãy số thực
        System.out.println("Nhập dãy số thực ");

        for (i = 0; i < n; i++) {
            System.out.println("Phần tử thứ " + (i + 1) + ": ");
            a[i] = sc.nextDouble();
        }


        // In dãy số ra màn hình
        System.out.println("Dãy số vừa được nhập: ");

        for (i = 0; i < n; i++) {
            System.out.println(a[i] + "");
        }
    }
}
