import java.util.Scanner;
import java.util.Arrays;

public class bai_1h {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Khai báo biến
        int i;
        int n;


        // Nhập số phần tử của dãy
        System.out.println("Nhập số phần tử của dãy: ");
        n = sc.nextInt();


        // Khởi tạo mảng chứa n phần tử
        double[] a = new double[n];


        // Nhập dãy số
        System.out.println("Nhập vào các số thực của dãy ");
        for (i = 0; i < n; i++) {
            System.out.println("Phần tử thứ " + (i + 1) + ": ");
            a[i] = sc.nextDouble();
        }


        // Chọn các số thực lớn hơn không
        int so_luong_so_thuc_lon_hon_0 = 0;

        // Duyệt lại mảng
        for (i = 0; i < n; i++) {
            if (a[i] > 0) {
                a[so_luong_so_thuc_lon_hon_0] = a[i];
                so_luong_so_thuc_lon_hon_0++;
            }
        }


        // Sắp xếp theo thứ tự tăng dần
        Arrays.sort(a, 0, so_luong_so_thuc_lon_hon_0);


        // Hiển thị dãy số sau khi sắp xếp
        System.out.println("Dãy số thực sau khi sắp xếp theo thứ tự tăng dần: ");
        for (i = 0; i < n; i++) {
            System.out.print(a[i] + " ");
        }
    }
}
