// Nop ban nay
// Xem lai cau c

import java.util.Scanner;
import java.util.Arrays;
import java.util.Comparator;          // Sap xep 1 tap hop


class SanPham {
    private String maSanPham;
    private String tenSanPham;
    private int soLuong;
    private int namNhap;


    // Constructor
    public SanPham(String maSanPham, String tenSanPham, int soLuong, int namNhap) {
        this.maSanPham = maSanPham;
        this.tenSanPham = tenSanPham;
        this.soLuong = soLuong;
        this.namNhap = namNhap;
    }


    // Get/Set
    public String getMaSanPham() {
        return maSanPham;
    }

    public void setMaSanPham(String maSanPham) {
        this.maSanPham = maSanPham;
    }

    public String getTenSanPham() {
        return tenSanPham;
    }

    public void setTenSanPham(String tenSanPham) {
        this.tenSanPham = tenSanPham;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public int getNamNhap() {
        return namNhap;
    }

    public void setNamNhap(int namNhap) {
        this.namNhap = namNhap;
    }


    // Phuong thuc nhap thong tin san pham
    public void input() {

        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap ma san pham: ");
        maSanPham = sc.nextLine();
        System.out.println("Nhap ten san pham: ");
        tenSanPham = sc.nextLine();
        System.out.println("Nhap so luong: ");
        soLuong = sc.nextInt();
        System.out.println("Nhap nam nhap: ");
        namNhap = sc.nextInt();
    }


    // Phuong thuc hien thi thong tin nhap
    public void output() {
        System.out.println("Ma san pham: " + maSanPham);
        System.out.println("Ten san pham: " + tenSanPham);
        System.out.println("So luong: " + soLuong);
        System.out.println("Nam nhap: " + namNhap);
    }
} // Het doan 1


// Lop SP_Phanmem ke thua tu lop SanPham
class SP_Phanmem extends SanPham {
    private String nganhUngDung;

    private String maKey;


    // Constructor - Phương thức khởi tạo
    public SP_Phanmem(String maSanPham, String tenSanPham, int soLuong, int namNhap, String nganhUngDung, String maKey) {
        super(maSanPham, tenSanPham, soLuong, namNhap);
        this.nganhUngDung = nganhUngDung;
        this.maKey = maKey;
    }


    // Get/set
    public String getNganhUngDung() {
        return nganhUngDung;
    }

    public void setNganhUngDung(String nganhUngDung) {
        this.nganhUngDung = nganhUngDung;
    }

    public String getMaKey() {
        return maKey;
    }

    public void setMaKey(String maKey) {
        this.maKey = maKey;
    }


    // Override phuong thuc input va out put
    @Override
    public void input() {
        super.input();

        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap nganh ung dung: ");
        nganhUngDung = sc.nextLine();
        System.out.println("Nhap ma key: ");
        maKey = sc.nextLine();
    }


    @Override
    public void output() {
        super.output();

        System.out.println("Nganh ung dung: " + nganhUngDung);
        System.out.println("Ma key: " + maKey);
    }
}


public class trungTamCongNghe {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // a
        System.out.println("Nhap so luong san pham phan mem: ");
        int n = Integer.parseInt(sc.nextLine());

        // Khai bao mang chua cac san pham phan mem
        SP_Phanmem[] dsSP = new SP_Phanmem[n];

        // Nhap thong tin cho tung san pham phen mem
        for (int i = 0; i < n; i++) {
            System.out.println("Nhap thong tin san pham phan mem thu " + (i + 1) + " ");
            dsSP[i] = new SP_Phanmem("", "", 0, 0, "", "");
            dsSP[i].input();
        }


        // b
        // In ra danh sach cac san pham phan mem vua nhap ra man hinh
        System.out.println("Danh sach san pham phan mem vua nhap: ");
        for (SP_Phanmem sp : dsSP) {
            sp.output();
            System.out.println();
        }


        // c. Sap xep san pham phan mem theo thu tu tu lon den nho cua so luong
        for (int i = 0; i < n; i++) {
            for (int j = i; j < n; j++) {
                if (dsSP[i].getSoLuong() < dsSP[j].getSoLuong()) {
                    SP_Phanmem sp = dsSP[i];
                    dsSP[i] = dsSP[j];
                    dsSP[j] = sp;
                }
            }
        }

        // In ra danh sach sau sap xep
        System.out.println("Danh sach san pham sau sap xep: ");
        for (int i = 0; i < n; i++) {
            System.out.println("Ma san pham: " + dsSP[i].getMaSanPham());
            System.out.println("Ten san pham: " + dsSP[i].getTenSanPham());
            System.out.println("So luong: " + dsSP[i].getSoLuong());
        }


        // d. Tim san pham co nam nhap lau nhat
        SP_Phanmem sp = dsSP[0];
        for (int i = 0; i < n; i++) {
            if (sp.getNamNhap() > dsSP[i].getNamNhap()) {
                sp = dsSP[i];
            }
        }
        System.out.println("San pham co nam nhap lau nhat: ");
        sp.output();

        /* int minNamNhap = Integer.MAX_VALUE;
        SP_Phanmem spMinNamNhap = null;
        for (SP_Phanmem sp : dsSP) {
            if (sp.getNamNhap() > minNamNhap) {
                minNamNhap = sp.getNamNhap();
                spMinNamNhap = sp;
            }
        }
        System.out.println("Sản phẩm phần mềm có năm nhập lâu nhất:");
        if (spMinNamNhap != null) {
            spMinNamNhap.output();

         */

    }
}
