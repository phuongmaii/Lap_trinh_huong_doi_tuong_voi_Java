import java.util.Locale;
import java.util.Scanner;
import java.util.StringTokenizer;
// DHT
class Sach {
    private String maSach;
    private String tenSach;
    private String tacGia;
    private int namXuatBan;
    private int soLuong;
    private double donGia;


    // Constructor
    public Sach(String maSach, String tenSach, String tacGia, int namXuatBan, int soLuong, double donGia) {
        this.maSach = maSach;
        this.tenSach = tenSach;
        this.tacGia = tacGia;
        this.namXuatBan = namXuatBan;
        this.soLuong = soLuong;
        this.donGia = donGia;
    }


    // get/set
    public String getMaSach() {
        return maSach;
    }

    public void setMaSach(String maSach) {
        this.maSach = maSach;
    }

    public String getTenSach() {
        return tenSach;
    }

    public void setTenSach(String tenSach) {
        this.tenSach = tenSach;
    }

    public String getTacGia() {
        return tacGia;
    }

    public void setTacGia(String tacGia) {
        this.tenSach = tenSach;
    }

    public int getNamXuatBan() {
        return namXuatBan;
    }

    public void setNamXuatBan(int namXuatBan) {
        this.namXuatBan = namXuatBan;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public double getDonGia() {
        return donGia;
    }

    public void setDonGia(double donGia) {
        this.donGia = donGia;
    }


    // Phuong thuc input cho cac dau sach
    public void input() {

        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap ma sach: ");
        maSach = sc.next();
        System.out.println("Nhap ten sach: ");
        tenSach = sc.next();
        System.out.println("Nhap tac gia: ");
        tacGia = sc.next();
        System.out.println("Nhap nam xuat ban: ");
        namXuatBan = sc.nextInt();
        System.out.println("Nhap so luong: ");
        soLuong = sc.nextInt();
        System.out.println("Nhap don gia: ");
        donGia = sc.nextFloat();
    }


    public void output() {

        System.out.println("Ma sach: " + maSach);
        System.out.println("Ten sach: " + tenSach);
        System.out.println("Tac gia: " + tacGia);
        System.out.println("Nam xuat ban: " + namXuatBan);
        System.out.println("So luong: " + soLuong);
        System.out.println("Don gia: " + donGia);
    }
}


// Lop sach chuyen khao ke thua tu lop sach
class SachChuyenKhao extends Sach {
    private String theLoai;
    private String ngonNgu;


    // Constructor
    public SachChuyenKhao(String maSach, String tenSach, String tacGia, int namXuatBan, int soLuong, double donGia, String theLoai, String ngonNgu) {
        super(maSach, tenSach, tacGia, namXuatBan, soLuong, donGia);
        this.theLoai = theLoai;
        this.ngonNgu = ngonNgu;
    }


    // get/set
    public String getTheLoai() {
        return theLoai;
    }

    public void setTheLoai(String theLoai) {
        this.theLoai = theLoai;
    }

    public String getNgonNgu() {
        return ngonNgu;
    }

    public void setNgonNgu(String ngonNgu) {
        this.ngonNgu = ngonNgu;
    }


    // Override input
    @Override
    public void input() {
        super.input();

        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap the loai: ");
        theLoai = sc.next();
        System.out.println("Nhap ngon nggu: ");
        ngonNgu = sc.next();
    }


    // Override output
    @Override
    public void output() {
        super.output();

        System.out.println("The loai: " + theLoai);
        System.out.println("Ngon ngu: " + ngonNgu);
    }
}


// Viet chuong trinh thuc hien cong viec
public class quanLySachXuatBan {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // a. Nhap vao danh sach chuyen khao
        System.out.println("Nhap danh sach chuyen khao: ");
        int n = Integer.parseInt(sc.nextLine());

        // Khoi tao mang chua n sach chuyen khao
        SachChuyenKhao[] dsSCK = new SachChuyenKhao[n];

        // Nhap thong tin cho tung dau sach
        for (int i = 0; i < n; i++) {
            System.out.println("Sach chuyen khao thu " + (i + 1) + " ");
            dsSCK[i] = new SachChuyenKhao("a1"+i, "b1"+i, "c1"+i, 2003+i, 12+i, 150000+i, "d1"+i, "e1"+i);
            //dsSCK[i] = new SachChuyenKhao("", "", "", 0, 0, 0, "", "");
            //dsSCK[i].input();
        }


        // b. In danh sach sach chuyen khao ra man hinh
        System.out.println("Danh sach sach chuyen khao da nhap: ");
        for (SachChuyenKhao sck : dsSCK) {
            sck.output();
            System.out.println();
        }


        // c. In ra man hinh sach chuyen khao thuoc the loai cong nghe thong tin
        System.out.println("Danh sach thuoc the loai cong nghe thong tin: ");
        for (int i = 0; i < n; i++) {
            var loaiSachDangXet = dsSCK[i];
            if (loaiSachDangXet.getTheLoai().equalsIgnoreCase("sach cong nghe thong tin")) {
                loaiSachDangXet.output();
                System.out.println("Ma sach: " + loaiSachDangXet.getMaSach());
                System.out.println("So luong: " + loaiSachDangXet.getSoLuong());
            }
        }


        // d. Tim kiem sach chuyen khao co ten la lap trinh huong doi tuong voi Java
        System.out.println("Sach chuyen khao co ten la Lap trinh huong doi tuong voi Java: ");
        for (int i = 0; i < n; i++) {
            var tenSachDangXet = dsSCK[i];
            if (tenSachDangXet.getTenSach().equalsIgnoreCase("Lap trinh huong doi tuong voi Java")) {
                tenSachDangXet.output();
                System.out.println("Ma sach: "+tenSachDangXet.getMaSach());
                System.out.println("So luong: " + tenSachDangXet.getSoLuong());
            }
        }
    }
}