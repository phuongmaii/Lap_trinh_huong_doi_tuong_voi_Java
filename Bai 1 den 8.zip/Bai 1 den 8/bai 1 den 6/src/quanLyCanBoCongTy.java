import java.util.Arrays;
import java.util.Scanner;
import java.util.concurrent.Callable;
// DHT
class NhanVien {
    private String maNhanVien;
    private String hoTen;
    private String phongBan;
    private String soDienThoai;
    private String diaChi;
    private double heSoLuong;


    // ConStructor
    public NhanVien(String maNhanVien, String hoTen, String phongBan, String soDienThoai, String diaChi, double heSoLuong) {
        this.maNhanVien = maNhanVien;
        this.hoTen = hoTen;
        this.phongBan = phongBan;
        this.soDienThoai = soDienThoai;
        this.diaChi = diaChi;
        this.heSoLuong = heSoLuong;
    }

    // get/set
    public String getMaNhanVien() {
        return maNhanVien;
    }

    public void setMaNhanVien(String maNhanVien) {
        this.maNhanVien = maNhanVien;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public String getPhongBan() {
        return phongBan;
    }

    public void setPhongBan(String phongBan) {
        this.phongBan = phongBan;
    }

    public String getSoDienThoai() {
        return soDienThoai;
    }

    public void setSoDienThoai(String soDienThoai) {
        this.soDienThoai = soDienThoai;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    public double getHeSoLuong() {
        return heSoLuong;
    }

    public void setHeSoLuong(double heSoLuong) {
        this.heSoLuong = heSoLuong;
    }


    // Phuong thuc input cho thong tin nhan vien
    public void input() {

        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap ma nhan vien: ");
        maNhanVien = sc.next();
        System.out.println("Nhap ho ten: ");
        hoTen = sc.next();
        System.out.println("Nhap phong ban: ");
        phongBan = sc.next();
        System.out.println("Nhap so dien thoai: ");
        soDienThoai = sc.next();
        System.out.println("Nhap dia chi: ");
        diaChi = sc.next();
        System.out.println("Nhap he so luong: ");
        heSoLuong = sc.nextDouble();
    }


    // Phuong thuc output cho thong tin nhan vien
    public void output() {

        System.out.println("Ma nhan vien: " + maNhanVien);
        System.out.println("Ho ten: " + hoTen);
        System.out.println("Phong ban: " + phongBan);
        System.out.println("So dien thoai: " + soDienThoai);
        System.out.println("Dia chi: " + diaChi);
        System.out.println("He so luong: " + heSoLuong);
    }
}


// Lop Can bo quan ly ke thua tu lop nhan vien
class CB_QuanLy extends NhanVien {
    private String chucVu;
    private double phuCap;


    // Constructor
    public CB_QuanLy(String maNhanVien, String hoTen, String phongBan, String soDienThoai, String diaChi, double heSoLuong, String chucVu, double phuCap) {
        super(maNhanVien, hoTen, phongBan, soDienThoai, diaChi, heSoLuong);
        this.chucVu = chucVu;
        this.phuCap = phuCap;
    }


    // get/set
    public String getChucVu() {
        return chucVu;
    }

    public void setChucVu(String chucVu) {
        this.chucVu = chucVu;
    }

    public double getPhuCap() {
        return phuCap;
    }

    public void setPhuCap(double phuCap) {
        this.phuCap = phuCap;
    }


    // Phuong thuc nhap thong tin can bo quan ly
    @Override
    public void input() {
        super.input();

        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap chuc vu: ");
        chucVu = sc.next();
        System.out.println("Nhap phu cap: ");
        phuCap = sc.nextDouble();
    }


    @Override
    public void output() {
        super.output();


        System.out.println("Chuc vu: " + chucVu);
        System.out.println("Phu cap: " + phuCap);
    }
}


// Viet chuong trinh thuc hien cac cong viec
public class quanLyCanBoCongTy {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // a. Nhap vao danh sach can bo quan ly
        System.out.println("Danh sach can bo quan ly: ");
        int n = Integer.parseInt(sc.nextLine());

        // Khai bao mang chua n can bo quan ly
        CB_QuanLy[] dsCB = new CB_QuanLy[n];

        // Nhap thong tin cho tung can bo quan ly
        for (int i = 0; i < n; i++) {
            System.out.println("Thong tin cua danh sach can bo quan ly thu " + (i + 1) + " ");
            dsCB[i] = new CB_QuanLy("", "", "", "", "", 0, "", 0);
            dsCB[i].input();
        }


        // b. In danh sach vua nhap ra man hinh
        System.out.println("Danh sach can bo vua nhap: ");
        for (CB_QuanLy cb : dsCB) {
            cb.output();
            System.out.println();
        }


        //c. Tim kiem can bo quan ly co chuc vu la giam doc
        System.out.println("Can bo quan ly co chuc vu la giam doc: ");
        for (int i = 0; i < n; i++) {
            var canBoDangXet = dsCB[i];
            if (canBoDangXet.getChucVu().equalsIgnoreCase("giamdoc")) {
                canBoDangXet.output();
                //System.out.println("Ma nhan vien: " + canBoDangXet.getMaNhanVien());
                //System.out.println("Ho ten: " + canBoDangXet.getHoTen());

            }
        }


        // d. Sap xep can bo theo muc phu cap giam dan
        for (int i = 0; i < n; i++) {
            for (int j = i; j < n; j++) {
                if (dsCB[i].getPhuCap() < dsCB[j].getPhuCap()) {
                    CB_QuanLy cb = dsCB[i];
                    dsCB[i] = dsCB[j];
                    dsCB[j] = cb;
                }
            }
        }

        // Danh sach sau sap xep
        System.out.println("Danh sach can bo co muc phu cap giam dan: ");
        for (int i = 0; i < n; i++) {
            System.out.println("Ma nhan vien: " + dsCB[i].getMaNhanVien());
            System.out.println("Ho ten: " + dsCB[i].getHoTen());
            System.out.println("Chuc vu: " + dsCB[i].getChucVu());
            System.out.println("Phu cap: " + dsCB[i].getPhuCap());

        }
    }
}