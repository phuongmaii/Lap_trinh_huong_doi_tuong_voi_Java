import java.util.Scanner;

class SanPham {
    private String maSanPham;
    private String tenSanPham;
    private String ngaySanXuat;
    private String hanSuDung;
    private String soLo;
    private String toSanXuat;


    // Constructor
    public SanPham(String maSanPham, String tenSanPham, String ngaySanXuat, String hanSuDung, String soLo, String toSanXuat) {
        this.maSanPham = maSanPham;
        this.tenSanPham = tenSanPham;
        this.ngaySanXuat = ngaySanXuat;
        this.hanSuDung = hanSuDung;
        this.soLo = soLo;
        this.toSanXuat = toSanXuat;
    }


    // get/set
    public String getMaSanPham() {
        return maSanPham;
    }

    public void setMaSanPham(String maSanPham) {
        this.maSanPham = maSanPham;
    }

    public String getTenSanPham() {
        return tenSanPham;
    }

    public void setTenSanPham(String tenSanPham) {
        this.tenSanPham = tenSanPham;
    }

    public String getNgaySanXuat() {
        return ngaySanXuat;
    }

    public void setNgaySanXuat(String ngaySanXuat) {
        this.ngaySanXuat = ngaySanXuat;
    }

    public String getHanSuDung() {
        return hanSuDung;
    }

    public void setHanSuDung(String hanSuDung) {
        this.hanSuDung = hanSuDung;
    }

    public String getSoLo() {
        return soLo;
    }

    public void setSoLo(String soLo) {
        this.soLo = soLo;
    }

    public String getToSanXuat() {
        return toSanXuat;
    }

    public void setToSanXuat(String toSanXuat) {
        this.toSanXuat = toSanXuat;
    }


    // Input
    public void input() {

        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap ma san pham: ");
        maSanPham = sc.next();
        System.out.println("Nhap ten san pham: ");
        tenSanPham = sc.next();
        System.out.println("Nhap ngay san xuat: ");
        ngaySanXuat = sc.next();
        System.out.println("Nhap han su dung: ");
        hanSuDung = sc.next();
        System.out.println("Nhap so lo: ");
        soLo = sc.next();
        System.out.println("Nhap to san xuat: ");
        toSanXuat = sc.next();
    }


    // Output
    public void output() {

        System.out.println("Ma san pham: " + maSanPham);
        System.out.println("Ten san pham: " + tenSanPham);
        System.out.println("Ngay san xuat: " + ngaySanXuat);
        System.out.println("Han su dung: " + hanSuDung);
        System.out.println("So lo: " + soLo);
        System.out.println("To san xuat: " + toSanXuat);
    }
}


// Lop san pham cao cap ke thua tu lop san pham
class SP_CaoCap extends SanPham {
    private String loaiSanPham;
    private double phuPhi;


    // Constructor
    public SP_CaoCap(String maSanPham, String tenSanPham, String ngaySanXuat, String hanSuDung, String soLo, String toSanXuat, String loaiSanPham, double phuPhi) {
        super(maSanPham, tenSanPham, ngaySanXuat, hanSuDung, soLo, toSanXuat);
        this.loaiSanPham = loaiSanPham;
        this.phuPhi = phuPhi;
    }


    // get/set
    public String getLoaiSanPham() {
        return loaiSanPham;
    }

    public void setLoaiSanPham(String loaiSanPham) {
        this.loaiSanPham = loaiSanPham;
    }

    public double getPhuPhi() {
        return phuPhi;
    }

    public void setPhuPhi(double phuPhi) {
        this.phuPhi = phuPhi;
    }


    // Override input
    @Override
    public void input() {
        super.input();

        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap loai san pham: ");
        loaiSanPham = sc.next();
        System.out.println("Nhap phu phi: ");
        phuPhi = sc.nextDouble();
    }


    // Override output
    @Override
    public void output() {
        super.output();

        System.out.println("Loai san pham: " + loaiSanPham);
        System.out.println("Phu phi: " + phuPhi);
    }
}


// Viet chuong trinh thuc hien cong viec
public class quanLySanPhamSanXuat {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);


        // a. Nhap danh sach san pham cao cap
        System.out.println("Danh sach san pham cao cap: ");
        int n = Integer.parseInt(sc.nextLine());

        // Khoi tao mang chua n san pham cao cap
        SP_CaoCap[] dsSP = new SP_CaoCap[n];

        // Nhap thong tin cua san pham cao cap
        for (int i = 0; i < n; i++) {
            System.out.println("San pham cao cap thu " + (i + 1) + ": ");
            //dsSP[i] = new SP_CaoCap("a"+i, "b"+i, "12/2/23"+i, "23/12/23"+i, "a12"+i, "t1"+i, "Nuocgiat"+i, 12000+i);
            dsSP[i] = new SP_CaoCap("", "", "", "", "", "", "", 0);
            dsSP[i].input();
        }


        // b. In ra danh sach cac san pham cao cap vua nhap
        System.out.println("Danh sach cac san pham cao cap: ");
        for (SP_CaoCap sp : dsSP) {
            sp.output();
            System.out.println();
        }


        // c. Tim kiem san pham cao cap co loai san pham la "dac biet"
        for (int i = 0; i < n; i++) {
            var laoiSanPhamDangXet = dsSP[i];
            if (dsSP[i].getLoaiSanPham().equalsIgnoreCase("dacbiet")) {
                laoiSanPhamDangXet.output();
                System.out.println(dsSP[i].getMaSanPham() + " " + dsSP[i].getTenSanPham());
            }
        }


        // d. Sap xep san pham theo thu tu giam dan cua phu phi
        for (int i = 0; i < n; i++) {
            for (int j = i; j < n; j++) {
                if (dsSP[i].getPhuPhi() < dsSP[j].getPhuPhi()) {
                    SP_CaoCap sp = dsSP[i];
                    dsSP[i] = dsSP[j];
                    dsSP[j] = sp;
                }
            }
        }
        System.out.println("Danh sach san pham sau khi sap xep theo thu tu giam dan muc phu phi: ");
        for (int i = 0; i < n; i++) {
            System.out.println("Ma san pham: " + dsSP[i].getMaSanPham());
            System.out.println("Ten san pham: " + dsSP[i].getTenSanPham());
            System.out.println("Phu phi: " + dsSP[i].getPhuPhi());
        }
    }
}