import java.util.Scanner;

// DHT
class ThietBi {
    private String maMay;
    private String tenMay;
    private int soLuong;
    private String namDuaVaoSuDung;
    private int namKiemKe;


    // Constructor
    public ThietBi(String maMay, String tenMay, int soLuong, String namDuaVaoSuDung, int namKiemKe) {
        this.maMay = maMay;
        this.tenMay = tenMay;
        this.soLuong = soLuong;
        this.namDuaVaoSuDung = namDuaVaoSuDung;
        this.namKiemKe = namKiemKe;
    }


    // get/set

    public String getMaMay() {
        return maMay;
    }

    public void setMaMay(String maMay) {
        this.maMay = maMay;
    }

    public String getTenMay() {
        return tenMay;
    }

    public void setTenMay(String tenMay) {
        this.tenMay = tenMay;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public String getNamDuaVaoSuDung() {
        return namDuaVaoSuDung;
    }

    public void setNamDuaVaoSuDung(String namDuaVaoSuDung) {
        this.namDuaVaoSuDung = namDuaVaoSuDung;
    }

    public int getNamKiemKe() {
        return namKiemKe;
    }

    public void setNamKiemKe(int namKiemKe) {
        this.namKiemKe = namKiemKe;
    }


    // Input
    public void input() {

        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap ma may: ");
        maMay = sc.next();
        System.out.println("Nhap ten may: ");
        tenMay = sc.next();
        System.out.println("Nhap so luong: ");
        soLuong = sc.nextInt();
        System.out.println("Nhap nam dua vao su dung: ");
        namDuaVaoSuDung = sc.next();
        System.out.println("Nhap nam kiem ke: ");
        namKiemKe = sc.nextInt();
    }


    // Output
    public void output() {

        System.out.println("Ma may: " + maMay);
        System.out.println("Ten may: " + tenMay);
        System.out.println("So luong: " + soLuong);
        System.out.println("Nam dua vao su dung: " + namDuaVaoSuDung);
        System.out.println("Nam kiem ke: " + namKiemKe);
    }
}


//Lop may chu ke thua tu lop thiet bi
class MayChu extends ThietBi {
    private String loaiMayChu;
    private String chucNang;


    // Constructor
    public MayChu(String maMay, String tenMay, int soluong, String namDuaVaoSuDung, int namKiemKe, String loaiMayChu, String chucNang) {
        super(maMay, tenMay, soluong, namDuaVaoSuDung, namKiemKe);
        this.loaiMayChu = loaiMayChu;
        this.chucNang = chucNang;
    }


    // get/set
    public String getLoaiMayChu() {
        return loaiMayChu;
    }

    public void setLoaiMayChu(String loaiMayChu) {
        this.loaiMayChu = loaiMayChu;
    }

    public String getChucNang() {
        return chucNang;
    }

    public void setChucNang(String chucNang) {
        this.chucNang = chucNang;
    }


    // Override input
    @Override
    public void input() {
        super.input();

        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap loai may chu: ");
        loaiMayChu = sc.next();
        System.out.println("Nhap chuc nang: ");
        chucNang = sc.next();
    }


    // Override output
    @Override
    public void output() {
        super.output();

        System.out.println("Loai may chu: " + loaiMayChu);
        System.out.println("Chuc nang: " + chucNang);
    }
}


// Viet chuong trinh thuc hien cong viec
public class quanLyThietBiPhongMay {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // a. Nhap danh sach may chu
        System.out.println("Danh sach may chu: ");
        int n = Integer.parseInt(sc.nextLine());

        // Khoi tao mang chua n may chu
        MayChu[] dsMC = new MayChu[n];

        // Nhap thong tin cho may chu
        for (int i = 0; i < n; i++) {
            System.out.println("May chu thu " + (i + 1) + " ");
            dsMC[i] = new MayChu("", "", 0, "21" + i, 0, "", "");
            dsMC[i].input();
        }


        // b. In ra danh sach may chu
        System.out.println("Danh sach may chu: ");
        for (MayChu mc : dsMC) {
            mc.output();
            System.out.println();
        }


        // c. Tim kiem may chu co chuc nang la "Application Servers"
        for (int i = 0; i < n; i++) {
            var mayChuDangXet = dsMC[i];
            if (mayChuDangXet.getChucNang().equalsIgnoreCase("Application Servers")) {
                mayChuDangXet.output();
                System.out.println();
            }
        }


        // d. Sap xep may chu giam dan theo so luong
        for (int i = 0; i < n; i++) {
            for (int j = i; j < n; j++) {
                if (dsMC[i].getSoLuong() < dsMC[j].getSoLuong()) {
                    MayChu mc = dsMC[i];
                    dsMC[i] = dsMC[j];
                    dsMC[j] = mc;
                }
            }
        }
        System.out.println("Danh sach may chu sau khi sap xep theo thu tu giam dan so luong: ");
        for (int i = 0; i < n; i++) {
            System.out.println("Ma may: " + dsMC[i].getMaMay());
            System.out.println("Ten may: " + dsMC[i].getTenMay());
            System.out.println("So luong: " + dsMC[i].getSoLuong());

        }
    }
}