// Nop ban nay

import java.util.Scanner;
import java.util.Arrays;
import java.util.Comparator;          // Sap xep 1 tap hop


class SanPham {
    private String maSanPham;
    private String tenSanPham;
    private int soLuong;
    private int namNhap;


    // Constructor
    public SanPham(String maSanPham, String tenSanPham, int soLuong, int namNhap) {
        this.maSanPham = maSanPham;
        this.tenSanPham = tenSanPham;
        this.soLuong = soLuong;
        this.namNhap = namNhap;
    }


    // Get/Set
    public String getMaSanPham() {
        return maSanPham;
    }

    public void setMaSanPham(String maSanPham) {
        this.maSanPham = maSanPham;
    }

    public String getTenSanPham() {
        return tenSanPham;
    }

    public void setTenSanPham(String tenSanPham) {
        this.tenSanPham = tenSanPham;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public int getNamNhap() {
        return namNhap;
    }

    public void setNamNhap(int namNhap) {
        this.namNhap = namNhap;
    }


    // Phuong thuc nhap thong tin san pham
    public void input() {

        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap ma san pham: ");
        maSanPham = sc.nextLine();
        System.out.println("Nhao ten san pham: ");
        tenSanPham = sc.nextLine();
        System.out.println("Nhap so luong: ");
        soLuong = sc.nextInt();
        System.out.println("Nhap nam nhap: ");
        namNhap = sc.nextInt();
    }


    // Phuong thuc hien thi thong tin nhap
    public void output() {
        System.out.println("Ma san pham: " + maSanPham);
        System.out.println("Ten san pham: " + tenSanPham);
        System.out.println("So luong: " + soLuong);
        System.out.println("Nam nhap: " + namNhap);
    }
} // Het doan 1


// Lop SP_Phanmem ke thua tu lop SanPham
class SP_Phanmem extends SanPham {
    private String nganhUngDung;

    private String maKey;


    // Constructor - Phương thức khởi tạo
    public SP_Phanmem(String maSanPham, String tenSanPham, int soLuong, int namNhap, String nganhUngDung, String maKey) {
        super(maSanPham, tenSanPham, soLuong, namNhap);
        this.nganhUngDung = nganhUngDung;
        this.maKey = maKey;
    }


    // Get/set
    public String getNganhUngDung() {
        return nganhUngDung;
    }

    public void setNganhUngDung(String nganhUngDung) {
        this.nganhUngDung = nganhUngDung;
    }

    public String getMaKey() {
        return maKey;
    }

    public void setMaKey(String maKey) {
        this.maKey = maKey;
    }


    // Override phuong thuc input va out put
    @Override
    public void input() {
        super.input();

        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap nganh ung dung: ");
        nganhUngDung = sc.nextLine();
        System.out.println("Nhap ma key: ");
        maKey = sc.nextLine();
    }


    @Override
    public void output() {
        super.output();

        System.out.println("Nganh ung dung: " + nganhUngDung);
        System.out.println("Ma key: " + maKey);
    }
}


public class main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // a
        System.out.println("Nhap so luong san pham phan mem: ");
        int n = Integer.parseInt(sc.nextLine());

        // Khai bao mang chua cac san pham phan mem
        SP_Phanmem[] dsSP = new SP_Phanmem[n];

        // Nhap thong tin cho tung san pham phen mem
        for (int i = 0; i < n; i++) {
            System.out.println("Nhap thong tin san pham phan mem thu " + (i + 1) + " ");
            dsSP[i] = new SP_Phanmem("", "", 0, 0, "", "");
            dsSP[i].input();
        }


        // b
        // In ra danh sach cac san pham phan mem vua nhap ra man hinh
        System.out.println("Danh sach san pham phan mem vua nhap: ");
        for (SP_Phanmem sp : dsSP) {
            sp.output();
            System.out.println();
        }


        // c
        // Sap xep cac phan mem nhap theo thu tu lon nho so luong
        Arrays.sort(dsSP, new Comparator<SP_Phanmem>() {
            @Override
            public int compare(SP_Phanmem sp1, SP_Phanmem sp2) {
                return sp2.getSoLuong() - sp1.getSoLuong();
            }
        });

        // In  ra danh sach cac san pham phan mem sau khi sap xep
        System.out.println("Danh sach cac san pham phan mem sau khi sap xep theo thu tu: ");
        for (SP_Phanmem sp : dsSP) {
            sp.output();
            System.out.println();
        }


        // d
        // Tim san pham co nam nhap lau nhat
        int maxNamNhap = dsSP[0].getNamNhap();
        SP_Phanmem spNamNhapLauNhat = dsSP[0];
        for (int i = 1; i < n; i++) {
            if (dsSP[i].getNamNhap() > maxNamNhap) {
                maxNamNhap = dsSP[i].getNamNhap();
                spNamNhapLauNhat = dsSP[i];
            }
        }

        // In thong tin san pham phan mem co nam nhap lau nhat
        System.out.println("San pham co nam nhap lau nhat: ");
        spNamNhapLauNhat.output();
    }
}