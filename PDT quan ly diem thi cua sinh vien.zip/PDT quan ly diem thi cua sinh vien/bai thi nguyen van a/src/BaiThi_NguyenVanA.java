import baithi.SinhVien;


import java.util.Scanner;


public class BaiThi_NguyenVanA {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // a. Nhap vao danh sach n sinh vien, xuat danh sach ra man hinh
        System.out.println("Nhap danh sach sinh vien: ");
        int n = Integer.parseInt(sc.nextLine());

        // Khoi tao mang chua n sinh vien
        SinhVien[] dsSV = new SinhVien[n];

        // Nhap thong tin cho danh sach sinh vien
        for (int i = 0; i < n; i++) {
            System.out.println("Sinh vien thu " + (i + 1) + " ");
            //dsSV[i] = new SinhVien("Ho Ten" + i, "gt", "ngaysinh", "masv", "lop" + i % 2,  i % 5 + 5);
            dsSV[i] = new SinhVien();
            dsSV[i].input();
        }
        while (true) {
            System.out.println("--------------------------------------------------------------------------");
            System.out.println("-----------------------------------MENU-----------------------------------");
            // In danh sach ra man hinh
            System.out.println("Danh sach sinh vien: ");
            for (SinhVien sv : dsSV) {
                sv.output();
                System.out.println();
            }


            // c. Dua ra bang diem cua 1 lop bat ki (ten lop duoc nhap tu ban phim)

            // Nhap ten lop
            System.out.println("Nhap ten lop: ");
            String lop = sc.next();
            // In ra bang diem cua lop do
            System.out.println("Bang diem: ");
            for (int i = 0; i < n; i++) {
                if (dsSV[i].getLop().equals(lop)) {
                    System.out.println("Ho ten: " + dsSV[i].getHoTen());
                    System.out.println("Diem trung binh: " + dsSV[i].getDiemTrungBinh());
                }
            }
        }
    }
}




