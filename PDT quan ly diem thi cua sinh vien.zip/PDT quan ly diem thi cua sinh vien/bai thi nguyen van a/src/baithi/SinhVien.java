package baithi;

// DHT

import java.util.Scanner;

class Nguoi {
    private String hoTen;
    private String gioiTinh;
    private String ngayThangNamSinh;


    // Constructor khong tham so
    public Nguoi() {

    }


    // Constructor co tham so
    public Nguoi(String hoTen, String gioiTinh, String ngayThangNamSinh) {
        this.hoTen = hoTen;
        this.gioiTinh = gioiTinh;
        this.ngayThangNamSinh = ngayThangNamSinh;
    }


    // get/set
    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public String getGioiTinh() {
        return gioiTinh;
    }

    public void setGioiTinh(String gioiTinh) {
        this.gioiTinh = gioiTinh;
    }

    public String getNgayThangNamSinh() {
        return ngayThangNamSinh;
    }

    public void setNgayThangNamSinh(String ngayThangNamSinh) {
        this.ngayThangNamSinh = ngayThangNamSinh;
    }


    // Input
    public void input() {

        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap ho ten: ");
        hoTen = sc.next();
        System.out.println("Nhap gioi tinh: ");
        gioiTinh = sc.next();
        System.out.println("Nhap ngay thang nam sinh: ");
        ngayThangNamSinh = sc.next();
    }


    // Output
    public void output() {

        System.out.println("Ho ten: " + hoTen);
        System.out.println("Gioi tinh: " + gioiTinh);
        System.out.println("Ngay thang nam sinh: " + ngayThangNamSinh);
    }
}


// Lop sinh vien ke thua tu lop nguoi
public class SinhVien extends Nguoi {
    private String maSinhVien;
    private String lop;
    private double diemTrungBinh;


    // Constructor khong co tham so
    public SinhVien() {

    }


    // Constructor co tham so
    public SinhVien(String hoTen, String gioiTinh, String ngayThangNamSinh, String maSinhVien, String lop, double diemTrungBinh) {
        super(hoTen, gioiTinh, ngayThangNamSinh);
        this.maSinhVien = maSinhVien;
        this.lop = lop;
        this.diemTrungBinh = diemTrungBinh;
    }


    // get/set
    public String getMaSinhVien() {
        return maSinhVien;
    }

    public void setMaSinhVien(String maSinhVien) {
        this.maSinhVien = maSinhVien;
    }

    public String getLop() {
        return lop;
    }

    public void setLop(String lop) {
        this.lop = lop;
    }

    public double getDiemTrungBinh() {
        return diemTrungBinh;
    }

    public void setDiemTrungBinh(double diemTrungBinh) {
        this.diemTrungBinh = diemTrungBinh;
    }


    // Override - ghi de
    // Override input
    @Override
    public void input() {
        super.input();

        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap ma sinh vien: ");
        maSinhVien = sc.next();
        System.out.println("Nhap lop: ");
        lop = sc.next();
        // Check diem co hop le khong
        while (true) {
            try {
                System.out.println("Nhap diem trung binh: ");
                diemTrungBinh = sc.nextDouble();
                if (diemTrungBinh < 0 || diemTrungBinh > 10) {
                    throw new IllegalArgumentException("Diem trung binh khong duoc nho hon 0 va lon hon 10");
                }
            } catch (Exception e) {
                System.out.println("Gap loi: " + e);
                System.out.println("Nhsp lai diem trung binh!");
                System.out.println("Nhap diem trung binh: ");
                diemTrungBinh = sc.nextDouble();
            }
            break;
        }
    }


    // Override output
    @Override
    public void output() {
        super.output();

        System.out.println("Ma sinh vien: " + maSinhVien);
        System.out.println("Lop: " + lop);
        System.out.println("Diem trung binh: " + diemTrungBinh);
    }
}




