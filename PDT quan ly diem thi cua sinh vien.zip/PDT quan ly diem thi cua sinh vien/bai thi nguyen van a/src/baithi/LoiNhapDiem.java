package baithi;

public class LoiNhapDiem {
    public LoiNhapDiem() {
        super();
    }
}

