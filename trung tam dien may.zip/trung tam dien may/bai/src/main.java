import java.util.Scanner;

class KhachHang {
    private String maKhachHang;
    private String hoTen;
    private String diaChi;
    private double soDienThoai;


    // Constructor
    public KhachHang(String maKhachHang, String hoTen, String diaChi, double soDienThoai) {
        this.maKhachHang = maKhachHang;
        this.hoTen = hoTen;
        this.diaChi = diaChi;
        this.soDienThoai = soDienThoai;
    }


    // get/set
    public String getMaKhachHang() {
        return maKhachHang;
    }

    public void setMaKhachHang(String maKhachHang) {
        this.maKhachHang = maKhachHang;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }
li
    public double getSoDienThoai() {
        return soDienThoai;
    }

    public void setSoDienThoai(double soDienThoai) {
        this.soDienThoai = soDienThoai;
    }


    // Phuong thuc input nhap thong tin 1 khach hang
    public void input() {

        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap ma khach hang: ");
        maKhachHang = sc.next();
        System.out.println("Nhap ho ten: ");
        hoTen = sc.next();
        System.out.println("Nhap dia chi: ");
        diaChi = sc.next();
        System.out.println("Nhap so dien thoai: ");
        soDienThoai = sc.nextDouble();
    }


    // Phuong thuc output cho 1 khach hang
    public void output() {

        System.out.println("Ma khach hang: " + maKhachHang);
        System.out.println("Ho ten: " + hoTen);
        System.out.println("Dia chi: " + diaChi);
        System.out.println("So dien thoai: " + soDienThoai);
    }
}


// Lop khach hang than thiet ke thua tu lop khach hang
class KH_ThanThiet extends KhachHang {
    private String loaiKhachHang;
    private double khuyenMai;


    // Constructor
    public KH_ThanThiet(String maKhachHang, String hoTen, String diaChi, double soDienThoai, String loaiKhachHang, double khuyenMai) {
        super(maKhachHang, hoTen, diaChi, soDienThoai);
        this.loaiKhachHang = loaiKhachHang;
        this.khuyenMai = khuyenMai;
    }


    // get/set
    public String getLoaiKhachHang() {
        return loaiKhachHang;
    }

    public void setLoaiKhachHang(String loaiKhachHang) {
        this.loaiKhachHang = loaiKhachHang;
    }

    public double getKhuyenMai() {
        return khuyenMai;
    }

    public void setKhuyenMai(double khuyenMai) {
        this.khuyenMai = khuyenMai;
    }


    // Phuong thuc input cho khach hang than thiet
    @Override
    public void input() {
        super.input();

        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap loai khach hang: ");
        loaiKhachHang = sc.next();
        System.out.println("Nhap khuyen mai: ");
        khuyenMai = sc.nextDouble();
    }


    // Phuong thuc output cho khach hang than thiet
    @Override
    public void output() {
        super.output();

        System.out.println("Loai khach hang: " + loaiKhachHang);
        System.out.println("Khuyen mai: " + khuyenMai);
    }
}


// Chuong trinh thuc hien cac cong viec
public class main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // a. Nhap danh sach khach hang than thiet
        System.out.println("Nhap danh sach khach hang than thiet: ");
        int n = Integer.parseInt(sc.nextLine());

        // Khai bao mang chua n khach hang thang thiet
        KH_ThanThiet[] dsKH = new KH_ThanThiet[n];

        // Nhap thong tin cho tung khach hang than thiet
        for (int i = 0; i < n; i++) {
            System.out.println("Nhap thong tin khach hang than thiet thu " + (i + 1) + " ");
            //dsKH[i] = new KH_ThanThiet("MaKH" + i, "Ho Ten " + i, "Dia Chi " + i, 987654320 + i, i % 3 == 0 ? "Vang" : i % 3 == 1 ? "Bac" : i % 3 == 2 ? "kimcuong" : "", i);
            dsKH[i] = new KH_ThanThiet("", "", "", 0, "", 0);
            dsKH[i].input();
        }
        System.out.println("-----------------------------------------------------------------------");
        System.out.println("----------------------------------MENU---------------------------------");
        System.out.println("1. In danh sach khach hang than thiet vua nhap ra man hinh");
        System.out.println("2. Tim kiem khach hanh than thiet cop muc khuyen mai cao nhat");
        System.out.println("3. Dem so khach hang than thiet thuoc loai kim cuong");
        System.out.println("0. Ket thuc chuong trinh");
        System.out.println("-----------------------------------------------------------------------");
        while (true) {
            int choice = sc.nextInt();
            switch (choice) {
                // b. In danh sach khach hang than thiet vua nhap
        /*
        System.out.println("Danh sach khach hang than thiet: ");
        for (KH_ThanThiet kh : dsKH) {
            kh.output();
            System.out.println();
        }

         */
                case 1:
                    System.out.println("-----------------------------------------------------------------------");
                    System.out.println("Danh sach khach hang than thiet vua nhap");
                    for (int i = 0; i < n; i++) {
                        dsKH[i].output();
                        System.out.println();
                    }
                    break;

                case 2:
                    System.out.println("-----------------------------------------------------------------------");
                    System.out.println("Khach hang co muc khuyen mai cao nhat");
                    // c. Tim kiem khach hang than thiet co muc khuyen mai cao nhat
                    KH_ThanThiet ketqua = dsKH[0];
                    for (int i = 0; i < n; i++) {
                        if (ketqua.getKhuyenMai() < dsKH[i].getKhuyenMai()) {
                            ketqua = dsKH[i];
                        }
                    }
                    ketqua.output();
                    break;
                case 3:
                    System.out.println("-----------------------------------------------------------------------");
                    System.out.println("Khach hanh than thiet thuoc loai kim cuong");
                    // d. Dem so khach hang than thiet thuoc loai khach hang kim cuong
                    int dem = 0;
                    for (int i = 0; i < n; i++) {
                        var khachHangDangXet = dsKH[i];
            /*
            String LoaiKhachHang = khachHangDangXet.getLoaiKhachHang();
            //String loaiKHKC = "kimcuong";
            if (LoaiKhachHang.equals(loaiKHKC)) {

             */
                        if (khachHangDangXet.getLoaiKhachHang().equals("kimcuong")) {
                            dem++;
                        }
                    }

                    break;
                case 0:
                    System.out.println("-----------------------------------------------------------------------");
                    System.out.println("Ket thuc chuong trinh");
                    break;
                default:
                    System.out.println("lua chon khong dung, vui long chon lai");
            }
        }
    }
}