import java.util.Scanner;

public class tinh_tien_thuong_cho_cong_nhan {
    public static void main(String[] args) {
        // Khai báo biến
        Scanner sc = new Scanner(System.in);
        double a;
        double b;
        double c;

        // Nhập biến số
        System.out.println("Nhập tên công nhân: ");
        String name = sc.nextLine();
        System.out.println("Định mức sản phẩm của công nhân: ");
        a = sc.nextDouble();
        System.out.println("Số lượng sản phẩm công nhân làm được: ");
        b = sc.nextDouble();


        // Điều kiện
        if (b > a) {
            System.out.println("Công nhân được thưởng tết");
            c = (b - a) * 100;
            System.out.println("Tiền thưởng tết của công nhân là: " + c);
        } else
            System.out.println("Công nhân không được thưởng tết");
    }
}
