
import java.util.Scanner;

public class ket_qua_hoc_tap {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhập a: ");
        double a;
        a = sc.nextDouble();

        if (a >= 8.0)
            System.out.println("Sinh viên đạt loại giỏi");
        else if (a >= 7.0)
            System.out.println("Sinh viên đạt loại khá");
        else if (a >= 5.0)
            System.out.println("Sinh viên đạt loại trung bình");
        else
            System.out.println("Sinh viên đạt loại yếu");
    }
}
