import java.util.Scanner;

public class tien_dien {
    public static void main(String[] args) {
        // Khai báo
        Scanner sc = new Scanner(System.in);
        double m1 = 25000;
        double m2 = 20000;
        double m3 = 15000;
        double m4 = 10000;
        double a_sodien;
        double b_sotien = 0;


        // Nhập tham số (Có thể comment đoạn này lại)
        /*
        System.out.println("Giá trị m1: ");
        m1 = sc.nextDouble();
        System.out.println("Giá trị m2: ");
        m2 = sc.nextDouble();
        System.out.println("Giá trị m3: ");
        m3 = sc.nextDouble();
        System.out.println("Giá trị m4: ");
        m4 = sc.nextDouble();
        */


        // Nhập biến số
        System.out.println("Nhập số điện đã dùng a: ");
        a_sodien = sc.nextDouble();
        //
        // b_sotien = sc.nextDouble();


        // Tính toán
        if (a_sodien <= 50) {
            b_sotien = a_sodien * m1;
            //System.out.println("Tiền điện tháng: "+b_sotien);
        } else {
            if (a_sodien >= 51 && a_sodien <= 100) {
                b_sotien = a_sodien * m2;
                // System.out.println("Tiền điện tháng: "+b_sotien);
            } else {
                if (a_sodien >= 101 && a_sodien <= 200) {
                    b_sotien = a_sodien * m3;
                    //System.out.println("Tiền điện tháng: "+b_sotien);
                } else {
                    if (a_sodien >= 201) {
                        b_sotien = a_sodien * m4;
                        //System.out.println("Tiền điện tháng: "+b_sotien);
                    }
                }
            }
        }


        // In ra kết quả
        System.out.println("Tiền điện tháng: " + b_sotien);
    }
}

