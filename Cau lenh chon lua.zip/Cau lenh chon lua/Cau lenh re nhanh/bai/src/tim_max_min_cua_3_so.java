import java.util.Scanner;

public class tim_max_min_cua_3_so {
    public static void main(String[] args) {
        // Khai báo biến
        Scanner sc = new Scanner(System.in);
        int a, b, c;
        int max, min;


        // Nhập biến số
        System.out.println("Nhập giá trị của a: ");
        a = sc.nextInt();
        System.out.println("Nhập giá trị của b: ");
        b = sc.nextInt();
        System.out.println("Nhập giá trị của c: ");
        c = sc.nextInt();


        // Điều kiện
        if (a > b && a > c) {
            max = a;
            System.out.println("Giá trị lớn nhất là: " + a);
        } else {
            if (b > a && b > c) {
                max = b;
                System.out.println("Giá trị lớn nhất là: " + b);
            } else {
                if (c > a && c > b) {
                    max = c;
                    System.out.println("Giá trị lớn nhất là: " + c);
                }
            }
        }


        if (a < b && a < c) {
            min = a;
            System.out.println("Giá trị nhỏ nhất là a: " + a);
        } else {
            if (b < a && b < c) {
                min = b;
                System.out.println("Giá trị nhỏ nhất là b: " + b);
            } else {
                if (c < a && c < b) {
                    min = c;
                    System.out.println("Giá trị nhỏ nhất là c: " + c);
                }
            }
        }
    }
}
