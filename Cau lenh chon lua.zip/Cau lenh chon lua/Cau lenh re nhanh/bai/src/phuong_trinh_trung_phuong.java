import java.util.Scanner;

public class phuong_trinh_trung_phuong {
    public static void main(String[] args) {
        // Khai báo biến
        Scanner sc = new Scanner(System.in);
        float a;
        float b;
        float c;
        double d_delta;
        double x1, x2, x3, x4, x5, x6;


        // Nhập biến số
        System.out.println("Nhập giá trị của a: ");
        a = sc.nextFloat();
        System.out.println("Nhập giá trị của b: ");
        b = sc.nextFloat();
        System.out.println("Nhập giá trị của c: ");
        c = sc.nextFloat();


        // Tính toán
        d_delta = Math.pow(b, 2) - 4 * a * c;


        // Điều kiện
        if (d_delta < 0) {
            System.out.println("Phương trình vô nghiệm");
        } else {
            if (d_delta == 0) {
                x5 = -(Math.sqrt(-b / 2 * a));
                x6 = +(Math.sqrt(-b / 2 * a));
                System.out.println("Phương trình có nghiệm kép: ");
                System.out.println("x5: " + x5);
                System.out.println("x6: " + x6);
            } else {
                if (d_delta > 0) {
                    x1 = -(Math.sqrt((-b + Math.sqrt(d_delta)) / 2 * a));
                    x2 = +(Math.sqrt((-b + Math.sqrt(d_delta)) / 2 * a));
                    x3 = -(Math.sqrt((-b - Math.sqrt(d_delta)) / 2 * a));
                    x4 = +(Math.sqrt((-b - Math.sqrt(d_delta)) / 2 * a));
                    System.out.println("Phương trình có 4 nghiệm phân biệt: ");
                    System.out.println("x1: " + x1);
                    System.out.println("x2: " + x2);
                    System.out.println("x3: " + x3);
                    System.out.println("x4: " + x4);
                }
            }
        }
    }
}
