
import java.util.Scanner;

public class kiem_tra_tinh_chan_le_cua_S_hcn {
    public static void main(String[] args) {
        // Khai báo biến
        Scanner sc = new Scanner(System.in);
        double a;
        double h;
        double s;
        double p;


        // Nhập biến số
        System.out.println("Nhập giá trị cạnh của tam giác: ");
        a = sc.nextDouble();
        System.out.println("Nhập giá trị đường cao của tam giác: ");
        h = sc.nextDouble();


        // Tính toán
        s = 0.5 * (a * h);
        p = (a + h) * 2;


        // Điều kiện
        if (p % 2 == 0)
            System.out.println("Diện tích hình chữ nhật là số chẵn");
        else
            System.out.println("Diện tích hình chữ nhật là số lẻ");


        // In ra kết quả
        System.out.println("Diện tích hình tam giác là: " + s);

    }
}
