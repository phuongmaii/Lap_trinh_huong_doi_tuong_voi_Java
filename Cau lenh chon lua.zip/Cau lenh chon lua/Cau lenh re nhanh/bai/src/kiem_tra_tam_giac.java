import java.util.Scanner;

public class kiem_tra_tam_giac {
    public static void main(String[] args) {
        // Khai báo biến
        Scanner sc = new Scanner(System.in);
        float a, b, c;
        float p;
        double s;


        // Nhập biến số
        System.out.println("Nhập giá trị cạnh a của tam giác: ");
        a = sc.nextFloat();
        System.out.println("Nhập giá trị cạnh b của tam giác: ");
        b = sc.nextFloat();
        System.out.println("Nhập giá trị cạnh c của tam giác: ");
        c = sc.nextFloat();


        // Điều kiện
        if (a + b > c && b + c > a && a + c > b && a > 0 && b > 0 && c > 0) {
            if ((a == b) && (b == c) && (c == a))
                System.out.println("Đây là 3 cạnh của tam giác đều");
            else if ((a == b) || (b == c) || (c == a))
                System.out.println("Dây là 3 cạnh của tam giác cân");
            else if ((a * a == b * b + c * c) || (b * b == a * a + c * c) || (c * c == a * a + b * b))
                System.out.println("Đây là 3 cạnh của tam giác vuông");
            else
                System.out.println("Đây là 3 cạnh của tam giác thường");
        } else
            System.out.println("Đây không là 3 cạnh của 1 tam giác");


        // Tính toán
        p = (a + b + c) / 2;
        s = Math.sqrt(p * (p - a) * (p - b) * (p - c));


        // In ra kết quả
        System.out.println("Nửa chu vi của tam giác là: " + p);
        System.out.println("Diện tích tam giác là: " + s);
    }
}

