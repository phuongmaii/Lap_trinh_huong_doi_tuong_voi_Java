import java.util.Scanner;

public class tinh_gia_tri_bieu_thuc {
    public static void main(String[] args) {
        // Khai báo biến
        Scanner sc = new Scanner(System.in);
        int a, b, c;
        double z;
        double d;


        // Nhập biến số
        System.out.println("Nhập giá trị của a: ");
        a = sc.nextInt();
        System.out.println("Nhập giá trị của b: ");
        b = sc.nextInt();
        System.out.println("Nhập giá trị của c: ");
        c = sc.nextInt();


        // Tính toán
        z = ((a + b) * c * (Math.sin(a) - 1)) / (2 * a * b - c + 7);
        d = 2 * a * b - c + 7;


        // Điều kiện
        if (d == 0) {
            z = 0;
            System.out.println("Giá trị biểu thức là: " + z);
        } else {
            if (d != 0)
                System.out.println("Giá trị biểu thức là: " + z);
        }
    }
}

