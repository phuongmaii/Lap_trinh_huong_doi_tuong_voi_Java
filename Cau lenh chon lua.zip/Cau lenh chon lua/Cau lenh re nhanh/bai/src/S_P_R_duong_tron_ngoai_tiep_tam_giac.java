import java.util.Scanner;

public class S_P_R_duong_tron_ngoai_tiep_tam_giac {
    public static void main(String[] args) {
        // Khai báo biến
        Scanner sc = new Scanner(System.in);
        double a, b, c;
        double p;
        double s;
        double r;


        // Nhập biến số
        System.out.println("Nhập vào giá trị của cạnh a: ");
        a = sc.nextDouble();
        System.out.println("Nhập vào giá trị của cạnh b: ");
        b = sc.nextDouble();
        System.out.println("Nhập vào giá trị của cạnh c: ");
        c = sc.nextDouble();


        // Điều kiện
        if (a > 0 && b > 0 && c > 0 && (a + b > c) && (a + c > b) && (b + c > 0)) {
            if ((a == b) && (a == c) && (b == c))
                System.out.println("Đây là tam giác đều");
            else if ((a == b) || (a == c) || (b == c))
                System.out.println("Đây là tam giác đều");
            else if ((a * a + b * b == c * c) || (a * a + c * c == b * b) || (b * b + c * c == a * a))
                System.out.println("Đây là tam giác vuông");
        } else
            System.out.println("Đây không là 3 cạnh của tam giác");


        // Tính toán
        p = (a + b + c) / 2;
        s = Math.sqrt(p * (p - a) * (p - b) * (p - c));
        r = (a * b * c) / (4 * s);


        // In ra kết quả
        System.out.println("Nửa chu vi của tam giác là: " + p);
        System.out.println("Diện tích của tam giác là: " + s);
        System.out.println("Bán kính đường tròn ngoại tiếp tam giác là: " + r);

    }
}
