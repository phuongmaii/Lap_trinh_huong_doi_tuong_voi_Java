import java.util.Scanner;

public class tinh_va_in_gia_tri_cua_ham {
    public static void main(String[] args) {
        // Khai báo biến
        Scanner sc = new Scanner(System.in);
        double x;
        double f = 0;


        // Nhập biến số
        System.out.println("Nhập giá trị của x: ");
        x = sc.nextDouble();


        // Điều kiện
        if (x < 0.5) {
            f = 2 * (Math.sin(x + 3));
        } else {
            if (x >= 0.5 && x < 13.5) {
                f = (5 * (Math.pow(x, 2))) + x;
            } else {
                if (x >= 13.5) {
                    f = (4 * x) + 7;
                }
            }
        }


        // In ra kết quả
        System.out.println("Giá trị của biểu thức f: " + f);
    }
}
