import java.util.Scanner;

public class tinh_hoc_bong {
    public static void main(String[] args) {
        // Khai báo biến
        Scanner sc = new Scanner(System.in);
        double a;


        // Nhập biến
        System.out.println("Nhập tên sinh viên: ");
        String name = sc.nextLine();
        System.out.println("Nhập điểm trung bình: ");
        a = sc.nextDouble();


        // Điều kiện
        if (a >= 7.0)
            System.out.println("Sinh viên đủ điều kiện nhận học bổng");
        else
            System.out.println("Sinh viên không đủ điều kiện nhận học bổng");


        if (a >= 7.0)
            System.out.println("Giá trị của học bổng là: 80000");
        else
            System.out.println("Giá trị của học bổng là: 0");

    }
}
