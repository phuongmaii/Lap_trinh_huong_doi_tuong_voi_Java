import java.util.Scanner;

public class bien_luan_bieu_thuc {
    public static void main(String[] args) {
        // Khai báo biến
        Scanner sc = new Scanner(System.in);
        double a;
        double b;
        double c;
        double d;
        double x;
        double y;
        double z;


        // Nhập biến số
        System.out.println("Nhập giá trị của a: ");
        a = sc.nextDouble();
        System.out.println("Nhập giá trị của b: ");
        b = sc.nextDouble();
        System.out.println("Nhập giá trị của c: ");
        c = sc.nextDouble();
        System.out.println("Nhập giá trị của d: ");
        d = sc.nextDouble();


        // Tính toán
        x = a + b + c + d;
        y = a * b - c * d;


        // Điều kiện
        if (y == 0) {
            z = 0;
            System.out.println("Giá trị biểu thức là: " + z);
        } else {
            if (x % y == 0) {
                System.out.println("Biểu thức chia hết: ");
                System.out.println("Thương: " + x / y);
            } else {
                System.out.println("Biểu thức không chia hết: ");
                System.out.println("Dư: " + x % y);
            }
        }
    }
}
