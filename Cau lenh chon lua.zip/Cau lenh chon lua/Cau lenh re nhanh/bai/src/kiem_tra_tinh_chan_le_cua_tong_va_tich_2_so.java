
import java.util.Scanner;

public class kiem_tra_tinh_chan_le_cua_tong_va_tich_2_so {
    public static void main(String[] args) {
        // Khai báo biến
        Scanner sc = new Scanner(System.in);
        int a, b;
        int c;
        int d;


        // Nhập biến số
        System.out.println("Nhập giá trị a: ");
        a = sc.nextInt();
        System.out.println("Nhập giá trị b: ");
        b = sc.nextInt();


        // Tính toán
        c = a + b;
        d = a * b;


        // Điều kiện
        if (c % 2 == 0)
            System.out.println("Tổng hai số là giá trị chẵn");
        else
            System.out.println("Tổng hai số là giá trị lẻ");
        if (d % 2 == 0)
            System.out.println("Tích hai số là giá trị chẵn");
        else
            System.out.println("Tích hai số là giá trị lẻ");
    }
}
