import java.util.Scanner;

public class phuong_trinh_bac_2 {
    public static void main(String[] args) {
        // Khai báo biến
        Scanner sc = new Scanner(System.in);
        double a;
        double b;
        double c;
        double x;
        double x1;
        double x2;
        double d_delta;


        // Nhập biến số
        System.out.println("Giá trị của a: ");
        a = sc.nextDouble();
        System.out.println("Giá trị của b: ");
        b = sc.nextDouble();
        System.out.println("Giá trị của c: ");
        c = sc.nextDouble();


        // Tính toán
        d_delta = Math.pow(b, 2) - 4 * a * c;


        // Điều kiện
        if (d_delta < 0) {
            System.out.println("Phương trình vô nghiệm ");
        } else {
            if (d_delta == 0) {
                x = x1 = x2 = -b / 2 * a;
                System.out.println("Phương trình có nghiệm kép: " + x);
            } else {
                if (d_delta > 0) {
                    x1 = (-b + Math.sqrt(d_delta)) / (2 * a);
                    x2 = (-b - Math.sqrt(d_delta)) / (2 * a);
                    System.out.println("Phương trình có 2 nghiệm phân biệt: ");
                    System.out.println("x1: " + x1);
                    System.out.println("x2: " + x2);
                }
            }

        }
    }
}
