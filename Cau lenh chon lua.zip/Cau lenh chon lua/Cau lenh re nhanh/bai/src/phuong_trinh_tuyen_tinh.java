import java.util.Scanner;

public class phuong_trinh_tuyen_tinh {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Nhập các hệ số và các hằng số từ bàn phím
        System.out.println("Nhập các hệ số và các hằng số:");
        System.out.print("a = ");
        double a = sc.nextDouble();
        System.out.print("b = ");
        double b = sc.nextDouble();
        System.out.print("m = ");
        double m = sc.nextDouble();
        System.out.print("c = ");
        double c = sc.nextDouble();
        System.out.print("d = ");
        double d = sc.nextDouble();
        System.out.print("n = ");
        double n = sc.nextDouble();

        // Tính định thức của ma trận hệ số
        double determinant = a * d - b * c;

        // Kiểm tra nếu định thức khác 0 (tức là hệ có nghiệm duy nhất)
        if (determinant != 0) {
            // Tính nghiệm x và y
            double x = (m * d - b * n) / determinant;
            double y = (a * n - m * c) / determinant;

            // In kết quả
            System.out.println("Nghiệm của hệ phương trình là:");
            System.out.println("x = " + x);
            System.out.println("y = " + y);
        } else {
            // Trường hợp hệ phương trình vô nghiệm hoặc có vô số nghiệm
            if ((a / c == b / d) && (b / d == m / n)) {
                System.out.println("Hệ phương trình có vô số nghiệm");
            } else {
                System.out.println("Hệ phương trình vô nghiệm");
            }
        }
    }
}