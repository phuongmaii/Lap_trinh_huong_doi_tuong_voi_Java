import java.util.Scanner;

public class may_noi_chuyen_voi_nguoi {
    public static void main(String[] args) {

        // Khai báo biến
        Scanner sc = new Scanner(System.in);


        // Nhập biến
        System.out.println("Bạn đã có gia đình chưa: ");
        String a = sc.nextLine();


        // Câu lệnh switch
        switch (a) {
            case "chưa":
                System.out.println("Bạn hãy bình tĩnh! ");
                break;
            default:
                System.out.println("Bạn có mấy con? ");
                int b;
                b = sc.nextInt();
                switch (b) {
                    case 3:
                        System.out.println("Bạn có hơi nhiều con! ");
                        break;
                    default:
                        if (b > 3)
                            System.out.println("Bạn có nhiều con quá! ");
                }
        }
    }
}

