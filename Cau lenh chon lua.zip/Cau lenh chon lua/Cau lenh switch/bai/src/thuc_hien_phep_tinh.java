import java.util.Scanner;

public class thuc_hien_phep_tinh {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Nhập biến số
        double a;
        double b;
        char ki_tu;
        double ket_qua = 0;


        System.out.println("Nhập số a: ");
        a = sc.nextDouble();
        System.out.println("Nhập số b: ");
        b = sc.nextDouble();
        System.out.println("Nhập kí tự: ");
        ki_tu = sc.next().charAt(0);


        // Câu lệnh switch
        switch (ki_tu) {
            case '+':
                ket_qua = a + b;
                break;
            case '-':
                ket_qua = a - b;
                break;
            case '*':
                ket_qua = a * b;
                break;
            case '/':
                ket_qua = a / b;
                break;
            default:
                System.out.println("Kí tự không hợp lệ");
        }
        System.out.println("Kết quả phép tính: " + ket_qua + "");
    }
}
