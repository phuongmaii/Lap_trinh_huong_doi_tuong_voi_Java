import java.util.Scanner;

public class kiem_tra_ngay_thang_nam {
    public static void main(String[] args) {
        // Khai báo biến
        Scanner sc = new Scanner(System.in);
        int a;
        int b;
        int so_ngay;


        // Nhập biến số
        System.out.println("Nhập vào năm: ");
        a = sc.nextInt();
        System.out.println("Nhập vào tháng: ");
        b = sc.nextInt();


        // Câu điều kiện kiểm tra năm nhuận
        if ((a % 400 == 0) || (a % 4 == 0 && a % 100 != 0)) {
            System.out.println("Đây là năm nhuận");
        } else {
            System.out.println("Đây là năm không nhuận");
        }


        // Câu lệnh switch
        switch (b) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                so_ngay = 31;
                System.out.println("Tháng có 31 ngày");
                break;
            case 4:
            case 6:
            case 9:
            case 11:
                so_ngay = 30;
                System.out.println("Tháng có 30 ngày");
                break;
            case 2: // Kiểm tra tháng của tháng nhuận
                if ((a % 400 == 0) || (a % 4 == 0 && a % 100 != 0)) {
                    so_ngay = 29;
                    System.out.println("Tháng có 29 ngày");
                } else {
                    so_ngay = 28;
                    System.out.println("Tháng có 28 ngày");
                }
                break;
            default:
                System.out.println("Dữ liệu tháng nhập vào không hợp lệ!");
        }

    }
}
