import java.util.Scanner;

public class kiem_tra_ki_tu {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Khai báo
        System.out.println("Mời bạn nhập kí tự: ");
        char ki_tu = sc.next().charAt(0);

        String a = null;


        // Câu lệnh switch
        switch (ki_tu) {
            case 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z':
                a = "Chữ hoa";
                break;
            case 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z':
                a = "Chữ thường";
                break;
            case '0', '1', '2', '3', '4', '5', '6', '7', '8', '9':
                a = "Chữ số";
                break;
            default:
                System.out.println("Kí tự nhập không hợp lệ");
        }


        // In ra kết quả
        System.out.println("Đây là kí tự: " + a + " ");
    }
}
