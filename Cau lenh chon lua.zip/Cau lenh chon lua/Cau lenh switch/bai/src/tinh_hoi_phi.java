import java.util.Scanner;

public class tinh_hoi_phi {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Nhập thông tin về nước
        System.out.print("Nhập tên của nước: ");
        String tenNuoc = scanner.nextLine();
        System.out.print("Nhập loại của nước (từ 1 đến 5): ");
        int loaiNuoc = scanner.nextInt();
        System.out.print("Nhập tổng thu nhập quốc gia (đơn vị: triệu đô la): ");
        double tongThuNhap = scanner.nextDouble();

        // Tính số tiền phải đóng góp
        double soTienPhaiDong = tinhSoTien(loaiNuoc, tongThuNhap);

        // In ra màn hình
        System.out.println("Tên nước: " + tenNuoc);
        System.out.println("Số tiền phải đóng góp: " + soTienPhaiDong + " triệu đô la");

        scanner.close();
    }

    // Hàm tính số tiền phải đóng góp
    public static double tinhSoTien(int loaiNuoc, double tongThuNhap) {
        double soTienPhaiDong = 0;
        switch (loaiNuoc) {
            case 1:
                soTienPhaiDong = tongThuNhap * 0.01;
                break;
            case 2:
                soTienPhaiDong = tongThuNhap * 0.007;
                break;
            case 3:
                soTienPhaiDong = tongThuNhap * 0.005;
                break;
            case 4:
                soTienPhaiDong = tongThuNhap * 0.001;
                break;
            case 5:
                soTienPhaiDong = 1_000_000; // 1 triệu đô la
                break;
            default:
                System.out.println("Loại nước không hợp lệ.");
                break;
        }
        return soTienPhaiDong;
    }
}
