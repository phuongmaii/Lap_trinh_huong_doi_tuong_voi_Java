import java.util.Scanner;

public class tet_giap_thin_2024 {
    public static void main(String[] args) {
        // Khai báo biến
        Scanner sc = new Scanner(System.in);
        double a;

        // Nhập biến số
        System.out.println("Xin mời nhập năm: ");
        a = sc.nextDouble();


        // In ra màn hình
        System.out.println("Chúc mừng năm mới!");

    }
}
