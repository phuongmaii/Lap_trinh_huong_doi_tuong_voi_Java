import java.util.Scanner;

public class tinh_bieu_thuc_can_bac_n {
    public static void main(String[] args) {
        // Khai báo biến
        Scanner sc = new Scanner(System.in);
        double x;
        double n;
        double s;


        // Nhập biến số
        System.out.println("Nhập giá trị của x: ");
        x = sc.nextDouble();
        System.out.println("Nhập giá trị của n: ");
        n = sc.nextDouble();


        // Tính toán
        s = Math.pow(x, 1 / n);
        if (x < 0) {
            System.out.println("Dữ liệu không hợp lệ: ");
        }


        // In ra màn hình
        System.out.println("Giá trị của biểu thức: " + s);
    }
}

