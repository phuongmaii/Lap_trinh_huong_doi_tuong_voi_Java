import java.util.Scanner;

public class dien_tich_va_chu_vi_hcn {
    public static void main(String[] args) {
        // Khai báo biến
        Scanner sc = new Scanner(System.in);
        double a;
        double b;
        double c;
        double s;
        double p;


        // Nhập biến số
        System.out.println("Giá trị cạnh a: ");
        a = sc.nextDouble();
        System.out.println("Giá trị cạnh b: ");
        b = sc.nextDouble();


        // Tính toán
        s = a * b;
        p = (a + b) * 2;
        c = Math.sqrt(Math.pow(a, 2) + Math.pow(b, 2));


        // In ra màn hình
        System.out.println("Diện tích hình chữ nhật: " + s);
        System.out.println("Chu vi hìnhn chữ nhật: " + p);
        System.out.println("Đường chéo của hình chữ nhật: " + c);

    }
}
