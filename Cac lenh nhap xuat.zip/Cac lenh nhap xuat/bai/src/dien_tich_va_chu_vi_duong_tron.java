import java.util.Scanner;

public class dien_tich_va_chu_vi_duong_tron {
    public static void main(String[] args) {
        // Khai báo biến
        Scanner sc = new Scanner(System.in);
        double r;
        double s;
        double p;


        // Nhập biến số
        System.out.println("Nhập giá trị của r: ");
        r = sc.nextDouble();


        // Tính toán
        s = 3.14 * Math.pow(r, 2);
        p = 2 * 3.14 * r;

        // In ra màn hình
        System.out.println("Diện tích hình tròn: " + s);
        System.out.println("Chu vi hình tròn: " + p);
    }
}
