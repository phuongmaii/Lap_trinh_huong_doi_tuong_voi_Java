
import java.util.Scanner;

public class demo {
    public static void main(String[] args) {
        // Khai báo 3 biến a, b, c không có giá trị
        int a, b, c;
        // khai báo đối tượng Scanner
        // Giúp chúng ta nhận thông tin từ keyboard
        Scanner sc = new Scanner(System.in);
        System.out.print("Nhập a: ");
        a = sc.nextInt();
        // sc.nextInt() là cách lấy giá trị từ bàn phím
        // nó sẽ chờ tới khi chúng ta nhập 1 số
        System.out.print("Nhập b: ");
        b = sc.nextInt();
        System.out.print("Nhập c: ");
        c = sc.nextInt();
        // In tất cả giá trị ra màn hình
        System.out.println("a = " + a + ", b = " + b + ", c = " + c);
    }
}
