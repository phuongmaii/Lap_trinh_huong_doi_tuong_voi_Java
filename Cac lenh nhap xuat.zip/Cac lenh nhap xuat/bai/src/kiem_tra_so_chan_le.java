import java.util.Scanner;

public class kiem_tra_so_chan_le {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a;
        System.out.println("Nhập a: ");
        a = sc.nextInt();
        if (a % 2 == 0)
            System.out.println("Số đó là số chẵn: " + a);
        else
            System.out.println("Số đó là số lẻ: " + a);
    }
}
