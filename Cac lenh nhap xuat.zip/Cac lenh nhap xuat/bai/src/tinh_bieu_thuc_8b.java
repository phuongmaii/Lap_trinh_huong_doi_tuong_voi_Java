import java.util.Scanner;

public class tinh_bieu_thuc_8b {
    public static void main(String[] args) {
        // Khai báo biến
        Scanner sc = new Scanner(System.in);
        double a;
        double b;
        double c;
        double h;
        double r;
        double s;


        // Nhập biến số
        System.out.println("Nhập giá trị của a:");
        a = sc.nextDouble();
        System.out.println("Nhập giá trị của b: ");
        b = sc.nextDouble();
        System.out.println("Nhập giá trị của c: ");
        c = sc.nextDouble();
        System.out.println("Nhập giá trị của h: ");
        h = sc.nextDouble();
        System.out.println("Nhập giá trị của r: ");
        r = sc.nextDouble();


        // Tính toán
        s = ((a + 4) * (b - 2 * c + 3)) / ((r / (2 * h)) - (9 * (a - 1)));


        // In ra màn hình
        System.out.println("Giá trị của biểu thức: " + s);

    }
}
