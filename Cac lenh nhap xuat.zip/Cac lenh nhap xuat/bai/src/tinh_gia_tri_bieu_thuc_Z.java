import java.util.Scanner;

public class tinh_gia_tri_bieu_thuc_Z {
    public static void main(String[] args) {
        // Khai báo biến
        Scanner sc = new Scanner(System.in);
        float a;
        float x;
        double Z;


        // Nhập biến số
        System.out.println("Nhập giá trị của a: ");
        a = sc.nextFloat();
        System.out.println("Nhập giá trị của x: ");
        x = sc.nextFloat();


        // Tính toán
        Z = Math.exp(a + Math.pow(Math.sin(x), 2) - x);


        // In ra màn hình
        System.out.println("Giá trị của biểu thức Z: " + Z);
    }
}
