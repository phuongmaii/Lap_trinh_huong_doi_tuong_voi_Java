import java.util.Scanner;

public class tinh_gia_tri_bieu_thuc_S {
    public static void main(String[] args) {
        // Khai báo biến
        Scanner sc = new Scanner(System.in);
        float x;
        float y;
        double S;


        // Nhập biến số
        System.out.println("Nhập giá trị của x: ");
        x = sc.nextFloat();
        System.out.println("Nhập giá trị của y: ");
        y = sc.nextFloat();


        // Tính toán
        S = Math.pow(x, y);


        // In ra màn hình
        System.out.println("Giá trị của S: " + S);
    }
}
