import java.util.Scanner;

public class do_cao_va_tam_xa_cua_bong {
    public static void main(String[] args) {
        // Khai báo biến
        Scanner sc = new Scanner(System.in);
        double v;
        double t;
        double h;
        double s;
        double g = 9.8;


        // Nhập biến số
        System.out.println("Vận tốc của bóng: ");
        v = sc.nextDouble();
        System.out.println("Thời gian bóng chuyển động: ");
        t = sc.nextDouble();


        // Tính toán
        s = v * t;
        h = (g * Math.pow(t, 2)) / 2;


        // In ra màn hình
        System.out.println("Tầm xa của bóng: " + s);
        System.out.println("Độ cao của bóng: " + h);
    }
}
