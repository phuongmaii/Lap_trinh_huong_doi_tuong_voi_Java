
import java.util.Scanner;

public class khoang_cach_tu_1_diem_den_duong_thang {
    public static void main(String[] args) {
        // Khai báo biến
        Scanner sc = new Scanner(System.in);
        double A;
        double B;
        double C;
        double xi;
        double yi;
        double h;


        // Nhập biến số
        System.out.println("Nhập giá trị của A: ");
        A = sc.nextDouble();
        System.out.println("Nhập giá trị của B: ");
        B = sc.nextDouble();
        System.out.println("Nhập giá trị của C: ");
        C = sc.nextDouble();
        System.out.println("Nhập giá trị xi của toạ độ I: ");
        xi = sc.nextDouble();
        System.out.println("Nhập giá trị yi của toạ độ I: ");
        yi = sc.nextDouble();


        // Tính toán
        h = (A * xi + B * yi + C) / (Math.sqrt(A * A + B * B));


        // In ra màn hình
        System.out.println("Khoảng cách từ điểm I đến phương trình đoạn thẳng: " + h);
    }
}
