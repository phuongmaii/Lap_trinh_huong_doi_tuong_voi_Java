import java.util.Scanner;

public class tinh_bieu_thuc_8a {
    public static void main(String[] args) {
        // Khai báo biến
        Scanner sc = new Scanner(System.in);
        double x;
        double y;
        double s;


        // Nhập biến số
        System.out.println("Nhập giá trị của x: ");
        x = sc.nextDouble();
        System.out.println("Nhập giá trị của y: ");
        y = sc.nextDouble();


        // Tính toán
        s = (x + y) / (2 + (x / y));


        // In ra màn hình
        System.out.println("Giá trị của biểu thức: " + s);
    }
}
