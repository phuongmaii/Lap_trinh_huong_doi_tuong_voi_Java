// Sử dụng biến trung gian

import java.util.Scanner;

public class hoan_doi_2_so {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);


        // Có sử dụng biến trung gian

        // Nhập hai số từ bàn phím
        System.out.print("Nhập số thứ nhất (a): ");
        int a = sc.nextInt();
        System.out.print("Nhập số thứ hai (b): ");
        int b = sc.nextInt();

        // Hiển thị giá trị trước khi hoán đổi
        System.out.println("Giá trị trước khi hoán đổi:");
        System.out.println("a = " + a);
        System.out.println("b = " + b);

        // Hoán đổi giá trị
        int temp = a;
        a = b;
        b = temp;

        // Hiển thị giá trị sau khi hoán đổi
        System.out.println("Giá trị sau khi hoán đổi:");
        System.out.println("a = " + a);
        System.out.println("b = " + b);


        // Không sử dụng biến trung gian

        // Nhập hai số từ bàn phím
        System.out.print("Nhập số thứ nhất (x): ");
        int x = sc.nextInt();
        System.out.print("Nhập số thứ hai (y): ");
        int y = sc.nextInt();

        // Hiển thị giá trị trước khi hoán đổi
        System.out.println("Giá trị trước khi hoán đổi:");
        System.out.println("x = " + x);
        System.out.println("y = " + y);

        // Hoán đổi giá trị
        x = x + y;
        y = x - y;
        x = x - y;

        // Hiển thị giá trị sau khi hoán đổi
        System.out.println("Giá trị sau khi hoán đổi:");
        System.out.println("x = " + x);
        System.out.println("y = " + y);
    }
}