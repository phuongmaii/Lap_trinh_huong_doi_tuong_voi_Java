import java.util.Scanner;

public class tinh_bieu_thuc_8c {
    public static void main(String[] args) {
        // Khai báo biến
        Scanner sc = new Scanner(System.in);
        double a;
        double x;
        double s;


        // Nhập biến số
        System.out.println("Nhập giá trị của a: ");
        a = sc.nextDouble();
        System.out.println("Nhập giá trị của x: ");
        x = sc.nextDouble();


        // Tính toán
        s = Math.sqrt(Math.abs(a + Math.pow(Math.sin(x), 2) - x));


        // In kết quả ra màn hình
        System.out.println("Giá trị của biểu thức: " + s);
    }
}
