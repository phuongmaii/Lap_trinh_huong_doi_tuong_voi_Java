// Loi super phan constructor
import java.util.Scanner;
import java.util.Arrays;
import java.util.Comparator;         // Sap xep 1 tap hop


class SanPham {
    // SanPham la lop cha
    // class: viet hoa chu cai dau tien trong cac tu ghep lai

    private String maSanPham;
    // Thuoc tinh bat dau bang chu thuong, viet hoa chu cai dau tien trong cac tu con lai
    private String tenSanPham;
    private int soLuong;
    private int namNhap;


    // Constructor
    public String getMaSanPham() {
        return maSanPham;
    }

    public void setMaSanPham(String maSanPham) {
        this.tenSanPham = maSanPham;
    }

    public String getTenSanPham() {
        return tenSanPham;
    }

    public void setTenSanPham(String tenSanPham) {
        this.tenSanPham = tenSanPham;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public int getNamNhap() {
        return namNhap;
    }

    public void setNamNhap(int namNhap) {
        this.namNhap = namNhap;
    }


    // Phuong thuc nhap thong tin san pham

    public void input() {
        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap ma san pham: ");
        maSanPham = sc.nextLine();

        System.out.println("Nhap ten san pham: ");
        tenSanPham = sc.nextLine();

        System.out.println("Nhap so luong: ");
        soLuong = sc.nextInt();

        System.out.println("Nhap nam nhap: ");
        namNhap = sc.nextInt();
    }


    // Phuong thuc hien thi thong tin da nhap

    public void output() {

        System.out.println("Ma san pham: " + maSanPham);

        System.out.println("Ten san pham: " + tenSanPham);

        System.out.println("So luong: " + soLuong);

        System.out.println("Nam nhap: " + namNhap);
    }
}


class SP_Phanmem extends SanPham {
    // Lop SP_Phanmem duoc ke thua tu lop SanPham

    private String nganhUngDung;
    private String maKey;


    // Constructor
    public SP_Phanmem(String maSanPham, String tenSanPham, int soLuong, int namNhap, String nganhUngDung, String maKey) {
        super(maSanPham, tenSanPham, soLuong, namNhap);
        this.nganhUngDung = nganhUngDung;
        this.maKey = maKey;
    }


    // Get/set

    public String getNganhUngDung() {
        return nganhUngDung;
    }

    public void setNganhUngDung(String nganhUngDung) {
        this.nganhUngDung = nganhUngDung;
    }

    public String getMaKey() {
        return maKey;
    }

    public void setMaKey(String maKey) {
        this.maKey = maKey;
    }


    // Override cho phuong thuc input
    @Override

    public void input() {
        super.input();

        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap nganh ung dung: ");
        nganhUngDung = sc.nextLine();

        System.out.println("Nhap ma key: ");
        maKey = sc.nextLine();
    }


    // Override cho phuong thuc output
    @Override

    public void output() {

        Scanner sc = new Scanner(System.in);

        System.out.println("Nganh ung dung: " + nganhUngDung);

        System.out.println("Ma key: " + maKey);
    }
}


public class main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap so luong san pham phan mem: ");
        int n = Integer.parseInt(sc.nextLine());

        // Khai bao mang chua cac san pham phan mem
        SP_Phanmem[] dsSP = new SP_Phanmem[n];

        // Nhap thong tin cho tung san pham phan mem
        for (int i = 0; i < n; i++) {
            System.out.println("Nhap thong tin san pham phan mem thu " + (i + 1) + " ");
            dsSP[i] = new SP_Phanmem("", "", 0, 0, "", "");
            dsSP[i].input();
        }


        // In danh sach cac san pham vua nhap ra man hinh
        System.out.println("Danh sach san pham phan mem vua nhap: ");
        for (SP_Phanmem sp : dsSP) {
            sp.output();
            System.out.println();
        }


        // Sap xep cac phan mem nhap theo thu tu lon nho so luong
        Arrays.sort(dsSP, new Comparator<SP_Phanmem>() {
            @Override
            public int compare(SP_Phanmem o1, SP_Phanmem o2) {
                return 0;
            }
        });


        // In ra danh sach cac san pham phan mem sau khi sap xep
        System.out.println("Danh sach cac san pham phan mem sau khi sap xep theo thu tu: ");
        for (SP_Phanmem sp : dsSP) {
            sp.output();
            System.out.println();
        }


        // Tim san pham co nam nhap lau nhat
        int maxNamNhap = dsSP[0].getNamNhap();
        SP_Phanmem spNamNhapLauNhat = dsSP[0];
        for (int i = 1; i < n; i++) {
            if (dsSP[i].getNamNhap() > maxNamNhap) {
                maxNamNhap = dsSP[i].getNamNhap();
                spNamNhapLauNhat = dsSP[i];
            }
        }


        // In thong tin san pham phan mem co thoi gian nhap lau nhat
        System.out.println("San pham co nam nhap lau nhat: ");
        spNamNhapLauNhat.output();
    }
}