import java.util.Scanner;
import java.util.Comparator;
import java.util.Arrays;
// DHT

class SinhVien {
    private String maSinhVien;
    private String hoTen;
    private String lop;
    private String chuyenNganh;
    private String diaChi;
    private String soDienThoai;
    private double diemTrungBinh;


    // Constructor
    public SinhVien(String maSinhVien, String hoTen, String lop, String chuyenNganh, String diaChi, String soDienThoai, double diemTrungBinh) {
        this.maSinhVien = maSinhVien;
        this.hoTen = hoTen;
        this.lop = lop;
        this.chuyenNganh = chuyenNganh;
        this.diaChi = diaChi;
        this.soDienThoai = soDienThoai;
        this.diemTrungBinh = diemTrungBinh;
    }


    // get/set
    public String getMaSinhVien() {
        return maSinhVien;
    }

    public void setMaSinhVien(String maSinhVien) {
        this.maSinhVien = maSinhVien;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public String getLop() {
        return lop;
    }

    public void setLop(String lop) {
        this.lop = lop;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    public String getSoDienThoai() {
        return soDienThoai;
    }

    public void setSoDienThoai(String soDienThoai) {
        this.soDienThoai = soDienThoai;
    }

    public double getDiemTrungBinh() {
        return diemTrungBinh;
    }

    public void setDiemTrungBinh(double diemTrungBinh) {
        this.diemTrungBinh = diemTrungBinh;
    }

    // Input
    public void input() {

        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap ma sinh vien: ");
        maSinhVien = sc.next();
        System.out.println("Nhap ho ten: ");
        hoTen = sc.next();
        System.out.println("Nhap lop: ");
        lop = sc.next();
        System.out.println("Nhap chuyen nganh: ");
        chuyenNganh = sc.next();
        System.out.println("Nhap dia chi: ");
        diaChi = sc.next();
        System.out.println("Nhap so dien thoai: ");
        soDienThoai = sc.next();
        System.out.println("Nhap diem trung binh: ");
        diemTrungBinh = sc.nextDouble();
    }


    // Output
    public void output() {

        System.out.println("Ma sinh vien: " + maSinhVien);
        System.out.println("Ho ten: " + hoTen);
        System.out.println("Lop: " + lop);
        System.out.println("Chuyen nganh: " + chuyenNganh);
        System.out.println("Dia chi: " + diaChi);
        System.out.println("So dien thoai: " + soDienThoai);
        System.out.println("Diem trung binh: " + diemTrungBinh);
    }
}


// Lop hoc vien ke thua tu lop sinh vien
class HocVien extends SinhVien {
    private String hinhThucDaoTao;
    private String trinhDoNgoaiNgu;


    // Constructor
    public HocVien(String maSinhVien, String hoTen, String lop, String chuyenNganh, String diaChi, String soDienThoai, double diemTrungBinh, String hinhThucDaoTao, String trinhDoNgoaiNgu) {
        super(maSinhVien, hoTen, lop, chuyenNganh, diaChi, soDienThoai, diemTrungBinh);
        this.hinhThucDaoTao = hinhThucDaoTao;
        this.trinhDoNgoaiNgu = trinhDoNgoaiNgu;
    }


    // get/set
    public String getHinhThucDaoTao() {
        return hinhThucDaoTao;
    }

    public void setHinhThucDaoTao(String hinhThucDaoTao) {
        this.hinhThucDaoTao = hinhThucDaoTao;
    }

    public String getTrinhDoNgoaiNgu() {
        return trinhDoNgoaiNgu;
    }

    public void setTrinhDoNgoaiNgu(String trinhDoNgoaiNgu) {
        this.trinhDoNgoaiNgu = trinhDoNgoaiNgu;
    }


    // Override input
    @Override
    public void input() {
        super.input();

        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap hinh thuc dao tao: ");
        hinhThucDaoTao = sc.next();
        System.out.println("Nhap trinh do ngoai ngu: ");
        trinhDoNgoaiNgu = sc.next();
    }


    // Override output
    @Override
    public void output() {
        super.output();

        System.out.println("Hinh thuc dao tao: " + hinhThucDaoTao);
        System.out.println("Trinh do ngoai ngu: " + trinhDoNgoaiNgu);
    }
}


// Viet ra chuong trinh thuc hien
public class main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);


        // a. Nhap danh sach n hoc vien
        System.out.println("Nhap danh sach hoc vien: ");
        int n = Integer.parseInt(sc.nextLine());

        // Khoi tao mang chua n hoc vien
        HocVien[] dsHV = new HocVien[n];

        // Nhap thong tin cho tung hoc vien
        for (int i = 0; i < n; i++) {
            System.out.println("Hoc vien thu " + (i + 1) + " ");
            dsHV[i] = new HocVien("a1" + i, "nvc" + i, "b" + i, "ac" + i, "x" + i, "098765432" + i, 5.6 + i, "c" + i, "b1" + i);
            //dsHV[i] = new HocVien("", "", "", "", "", 0, 0, "", "");
            //dsHV[i].input();
        }
        while (true) {
            System.out.println("--------------------------------------------------------------------");
            System.out.println("--------------------------------MENU--------------------------------");
            System.out.println("1. In danh sach cac hoc vien vua nhap ra man hinh");
            System.out.println("2. Dem so hoc vien co trinh do ngoai ngu B1");
            System.out.println("3. Sap xep hoc vien theo thu tu giam dan cua diem trung binh");
            System.out.println("0. Ket thuc chuong trinh");
            System.out.println("--------------------------------------------------------------------");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("--------------------------------------------------------------------");
                    // b. In danh sach giang vien ra man hinh
                    System.out.println("Danh sach hoc vien vua nhap");
                    for (HocVien hv : dsHV) {
                        hv.output();
                        System.out.println();
                    }
                    break;
                case 2:
                    System.out.println("--------------------------------------------------------------------");


                    // c. Dem so hoc vien co trinh do ngoai ngu B1
                    int dem = 0;
                    for (int i = 0; i < n; i++) {
                        var hocvien = dsHV[i];
                        if (hocvien.getTrinhDoNgoaiNgu().equalsIgnoreCase("B1")) {
                            dem++;
                        }
                    }
                    System.out.println("So luong hoc vien co trinh do ngoai ngu B1 " + dem);
                    break;


                case 3:
                    System.out.println("--------------------------------------------------------------------");
                    // d. Sap xep hoc vien theo thu tu giam dan cua diem trung binh
                    for (int i = 0; i < n; i++) {
                        for (int j = i; j < n; j++) {
                            if (dsHV[i].getDiemTrungBinh() < dsHV[j].getDiemTrungBinh()) {
                                HocVien hv = dsHV[i];
                                dsHV[i] = dsHV[j];
                                dsHV[j] = hv;
                            }
                        }
                    }
                    System.out.println("Danh sach hoc vien co muc diem trung binh giam dan");
                    for (int i = 0; i < n; i++) {
                        System.out.println("Ma sinh vien: " + dsHV[i].getMaSinhVien());
                        System.out.println("Ho ten: " + dsHV[i].getHoTen());
                        System.out.println("Diem trung binh: " + dsHV[i].getDiemTrungBinh());
                    }
                    break;
                case 0:
                    System.out.println("--------------------------------------------------------------------");
                    System.out.println("Ket thuc chuong trinh");
                    break;
                default:
                    System.out.println("--------------------------------------------------------------------");
                    System.out.println("Lua chon khong dung, vui long chon lai");
            }
        }
    }
}