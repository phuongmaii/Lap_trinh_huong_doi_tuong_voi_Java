import tiendien.HoaDon;

import java.util.Scanner;
// Tinh tien dien


public class ChuHo_HoaDonTienDien {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // a. Nhap danh sach hoa don, hien thi thong tin ve hoa don nhap
        System.out.println("Nhap danh sach hoa don: ");
        int n = Integer.parseInt(sc.nextLine());

        // Khoi tao mang chua n hoa don
        HoaDon[] dsHD = new HoaDon[n];

        // Nhap thong tin ve cac hoa don
        for (int i = 0; i < n; i++) {
            System.out.println("Hoa don thu " + (i + 1) + " ");
            //dsHD[i] = new HoaDon("ac" + i, "c" + i, 12 + i, "avd" + i, 30 + i, 12 + i, 5 + i);
            dsHD[i] = new HoaDon();
            dsHD[i].input();
        }
        while (true) {
            System.out.println("------------------------------------------------------------");
            System.out.println("----------------------------MENU----------------------------");
            System.out.println("1. In danh sach hoa don vua nhap ra man hinh");
            System.out.println("2. Tim kiem hoa don cho khach hang voi danh sach khach hang nhap tu ban phim");
            System.out.println("3. Danh sach khach hang co hoa don tien dien > 2tr/thang");
            System.out.println("4. Danh sach khach hang co hoa don tien dien giam dan");
            System.out.println("0. Ket thuc chuong trinh");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("------------------------------------------------------------");
                    // In ra danh sach hoa don
                    System.out.println("Danh sach hoa don: ");
                    for (HoaDon hd : dsHD) {
                        hd.output();
                        System.out.println();
                    }
                    break;
                case 2:
                    System.out.println("------------------------------------------------------------");

                    // b. Tim kiem hoa don cho khach hang voi ma khach hang nhap tu ban phim
                    // Nhap ma hoa don
                    System.out.println("Ma khach hang: ");
                    String maKhachHang = sc.next();
                    // In ra hoa don
                    System.out.println("Hoa don: ");
                    for (int i = 0; i < n; i++) {
                        if (dsHD[i].getMaKhachHang().equals(maKhachHang)) {
                            System.out.println("Ma khach hang: " + dsHD[i].getMaKhachHang());
                            System.out.println("Ten chu ho: " + dsHD[i].getHoTenChuHo());
                            System.out.println("So tien phai tra: " + dsHD[i].tinhTien() + "VND");
                        }
                    }
                    break;
                case 3:
                    System.out.println("------------------------------------------------------------");


                    // c. Loi cong to khi chi so moi nho hon chi so cu


                    // c. Danh sach khach hang su dung tien dien lon hon 2tr/1 thang
                    System.out.println("Danh sach khach hang co hoa don lon hon 2tr/1 thang");
                    for (int i = 0; i < n; i++) {
                        if (dsHD[i].tinhTien() > 2000000) {
                            dsHD[i].output();
                            System.out.println();
                /*System.out.println("Ma khach hang: " + dsHD[i].getMaKhachHang());
                System.out.println("Ten chu ho: " + dsHD[i].getHoTenChuHo());
                System.out.println("So tien phai tra: " + dsHD[i].tinhTien() + "VND");

                 */
                        }
                    }
                    break;
                case 4:
                    System.out.println("------------------------------------------------------------");

                    // d. Sap xep danh sach theo thu tu giam dan cua tien dien
                    System.out.println("Danh sach khach hang co hoa don tien dien theo thu tu giam dan ");
                    for (int i = 0; i < n; i++) {
                        for (int j = i; j < n; j++) {
                            if (dsHD[i].tinhTien() < dsHD[j].tinhTien()) {
                                HoaDon tienDien = dsHD[i];
                                dsHD[i] = dsHD[j];
                                dsHD[j] = tienDien;
                                //dsHD[i].output();
                                //System.out.println();
                            }
                        }
                    }
                    for (int i = 0; i < n; i++) {
                        System.out.println("Ma khach hang: " + dsHD[i].getMaKhachHang());
                        System.out.println("Ten chu ho: " + dsHD[i].getHoTenChuHo());
                        System.out.println("So tien phai tra: " + dsHD[i].tinhTien() + "VND");
                    }
                    break;
                case 0:
                    System.out.println("------------------------------------------------------------");
                    System.out.println("Ket thuc chuong trinh");
                    break;
                default:
                    System.out.println("------------------------------------------------------------");
                    System.out.println("Lua chon khong dung, vui long chon lai!");
        /*
        System.out.println("Ma khach hang: " + dsHD[i].getMaKhachHang());
        System.out.println("Ten chu ho: " + dsHD[i].getHoTenChuHo());
        System.out.println("So tien phai tra: " + dsHD[i].tinhTien() + "VND");

         */
            }
        }
    }
}