package tiendien;

public class LoiCongTo extends HoaDon {
    public LoiCongTo() {
    }
}