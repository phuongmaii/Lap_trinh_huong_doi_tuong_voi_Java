package tiendien;
// DHT

import java.util.Scanner;

class KhachHang {
    private String maKhachHang;
    private String hoTenChuHo;
    private int soNha;
    private String maSoCongTo;


    // Constructor khong co tham so
    public KhachHang() {

    }


    // Constructor co tham so
    public KhachHang(String maKhachHang, String hoTenChuHo, int soNha, String maSoCongTo) {
        this.maKhachHang = maKhachHang;
        this.hoTenChuHo = hoTenChuHo;
        this.soNha = soNha;
        this.maSoCongTo = maSoCongTo;
    }


    // get/set

    public String getMaKhachHang() {
        return maKhachHang;
    }

    public void setMaKhachHang(String maKhachHang) {
        this.maKhachHang = maKhachHang;
    }

    public String getHoTenChuHo() {
        return hoTenChuHo;
    }

    public void setHoTenChuHo(String hoTenChuHo) {
        this.hoTenChuHo = hoTenChuHo;
    }

    public int getSoNha() {
        return soNha;
    }

    public void setSoNha(int soNha) {
        this.soNha = soNha;
    }

    public String getMaSoCongTo() {
        return maSoCongTo;
    }

    public void setMaSoCongTo(String maSoCongTo) {
        this.maSoCongTo = maSoCongTo;
    }


    // Input
    public void input() {

        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap ma khach hang: ");
        maKhachHang = sc.next();
        System.out.println("Nhap ten chu ho: ");
        hoTenChuHo = sc.next();
        System.out.println("Nhap so nha: ");
        soNha = sc.nextInt();
        System.out.println("Nhap ma so cong to: ");
        maSoCongTo = sc.next();
    }


    // Output
    public void output() {

        System.out.println("Ma khach hang: " + maKhachHang);
        System.out.println("Ten chu ho: " + hoTenChuHo);
        System.out.println("So nha: " + soNha);
        System.out.println("Ma so cong to: " + maSoCongTo);
    }
}


// Lop hoa don ke thua tu lop khach hang
public class HoaDon extends KhachHang {
    public int chiSoMoi;
    public int chiSoCu;
    private int thangSuDung;


    // Constructor khong co tham so
    public HoaDon() {

    }


    // Constructor co tham so
    public HoaDon(String maKhachHang, String hoTenChuHo, int soNha, String maSoCongTo, int chiSoMoi, int chiSoCu, int thangSuDung) {
        super(maKhachHang, hoTenChuHo, soNha, maSoCongTo);
        this.chiSoMoi = chiSoMoi;
        this.chiSoCu = chiSoCu;
        this.thangSuDung = thangSuDung;
    }


    // get/set

    public int getChiSoMoi() {
        return chiSoMoi;
    }

    public void setChiSoMoi(int chiSoMoi) {
        this.chiSoMoi = chiSoMoi;
    }

    public int getChiSoCu() {
        return chiSoCu;
    }

    public void setChiSoCu(int chiSoCu) {
        this.chiSoCu = chiSoCu;
    }

    public int getThangSuDung() {
        return thangSuDung;
    }

    public void setThangSuDung(int thangSuDung) {
        this.thangSuDung = thangSuDung;
    }

    // Override input
    @Override
    public void input() {
        super.input();

        Scanner sc = new Scanner(System.in);
        /*HoaDon hoaDon = new HoaDon();
        try{
            hoaDon.input();
        }catch(Exception ex) {
            System.out.println("Loi: " + ex.getMessage());
            hoaDon.input();
        }

         */

        System.out.println("Thang su dung: ");
        thangSuDung = sc.nextInt();
        while (true) {
            try {
                System.out.println("Nhap chi so moi: ");
                chiSoMoi = sc.nextInt();
                System.out.println("Nhap chi so cu: ");
                chiSoCu = sc.nextInt();
                if (chiSoMoi < chiSoCu) {
                    throw new IllegalArgumentException("CHi so moi khong duoc nho hon chi so cu");
                }
            } catch (Exception e) {
                System.out.println("Gap loi: " + e);
                System.out.println("Nhap lai chi so moi va chi so cu!");
                System.out.println("Nhap chi so moi: ");
                chiSoMoi = sc.nextInt();
                System.out.println("Nhap chi so cu: ");
                chiSoCu = sc.nextInt();
            }
            break;
        }
    }
        /*class LoiCongTo extends HoaDon {
            public LoiCongTo() {

                try {
                    System.out.println("Nhap chi so moi: ");
                    chiSoMoi = sc.nextInt();
                    System.out.println("Nhap chi so cu: ");
                    chiSoCu = sc.nextInt();
                    int a = chiSoMoi;
                    int b = chiSoCu;
                    if (a < b) {
                        System.out.println("Chi so nhap sai: ");
                    }
                }
                    catch(Exception e) {
                        System.out.println("Chi so nhap sai: "+e);
                        System.out.println("Nhap lai chi so: ");
                        System.out.println("Chi so moi: " + chiSoMoi);
                        System.out.println("Chi so cu: " + chiSoCu);
                    }
                }
            }

         */

    // Check su hop le cua chi so moi va chi so cu
        /*int a = chiSoMoi;
        int b = chiSoCu;
        if (a < b) {
            // Chi so cong to khong hop le
            System.out.println("Nhap lai chi so cong to: ");
            System.out.println("Chi so cong to moi: ");
            a = sc.nextInt();
            b = sc.nextInt();

        System.out.println("Thang su dung: ");
        thangSuDung = sc.nextInt();
        }

    }

         */


    // Override output
    @Override
    public void output() {
        super.output();

        System.out.println("Chi so moi: " + chiSoMoi);
        System.out.println("Chi so cu: " + chiSoCu);
        System.out.println("Thang su dung: " + thangSuDung);
    }


    // Phuong thuc tinh tien
    public int tinhTien() {
        int tinhTien = (chiSoMoi - chiSoCu) * 850;
        return tinhTien;
    }


    /*class LoiCongTo extends HoaDon {
        public LoiCongTo() {

            Scanner sc = new Scanner(System.in);
            try {
                System.out.println("Nhap chi so moi: ");
                chiSoMoi = sc.nextInt();
                System.out.println("Nhap chi so cu: ");
                chiSoCu = sc.nextInt();
                int a = chiSoMoi;
                int b = chiSoCu;
                if (a < b) {
                    System.out.println("Chi so nhap sai: ");
                }
            }
            catch(Exception e) {
                System.out.println("Chi so nhap sai: "+e);
                System.out.println("Nhap lai chi so: ");
                System.out.println("Chi so moi: " + chiSoMoi);
                System.out.println("Chi so cu: " + chiSoCu);
            }
        }
    }

     */
}