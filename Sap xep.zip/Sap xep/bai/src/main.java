import java.util.Scanner;

public class main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // Khai bao
        int n = 5;
        int i;
        int j;
        double b;


        // Khoi tao mang
        double a[] = {2, 1, 7, 5, 8}; //new double[n];

        // Input
        // Sap xep
        /* for (i = 0; i < n; i++) {
            // Tim gia tri phu hop cho a[i]
            for (j = i; j < n; j++) {
                if (a[j] > a[i]) {
                    // doi cho a[j] va a[i]
                    double b = a[i];
                    a[i] = a[j];
                    a[j] = b;

                }
            }
        }
*/
        for (i = 0; i < n; i++) {
            for (j = i; j < n; j++) {
                if (a[j] < a[i]) {
                    b = a[i];
                    a[i] = a[j];
                    a[j] = b;
                }
            }
        }


        // Output
        System.out.printf("In ra mang: ");
        for (i = 0; i < n; i++) {
            System.out.printf(" " + a[i] + ",");
            a[i]++;
        }


    }
}
