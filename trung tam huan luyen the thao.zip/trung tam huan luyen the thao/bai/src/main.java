import java.util.Scanner;
// xem lai cau cu li sap xep nho den lon
// DHT
class VanDongVien {
    private String maVanDongVien;
    private String hoTen;
    private int tuoi;
    private String gioiTinh;


    // Constructor
    public VanDongVien(String maVanDongVien, String hoTen, int tuoi, String gioiTinh) {
        this.maVanDongVien = maVanDongVien;
        this.hoTen = hoTen;
        this.tuoi = tuoi;
        this.gioiTinh = gioiTinh;
    }

    public VanDongVien() {

    }


    // get/set

    public String getMaVanDongVien() {
        return maVanDongVien;
    }

    public void setMaVanDongVien(String maVanDongVien) {
        this.maVanDongVien = maVanDongVien;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public int getTuoi() {
        return tuoi;
    }

    public void setTuoi(int tuoi) {
        this.tuoi = tuoi;
    }

    public String getGioiTinh() {
        return gioiTinh;
    }

    public void setGioiTinh(String gioiTinh) {
        this.gioiTinh = gioiTinh;
    }


    // Phuong thuc input cho thong tin ve van dong vien
    public void input() {

        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap ma van dong vien: ");
        maVanDongVien = sc.next();
        System.out.println("Nhap ho ten: ");
        hoTen = sc.next();
        System.out.println("Nhap tuoi: ");
        tuoi = sc.nextInt();
        System.out.println("Nhap gioi tinh: ");
        gioiTinh = sc.next();
    }


    // Phuong thuc output cho thong tin van dong vien
    public void output() {

        System.out.println("Ma van dong vien: " + maVanDongVien);
        System.out.println("Ho ten: " + hoTen);
        System.out.println("Tuoi: " + tuoi);
        System.out.println("Gioi tinh: " + gioiTinh);
    }
}


// Lop van dong vien dien kinh ke thua tu lop van dong vien
class VDV_DienKinh extends VanDongVien {
    private int cuLyChay;
    private String tocDoChay;


    // Constructor
    public VDV_DienKinh() {
        super();
    }

    public VDV_DienKinh(String maVanDongVien, String hoTen, int tuoi, String gioiTinh, int cuLyChay, String tocDoChay) {
        super(maVanDongVien, hoTen, tuoi, gioiTinh);
        this.cuLyChay = cuLyChay;
        this.tocDoChay = tocDoChay;
    }


    // get/set
    public int getCuLyChay() {
        return cuLyChay;
    }

    public void setCuLyChay(int cuLyChay) {
        this.cuLyChay = cuLyChay;
    }

    public String getTocDoChay() {
        return tocDoChay;
    }

    public void setTocDoChay(String tocDoChay) {
        this.tocDoChay = tocDoChay;
    }


    // Phuong thuc input cho thong tin VDV_DienKinh
    @Override
    public void input() {
        super.input();
        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap cu ly chay: ");
        cuLyChay = sc.nextInt();
        System.out.println("Nhap toc do chay: ");
        tocDoChay = sc.next();
    }


    // Phuong thuc output cho thong tin VDV_DienKinh
    @Override
    public void output() {
        super.output();

        System.out.println("Cu ly chay: " + cuLyChay);
        System.out.println("Toc do chay: " + tocDoChay);
    }
}


// Viet chuong trinh thuc hien cong viec
public class main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // a
        System.out.println("Nhap danh sach van dong vien dien kinh: ");
        int n = Integer.parseInt(sc.nextLine());

        // Khai bao mang chua n van dong vien dien kinh
        VDV_DienKinh[] dsVDV = new VDV_DienKinh[n];

        // Nhap thong tin cho tung van dong vien
        for (int i = 0; i < n; i++) {
            System.out.println("Nhap thong tin van dong vien thu " + (i + 1) + " ");
            //dsVDV[i] = new VDV_DienKinh("abc" + i, "nvs" + i, 23 + i, "fs" + i, 12 + i, 21 + i);
            dsVDV[i] = new VDV_DienKinh("", "", 0, "", 0, "");
            dsVDV[i].input();
        }
        System.out.println("----------------------------------------------------------------------------------------");
        System.out.println("------------------------------------------MENU------------------------------------------");
        System.out.println("1. In danh sach cac van dong vien vua nhap ra man hinh");
        System.out.println("2. Sap xep danh sach van dong vien dien kinh trong danh sach theo cu ly chay tu nho den lon");
        System.out.println("3. Tim kiem van dong vien nhieu tuoi nhat");
        System.out.println("0. Ket thuc chuong trinh");
        System.out.println("----------------------------------------------------------------------------------------");
        while (true) {
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("----------------------------------------------------------------------------------------");
                    System.out.println("In danh sach cac van dong vien vua nhap ra man hinh");
                //  In ra danh sach van dong vien sau khi nhap
                    /*
                for (VDV_DienKinh VDV : dsVDV) {
                    VDV.output();
                    System.out.println();
                }

                     */
                    for(int i =0; i<n;i++){
                        dsVDV[i].output();
                        System.out.println();
                    }
                    break;
                case 2:
                    System.out.println("----------------------------------------------------------------------------------------");
                    System.out.println("Danh sach van dong vien sap xep theo cu ly chay tu nho den lon");

                // c. Sap xep danh sach vdv theo cu ly chay tu nho den lon
                for (int i = 0; i < n; i++) {
                    for (int j = i; j < n; j++) {
                        if (dsVDV[i].getCuLyChay() > dsVDV[j].getCuLyChay()) {
                            VDV_DienKinh VDV = dsVDV[i];
                            dsVDV[i] = dsVDV[j];
                            dsVDV[j] = VDV;
                        }
                    }
                }
                for (int i = 0; i < n; i++) {
                    System.out.println("Ho ten: " + dsVDV[i].getHoTen());
                    System.out.println("Cu ly chay: " + dsVDV[i].getCuLyChay());
                }
                break;
                case 3:
                    System.out.println("----------------------------------------------------------------------------------------");
                    System.out.println("Van dong vien dien kinh nhieu tuoi nhat");


                // d. Tim kiem van dong vien nhieu tuoi nhat
                VDV_DienKinh ketqua = dsVDV[0];
                for (int i = 0; i < n; i++) {
                    if (ketqua.getTuoi() < dsVDV[i].getTuoi()) {
                        ketqua = dsVDV[i];
                    }
                }
                ketqua.output();
                break;
                case 0:
                    System.out.println("----------------------------------------------------------------------------------------");
                    System.out.println("Ket thuc chuong trinh");
                    break;
                default:
                    System.out.println("----------------------------------------------------------------------------------------");
                    System.out.println("Lua chon khong dung. Vui long chon lai");
            }
        }
    }
}
