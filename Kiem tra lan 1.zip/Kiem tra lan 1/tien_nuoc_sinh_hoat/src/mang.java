import java.util.Scanner;

public class mang {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);


        // Khai báo biến
        int n;
        int i;
        double[] a;


        // Nhập giá trị từ bàn phím
        System.out.println("Nhập số phần tử của mảng: ");
        n = sc.nextInt();


        // Khởi tạo mảng chứa n phần tử
        // double[] a = new double[n];
        a = new double[n];

        // Nhập dãy số thực
        System.out.println("Nhập dãy số thực ");
        for (i = 0; i < n; i++) {
            System.out.println("Phần tử thứ " + (i + 1) + ": ");
            a[i] = sc.nextDouble();
        }


        // In ra dãy số
        System.out.println("Dãy số vừa nhập: ");
        for (i = 0; i < n; i++) {
            System.out.println(a[i] + " ");
        }

        // Tìm phần tử lẻ đầu tiên
        for (i = 0; i < n; i++) {
            if (a[i] % 2 != 0) {
                System.out.println("Phần tử lẻ đầu tiên của mảng: " + a[i]);
                break;

            } else
                System.out.println("Mảng không có phần tử lẻ ");
            break;
        }


        // Thay giá trí số 0 = 10
        for (i = 0; i < n; i++) {
            if (a[i] == 0) {
                a[i] = 10;
            }
        }
        // In ra dãy số
        System.out.println("Dãy số sau thay thế: ");
        for (i = 0; i < n; i++) {
            System.out.println(a[i] + " ");
        }
    }
}
