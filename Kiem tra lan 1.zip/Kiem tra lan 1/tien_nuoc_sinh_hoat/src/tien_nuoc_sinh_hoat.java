import java.util.Scanner;

public class tien_nuoc_sinh_hoat {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Khai báo biến
        double a;
        double d;
        double c;
        double m1 = 8000;
        double m2 = 9000;
        double m3 = 11000;
        double m4 = 18000;
        double b_tiennuoc = 0;


        // Nhập giá trị
        System.out.println("Mời nhập tên chủ hộ: ");
        String name = sc.nextLine();
        System.out.println("Số đồng hồ nước cũ: ");
        c = sc.nextDouble();
        System.out.println("Số đồng hồ nước mới: ");
        d = sc.nextDouble();


        // Tính toán
        System.out.println("Tính toán lượng nước tiêu thụ trong 1 tháng: ");
        a = d - c;
        System.out.println(+a);


        // Tính toán
        if (a >= 0 && a <= 10) {
            b_tiennuoc = a * m1;
            System.out.println("Số tiền nước cần trả: " + b_tiennuoc);
        } else if (a >= 11 && a <= 20) {
            b_tiennuoc = a * m2;
            System.out.println("Số tiền nước cần trả: " + b_tiennuoc);
        } else if (a >= 21 && a <= 30) {
            b_tiennuoc = a * m3;
            System.out.println("Số tiền nước cần trả: " + b_tiennuoc);
        } else if (a >= 31) {
            b_tiennuoc = a * m4;
            System.out.println("Số tiền nước cần trả: " + b_tiennuoc);
        }
    }
}
