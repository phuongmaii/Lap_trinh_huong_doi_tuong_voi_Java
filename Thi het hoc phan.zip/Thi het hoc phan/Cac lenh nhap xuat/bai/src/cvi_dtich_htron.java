import java.net.SecureCacheResponse;
import java.util.Scanner;

public class cvi_dtich_htron {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // khai bao bien
        double r;
        double c, s;

        // nhap gia tri cua ban kinh
        System.out.println("nhap gia tri ban kinh r: ");
        r = sc.nextDouble();

        // tinh toan
        c = 2 * 3.14 * r;
        s = 3.14 * Math.pow(r, 2);

        // in kq ra man hinh
        System.out.println("chu vi htron: " + c);
        System.out.println("dien tich htron: " + s);
    }
}
