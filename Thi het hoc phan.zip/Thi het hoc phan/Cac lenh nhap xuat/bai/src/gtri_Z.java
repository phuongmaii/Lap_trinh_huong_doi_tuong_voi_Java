import java.util.Scanner;

public class gtri_Z {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // khai bao bien
        float a, x;
        double Z;

        // nhap du lieu
        System.out.println("nhap gia tri cua a: ");
        a = sc.nextFloat();
        System.out.println("nhap gia tri cua x: ");
        x = sc.nextFloat();

        // tinh toan
        Z = Math.exp(a + Math.pow(Math.sin(x), 2) - x);  // e luy thua

        // in kq
        System.out.println("gia tri cua bieu thuc Z: " + Z);
    }
}