import java.util.Scanner;

public class cvi_dtich_hcn {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // khai bao bien
        double a, b;
        double p, s;

        // nhap gia tri a, b
        System.out.println("nhap gia tri canh a: ");
        a = sc.nextDouble();
        System.out.println("nhap gia tri canh b: ");
        b = sc.nextDouble();

        // tinh toan
        p = (a + b) * 2;
        s = a * b;

        // in kq ra man hinh
        System.out.println("chu vi hcn: " + p);
        System.out.println("dien tich hcn: " + s);
    }
}
