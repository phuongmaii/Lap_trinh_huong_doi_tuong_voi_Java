import java.util.Scanner;

public class gtri_S {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // khai bao bien
        double x, y;
        double S;

        // nhap gia tri cua x va y
        System.out.println("nhap gia tri x: ");
        x = sc.nextDouble();
        System.out.println("nhap gia tri y: ");
        y = sc.nextDouble();

        // tinh toan
        S = Math.pow(x, y);

        // in kq ra man hinh
        System.out.println("gia tri cua S: " + S);
    }
}
