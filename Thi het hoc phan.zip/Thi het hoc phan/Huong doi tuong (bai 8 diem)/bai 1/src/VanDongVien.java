import java.util.Scanner;

public class VanDongVien {
    private String maVanDongVien;
    private String hoTen;
    private int tuoi;
    private String gioiTinh;

    // get/ set
    public String getMaVanDongVien() {
        return maVanDongVien;
    }

    public void setMaVanDongVien(String maVanDongVien) {
        this.maVanDongVien = maVanDongVien;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public int getTuoi() {
        return tuoi;
    }

    public void setTuoi(int tuoi) {
        this.tuoi = tuoi;
    }

    public String getGioiTinh() {
        return gioiTinh;
    }

    public void setGioiTinh(String gioiTinh) {
        this.gioiTinh = gioiTinh;
    }

    // Constructor
    public VanDongVien(String maVanDongVien, String hoTen, int tuoi, String gioiTinh) {
        this.maVanDongVien = maVanDongVien;
        this.hoTen = hoTen;
        this.tuoi = tuoi;
        this.gioiTinh = gioiTinh;
    }

    public void Input() {
        Scanner sc = new Scanner(System.in);
        System.out.println("nhap ma van dong vien: ");
        maVanDongVien = sc.next();
        System.out.println("nhap ho ten: ");
        hoTen = sc.next();
        System.out.println("nhap tuoi: ");
        tuoi = sc.nextInt();
        System.out.println("nhap gioi tinh: ");
        gioiTinh = sc.next();
    }

    public void Output() {
        System.out.println("ma van dong vien: " + maVanDongVien);
        System.out.println("ho ten: " + hoTen);
        System.out.println("tuoi: " + tuoi);
        System.out.println("nhap gioi tinh: " + gioiTinh);
    }
}
