import java.util.Scanner;

public class VDV_DienKinh extends VanDongVien {
    private int cuLyChay;
    private int tocDoChay;

    // get/ set

    public int getCuLyChay() {
        return cuLyChay;
    }

    public void setCuLyChay(int cuLyChay) {
        this.cuLyChay = cuLyChay;
    }

    public int getTocDoChay() {
        return tocDoChay;
    }

    public void setTocDoChay(int tocDoChay) {
        this.tocDoChay = tocDoChay;
    }

    // Constructor
    public VDV_DienKinh(String maVanDongVien, String hoTen, int tuoi, String gioiTinh, int cuLyChay, int tocDoChay) {
        super(maVanDongVien, hoTen, tuoi, gioiTinh);
        this.cuLyChay = cuLyChay;
        this.tocDoChay = tocDoChay;

    }

    // Override input
    @Override
    public void Input() {
        super.Input();
        Scanner sc = new Scanner(System.in);
        System.out.println("nhap cu ly chay: ");
        cuLyChay = sc.nextInt();
        System.out.println("nhap toc do chay: ");
        tocDoChay = sc.nextInt();
    }

    // Override output
    public void Output() {
        super.Output();
        System.out.println("cu ly chay: " + cuLyChay);
        System.out.println("toc do chay: " + tocDoChay);
    }
}
