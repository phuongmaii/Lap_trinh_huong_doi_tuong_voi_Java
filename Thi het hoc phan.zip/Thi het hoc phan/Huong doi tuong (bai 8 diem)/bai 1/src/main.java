import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // nhap so luong danh sach van dong vien
        System.out.println("nhap so luong n van dong vien: ");
        int n = Integer.parseInt(sc.next());
        // khoi tao mang
        VDV_DienKinh[] dsVDV = new VDV_DienKinh[n];
        for (int i = 0; i < n; i++) {
            System.out.println("nhap thong tin van dong vien thu " + (i + 1) + " ");
            dsVDV[i] = new VDV_DienKinh("", "", 0, "", 0, 0);
            dsVDV[i].Input();
        }

        // thuc hien cac yeu cau de bai
        while (true) {
            System.out.println("-------------------------------------------MENU-------------------------------------------");
            System.out.println("1. in ra danh sach van dong vien vua nhap");
            System.out.println("2. sap xep danh sach van dong vien theo thu tu cu ly chay tu nho den lon");
            System.out.println("3. tim kiem van dong vien nhieu tuoi nhat");
            System.out.println("0. ket thuc chuong trinh");
            System.out.println("------------------------------------------------------------------------------------------");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("danh sach van dong vien vua nhap:");
                    for (int i = 0; i < n; i++) {
                        dsVDV[i].Output();
                        System.out.println();
                    }
                    System.out.println("------------------------------------------------------------------------------------------");
                    break;
                case 2:
                    System.out.println("sap xep danh sach van dong vien theo thu tu cu ly chay tu nho den lon:");
                    for (int i = 0; i < n; i++) {
                        for (int j = 0; j < n; j++) {
                            if (dsVDV[i].getCuLyChay() < dsVDV[j].getCuLyChay()) {
                                VDV_DienKinh tempt = dsVDV[i];
                                dsVDV[i] = dsVDV[j];
                                dsVDV[j] = tempt;
                            }
                        }
                        System.out.println("ma van dong vien: " + dsVDV[i].getMaVanDongVien());
                        System.out.println("ho ten: " + dsVDV[i].getHoTen());
                        System.out.println("cu ly chay: " + dsVDV[i].getCuLyChay());
                        System.out.println();
                    }
                    System.out.println("------------------------------------------------------------------------------------------");
                    break;
                case 3:
                    System.out.println("tim kiem van dong vien nhieu tuoi nhat:");
                    VDV_DienKinh ketqua = dsVDV[0];
                    for (int i = 0; i < n; i++) {
                        if (ketqua.getTuoi() < dsVDV[i].getTuoi()) {
                        }
                            System.out.println("ma van dong vien: " + dsVDV[i].getMaVanDongVien());
                            System.out.println("ho ten: " + dsVDV[i].getHoTen());
                            System.out.println("tuoi: " + dsVDV[i].getTuoi());
                            System.out.println();
                    }
                    System.out.println("------------------------------------------------------------------------------------------");
                    break;
                case 0:
                    System.out.println("ket thuc chuong trinh");
                    System.out.println();
                    System.out.println("------------------------------------------------------------------------------------------");
                    break;
                default:
                    System.out.println("lua chon khong hop le, vui long chon lai!");
                    System.out.println();
            }
        }
    }
}
