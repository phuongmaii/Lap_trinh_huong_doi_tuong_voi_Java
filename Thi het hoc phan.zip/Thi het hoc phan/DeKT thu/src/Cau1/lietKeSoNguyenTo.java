package Cau1;

import java.util.Scanner;

public class lietKeSoNguyenTo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // khai bao bien
        int n;
        int count = 0;

        // nhap du lieu
        System.out.println("nhap gia tri cua n: ");
        n = sc.nextInt();

        // kiem tra dieu kien 0 < n <= 10000
        if (n > 0 && n <= 10000) {
            // tim so nguyen to
            System.out.println("cac so nguyen to la: ");
            for (int i = 2; i < n; i++) {
                boolean isPrime = true;
                for (int j = 2; j * j <= i; j++) {
                    if (i % j == 0) {
                        isPrime = false;
                        break;
                    }
                }
                if (isPrime) {
                    System.out.print(i + " ");
                    count++;
                }
            }
        }
        while (true) {
            try {
                if (n < 0 || n > 10000) {
                    throw new IllegalArgumentException("n khong nam trong khoang cho phep, vui long nhap lai!");
                }
            } catch (Exception e) {
                System.out.println("gap loi: " + e);
                System.out.println("nhap lai gia tri cua n: ");
                n = sc.nextInt();
                if (n > 0 && n <= 10000) {
                    // tim so nguyen to
                    System.out.println("cac so nguyen to la: ");
                    for (int i = 2; i < n; i++) {
                        boolean isPrime = true;
                        for (int j = 2; j * j <= i; j++) {
                            if (i % j == 0) {
                                isPrime = false;
                                break;
                            }
                        }
                        if (isPrime) {
                            System.out.print(i + " ");
                            count++;
                        }
                    }
                }
            }
        }
    }
}