package Cau2;

import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // khai bao so luong
        System.out.println("nhap so luong may: ");
        int n = Integer.parseInt(sc.next());
        // khoi tao mang
        MayChu dsMC[] = new MayChu[n];
        // nhap thong tin cho tung may
        for (int i = 0; i < n; i++) {
            System.out.println("nhap thong tin cho may thu " + (i + 1) + " ");
            dsMC[i] = new MayChu("", "", 0, 0, 0, "", "");
            dsMC[i].inPut();
        }

        // menu
        while (true) {
            System.out.println("----------------------------------------------MENU----------------------------------------------");
            System.out.println("1. in ra danh sach cac may cua hang (nhap ten hang tu ban phim) da su dung > 5 nam");
            System.out.println("2. thong ke may theo ten hang, so luong");
            System.out.println("3. liet ke cac may kiem ke nam 2023");
            System.out.println("0. ket thuc chuong trinh");
            System.out.println("------------------------------------------------------------------------------------------------");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("danh sach cac may cua hang (nhap ten hang tu ban phim) da su dung > 5 nam");
                    String tenMay = sc.next();
                    for (int i = 0; i < n; i++) {
                        if (dsMC[i].getTenMay().equals(tenMay) && dsMC[i].tinhThoiGianSuDung() > 5) {
                            System.out.println("ma may: " + dsMC[i].getMaMay());
                            System.out.println("nam dua vao su dung: " + dsMC[i].getNamDuaVaoSuDung());
                            System.out.println("nam kiem ke: " + dsMC[i].getNamKiemKe());
                        }
                        else{
                            System.out.println("hang may da chon khong co may da su dung > 5 nam, vui long chon lai!");
                        }
                    }
                    System.out.println("------------------------------------------------------------------------------------------------");
                    break;
                case 2:
                    System.out.println("thong ke may theo ten hang, so luong");
                    for (int i = 0; i < n; i++) {
                        System.out.println("ten hang: " + dsMC[i].getTenMay());
                        System.out.println("so luong: " + dsMC[i].getSoLuong());
                        System.out.println();
                    }
                    System.out.println("------------------------------------------------------------------------------------------------");
                    break;
                case 3:
                    System.out.println("liet ke may kiem ke nam 2023");
                    for (int i = 0; i < n; i++) {
                        if (dsMC[i].getNamKiemKe() == 2023) {
                            System.out.println("ma may: " + dsMC[i].getMaMay());
                            System.out.println("ten hang: " + dsMC[i].getTenMay());
                            System.out.println("so luong: " + dsMC[i].getSoLuong());
                            System.out.println();
                        }
                    }
                    System.out.println("------------------------------------------------------------------------------------------------");
                    break;
                case 0:
                    System.out.println("ket thuc chuong trinh");
                    System.out.println("------------------------------------------------------------------------------------------------");
                    break;
                default:
                    System.out.println("lua chon khong hop le, vui long nhap lai!");
            }
        }
    }
}
