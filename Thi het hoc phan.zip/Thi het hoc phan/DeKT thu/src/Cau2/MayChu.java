package Cau2;

import java.util.Scanner;

public class MayChu extends ThietBi {
    private String loaiMayChu;
    private String chucNang;

    // get/ set

    public String getLoaiMayChu() {
        return loaiMayChu;
    }

    public void setLoaiMayChu(String loaiMayChu) {
        this.loaiMayChu = loaiMayChu;
    }

    public String getChucNang() {
        return chucNang;
    }

    public void setChucNang(String chucNang) {
        this.chucNang = chucNang;
    }

    // Constructor
    public MayChu(String maMay, String tenMay, int soLuong, int namDuaVaoSuDung, int namKiemKen, String loaiMayChu, String chucNang) {
        super(maMay, tenMay, soLuong, namDuaVaoSuDung, namKiemKen);
        this.loaiMayChu = loaiMayChu;
        this.chucNang = chucNang;
    }

    // Override inPut

    @Override
    public void inPut() {
        super.inPut();
        Scanner sc = new Scanner(System.in);
        System.out.println("nhap loai may chu: ");
        loaiMayChu = sc.next();
        System.out.println("nhap chuc nang: ");
        chucNang = sc.next();
    }

    // Override outPut
    @Override
    public void outPut() {
        super.outPut();
        System.out.println("loai may chu: " + loaiMayChu);
        System.out.println("chuc nang: " + chucNang);
    }
}
