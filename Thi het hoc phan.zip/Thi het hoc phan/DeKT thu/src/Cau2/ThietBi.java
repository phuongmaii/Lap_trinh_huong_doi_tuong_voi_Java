package Cau2;

import java.util.Scanner;

public class ThietBi {
    private String maMay;
    private String tenMay;
    private int soLuong;
    private int namDuaVaoSuDung;
    private int namKiemKe;

    // get/ set
    public String getMaMay() {
        return maMay;
    }

    public void setMaMay(String maMay) {
        this.maMay = maMay;
    }

    public String getTenMay() {
        return tenMay;
    }

    public void setTenMay(String tenMay) {
        this.tenMay = tenMay;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public int getNamDuaVaoSuDung() {
        return namDuaVaoSuDung;
    }

    public void setNamDuaVaoSuDung(int namDuaVaoSuDung) {
        this.namDuaVaoSuDung = namDuaVaoSuDung;
    }

    public int getNamKiemKe() {
        return namKiemKe;
    }

    public void setNamKiemKe(int namKiemKe) {
        this.namKiemKe = namKiemKe;
    }

    // Constructor
    public ThietBi(String maMay, String tenMay, int soLuong, int namDuaVaoSuDung, int namKiemKen) {
        this.maMay = maMay;
        this.tenMay = tenMay;
        this.soLuong = soLuong;
        this.namDuaVaoSuDung = namDuaVaoSuDung;
        this.namKiemKe = namKiemKe;
    }

    // inPut
    public void inPut() {
        Scanner sc = new Scanner(System.in);
        System.out.println("nhap ma may: ");
        maMay = sc.next();
        System.out.println("nhap ten may: ");
        tenMay = sc.next();
        System.out.println("nhap so luong: ");
        soLuong = sc.nextInt();
        while (true) {
            try {
                System.out.println("nhap nam dua vao su dung: ");
                namDuaVaoSuDung = sc.nextInt();
                System.out.println("nam kiem ke: ");
                namKiemKe = sc.nextInt();
                if (namKiemKe < namDuaVaoSuDung) {
                    throw new IllegalArgumentException("nam kiem ke phai lon hon nam dua vao su dung!");
                }
            } catch (Exception e) {
                System.out.println("gap loi: " + e);
                System.out.println("nam kiem ke: ");
                namKiemKe = sc.nextInt();
            }
            break;
        }
    }

    // outPut
    public void outPut() {
        System.out.println("ma may: " + maMay);
        System.out.println("ten may: " + tenMay);
        System.out.println("so luong: " + soLuong);
        System.out.println("nam dua vao su dung: " + namDuaVaoSuDung);
        System.out.println("nam kiem ke: " + namKiemKe);
    }

    public double tinhThoiGianSuDung() {
        double thoigian = namKiemKe - namDuaVaoSuDung;
        return thoigian;
    }
}
