import java.util.InputMismatchException;
import java.util.Scanner;

public class tryCatch {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // khai bao bien
        int a = 0;
        int b = 0;

        boolean validInput = false;
        while (!validInput) {
            try {
                System.out.println("nhap gia tri cua a: ");
                a = Integer.parseInt(sc.nextLine());
                validInput = true;
            } catch (NumberFormatException e1) {
                System.out.println("loi: so nhap khong hop le. vui long nhap lai!");

            }
        }
        validInput = false;
        while (!validInput) {
            try {
                System.out.println("nhap gia tri cua b: ");
                b = Integer.parseInt(sc.nextLine());
                validInput = true;
            } catch (NumberFormatException e1) {
                System.out.println("loi: so nhap khong hop le. vui long nhap lai!");
                /*
                System.out.println("nhap so nguyen b: ");
                b = sc.nextInt();

                 */
            }
            break;
        }

        System.out.println("gia tri cua a va b: " + a + " va " + b);
    }
}

