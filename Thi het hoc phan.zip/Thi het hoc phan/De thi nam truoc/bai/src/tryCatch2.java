import java.util.Scanner;
public class tryCatch2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double a = 0;
        double b = 0;

        boolean validInput = false;
        while (!validInput) {
            try {
                System.out.println("nhap gia tri cua a : ");
                a = Integer.parseInt(sc.nextLine());
                validInput = true;
                //NumberFormatException e
                //

            } catch (NumberFormatException e1) {
                System.out.println("loi: so nhap khong hop le. vui long nhap lai!");
            }
        }


        validInput = false;
        while (!validInput) {
            try {
                System.out.println("nhap gia tri cua b: ");
                b = Integer.parseInt(sc.nextLine());
                validInput = true;
            } catch (NumberFormatException e1) {
                System.out.println("loi: so nhap khong hop le. vui long nhap lai!");
            }
        }
        System.out.println("gia tri cua a  va b la: " + a + " va " + b);
    }
}
