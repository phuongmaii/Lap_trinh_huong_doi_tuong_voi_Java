import java.util.Scanner;

public class tongS {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // khai bao bien
        int n;

        // nhap gia tri cho bien
        System.out.println("nhap gia tri cua n: ");
        n = sc.nextInt();

        // tinh toan
        // can dung vong lap for
        int sum = 0; // khoi tao bien tong
        for (int i = 1; i <= n; i++) {
            sum += i * i;
        }

        // in kq
        System.out.println("gia tri cua S: " + sum);
    }
}
