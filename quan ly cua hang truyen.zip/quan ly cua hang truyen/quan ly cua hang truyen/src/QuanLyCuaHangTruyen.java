import cuahangtruyen.TheThue;

import java.util.Scanner;

public class QuanLyCuaHangTruyen {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);


        // a. Nhap vao danh sach thue, xuat danh sach thue ra man hinh
        System.out.println("Nhap danh sach thue: ");
        int n = Integer.parseInt(sc.nextLine());

        // Khai bao mang chua n phan tu
        TheThue[] ds_thethue = new TheThue[n];

        // Nhap thong tin cho the thue
        for (int i = 0; i < n; i++) {
            System.out.println("The thue thu " + (i + 1) + " ");
            //ds_thethue[i] = new TheThue("Ho ten" + i, "Dia chi" + i, "SDT" + i, 12 + i, "So hieu truyen" + i, 12 + i, 21 + i, 12000 + i);
            ds_thethue[i] = new TheThue();
            ds_thethue[i].input();
        }
        while (true) {
            System.out.println("------------------------------------------------------------------------------------------");
            System.out.println("-------------------------------------------MENU-------------------------------------------");
            System.out.println("1. In danh sach the thue vua nhap ra man hinh");
            System.out.println("2. Tinh trung binh tien thue cua cac phieu thue");
            System.out.println("0. Ket thuc chuong trinh");
            System.out.println("------------------------------------------------------------------------------------------");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("------------------------------------------------------------------------------------------");
                    // In ra danh sach the thue
                    System.out.println("Danh sach the thue: ");
                    for (TheThue theThue : ds_thethue) {
                        theThue.output();
                        System.out.println();
                    }
                    break;
                case 2:
                    System.out.println("------------------------------------------------------------------------------------------");


                    // b. Tinh tien trung binh tien thue cua cac phieu thue
                    // Tong so tien - co 2 cach
                    double tong = 0;
        /*for(TheThue theThue: ds_thethue){
            tong += theThue.getSoTienThue();
        }
         */
                    for (int i = 0; i < n; i++) {
                        tong += ds_thethue[i].getSoTienThue();
                    }

                    // Trung binh so tien
                    double trungBinhTienThue = tong / n;
                    System.out.println("Trung binh tien thue: " + trungBinhTienThue + "VND");
                    break;
                case 0:
                    System.out.println("------------------------------------------------------------------------------------------");
                    System.out.println("Ket thuc chuong trinh");
                    break;
                default:
                    System.out.println("------------------------------------------------------------------------------------------");
                    System.out.println("Lua chon khong hop le, vui long chon lai");
            }
        }
    }
}