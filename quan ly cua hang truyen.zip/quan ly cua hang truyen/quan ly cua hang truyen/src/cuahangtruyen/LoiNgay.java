package cuahangtruyen;

public class LoiNgay extends Exception {
    public LoiNgay() {
        super();
    }
}
