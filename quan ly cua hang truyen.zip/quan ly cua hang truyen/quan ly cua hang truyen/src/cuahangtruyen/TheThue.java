package cuahangtruyen;
// DHT

import java.util.Scanner;

class KhachThue {
    private String hoTen;
    private String diaChi;
    private String soDienThoai;


    // Constructor khong co tham so
    public KhachThue() {

    }


    // Constructor co tham so
    public KhachThue(String hoTen, String diaChi, String soDienThoai) {
        this.hoTen = hoTen;
        this.diaChi = diaChi;
        this.soDienThoai = soDienThoai;
    }


    // get/set

    public String getHoTen() {
        return hoTen;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    public String getSoDienThoai() {
        return soDienThoai;
    }

    public void setSoDienThoai(String soDienThoai) {
        this.soDienThoai = soDienThoai;
    }


    // Input
    public void input() {

        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap ho ten: ");
        hoTen = sc.next();
        System.out.println("Nhap dia chi: ");
        diaChi = sc.next();
        System.out.println("Nhap so dien thoai: ");
        soDienThoai = sc.next();
    }


    // Output
    public void output() {

        System.out.println("Ho ten: " + hoTen);
        System.out.println("Dia chi: " + diaChi);
        System.out.println("So dien thoai: " + soDienThoai);
    }
}


// Lop the thue ke thua tu lop khach thue
public class TheThue extends KhachThue {
    private int soPhieuThue;
    private String soHieuTruyen;
    private int ngayThue;
    private int hanTra;
    private double soTienThue;


    // Constructor khong co tham so
    public TheThue() {
        super();

    }


    // Constructor co tham so
    public TheThue(String hoTen, String diaChi, String soDienThoai, int soPhieuThue, String soHieuTruyen, int ngayThue, int hanTra, double soTienThue) {
        super(hoTen, diaChi, soDienThoai);
        this.soPhieuThue = soPhieuThue;
        this.soHieuTruyen = soHieuTruyen;
        this.ngayThue = ngayThue;
        this.hanTra = hanTra;
        this.soTienThue = soTienThue;
    }


    // get/set

    public int getSoPhieuThue() {
        return soPhieuThue;
    }

    public void setSoPhieuThue(int soPhieuThue) {
        this.soPhieuThue = soPhieuThue;
    }

    public String getSoHieuTruyen() {
        return soHieuTruyen;
    }

    public void setSoHieuTruyen(String soHieuTruyen) {
        this.soHieuTruyen = soHieuTruyen;
    }

    public int getNgayThue() {
        return ngayThue;
    }

    public void setNgayThue(int ngayThue) {
        this.ngayThue = ngayThue;
    }

    public int getHanTra() {
        return hanTra;
    }

    public void setHanTra(int hanTra) {
        this.hanTra = hanTra;
    }

    public double getSoTienThue() {
        return soTienThue;
    }

    public void setSoTienThue(double soTienThue) {
        this.soTienThue = soTienThue;
    }


    // Override input
    @Override
    public void input() {
        super.input();

        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap so phieu thue: ");
        soPhieuThue = sc.nextInt();
        System.out.println("Nhap so hieu truyen: ");
        soHieuTruyen = sc.next();
        /*
        // Kiem tra ngay thue va han tra truyen
        int a = ngayThue;
        int b = hanTra;
        if (b < a) {
            // Ngay thue va han tra khong hop le
            System.out.println("Ngay thue va han tra khong hop le. Vui long nhap lai ");
            System.out.println("Nhap lai ngay thue: ");
            a = sc.nextInt();
            System.out.println("Nhap lai han tra: ");
            b = sc.nextInt();
        }

        System.out.println("Nhap so tien thue: ");
        soTienThue = sc.nextDouble();
    }

         */
        while (true){
            try {
                System.out.println("Nhap ngay thue: ");
                ngayThue = sc.nextInt();
                System.out.println("Nhap han tra: ");
                hanTra = sc.nextInt();
                if(hanTra<ngayThue){
                    throw new IllegalArgumentException("han tra khong duoc nho hon ngay thue!");
                }
            }
            catch (Exception e){
                System.out.println("Gap loi: "+e);
                System.out.println("Nhap lai ngay thue va han tra!");
                System.out.println("Nhap ngay thue: ");
                ngayThue = sc.nextInt();
                System.out.println("Nhap han tra: ");
                hanTra = sc.nextInt();
            }
            break;
            }
        }

        // Override output
        public void output () {
            super.output();

            System.out.println("So phieu thue: " + soTienThue);
            System.out.println("So hieu truyen: " + soHieuTruyen);
            System.out.println("Ngay thue: " + ngayThue);
            System.out.println("Han tra: " + hanTra);
            System.out.println("So tien thue: " + soTienThue);
        }

    }

