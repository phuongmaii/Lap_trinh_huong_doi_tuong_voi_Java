package thuvien;

import java.util.Scanner;

class SinhVien {
    private String hoTen;
    private String namSinh;
    private String lop;


    // Constructor khong tham so
    public SinhVien() {

    }


    // Constructor co tham so
    public SinhVien(String hoTen, String namSinh, String lop) {
        this.hoTen = hoTen;
        this.namSinh = namSinh;
        this.lop = lop;
    }


    // get/set

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public String getNamSinh() {
        return namSinh;
    }

    public void setNamSinh(String namSinh) {
        this.namSinh = namSinh;
    }

    public String getLop() {
        return lop;
    }

    public void setLop(String lop) {
        this.lop = lop;
    }


    // Input
    public void input() {

        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap ho ten: ");
        hoTen = sc.next();
        System.out.println("Nhap nam sinh: ");
        namSinh = sc.next();
        System.out.println("Nhap lop: ");
        lop = sc.next();
    }


    // Output
    public void output() {

        System.out.println("Ho ten: " + hoTen);
        System.out.println("Nam sinh: " + namSinh);
        System.out.println("Lop: " + lop);
    }
}


// Lop the muon ke thua tu lop sinh vien
public class TheMuon extends SinhVien {
    private int soPhieuMuon;
    private String soHieuSach;
    private int ngayThue;
    private int ngayTra;


    // Constructor khong co tham so
    public TheMuon() {

    }


    // Constructor co tham so
    public TheMuon(String hoTen, String namSinh, String lop, int soPhieuMuon, String soHieuSach, int ngayThue, int ngayTra) {
        this.soPhieuMuon = soPhieuMuon;
        this.soHieuSach = soHieuSach;
        this.ngayThue = ngayThue;
        this.ngayTra = ngayTra;
    }


    // get/set

    public int getSoPhieuMuon() {
        return soPhieuMuon;
    }

    public void setSoPhieuMuon(int soPhieuMuon) {
        this.soPhieuMuon = soPhieuMuon;
    }

    public String getSoHieuSach() {
        return soHieuSach;
    }

    public void setSoHieuSach(String soHieuSach) {
        this.soHieuSach = soHieuSach;
    }

    public int getNgayThue() {
        return ngayThue;
    }

    public void setNgayThue(int ngayThue) {
        this.ngayThue = ngayThue;
    }

    public int getNgayTra() {
        return ngayTra;
    }

    public void setNgayTra(int ngayTra) {
        this.ngayTra = ngayTra;
    }


    // Override input
    @Override
    public void input() {
        super.input();

        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap so phieu thue: ");
        soPhieuMuon = sc.nextInt();
        System.out.println("Nhap so hieu sach: ");
        soHieuSach = sc.next();
        System.out.println("Nhap ngay thue: ");
        ngayThue = sc.nextInt();
        System.out.println("Nhap ngay tra: ");
        ngayTra = sc.nextInt();

        // Check xem ngay co hop le khong
        int a = ngayTra;
        int b = ngayThue;
        if (a < b) {
            // Ngay nhap vao khong hop le
            System.out.println("Ngay tra va ngay thue khong hop le. Vui long nhap lai ");
            System.out.println("Ngay tra: ");
            a = sc.nextInt();
            System.out.println("Ngay thue: ");
            b = sc.nextInt();
        }
    }


    // Override output
    @Override
    public void output() {

        System.out.println("So phieu muon: " + soPhieuMuon);
        System.out.println("So hieu sach: " + soHieuSach);
        System.out.println("Ngay thue: " + ngayThue);
        System.out.println("Ngay tra: " + ngayTra);
    }
}

