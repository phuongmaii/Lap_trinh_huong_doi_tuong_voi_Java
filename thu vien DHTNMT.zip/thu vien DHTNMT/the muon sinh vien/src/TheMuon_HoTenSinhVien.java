import thuvien.TheMuon;

import java.util.Scanner;

public class TheMuon_HoTenSinhVien {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // a. Nhap danh sach n the muon, xuat danh sach the muon ra man hinh
        System.out.println("Nhap danh sach the muon: ");
        int n = Integer.parseInt(sc.nextLine());

        // Khai bao mang chua n the muon
        TheMuon[] dsTM = new TheMuon[n];

        // Nhap danh sach the muon
        for (int i = 0; i < n; i++) {
            System.out.println("The muon thu " + (i + 1) + " ");
            //dsTM[i] = new TheMuon("ho ten" + i, 2004 + i, "a" + i, 23 + i, "abc" + i, 23 + i, 25 + i);
            dsTM[i] = new TheMuon();
            dsTM[i].input();
        }
        while (true) {
            System.out.println("----------------------------------------------------------");
            System.out.println("---------------------------MENU---------------------------");
            System.out.println("1. Xuat danh sach the muon ra man hinh");
            System.out.println("2. Dem tong so phieu muon");
            System.out.println("0. Ket thuc chuong trinh");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("----------------------------------------------------------");
                    // In danh sach ra man hinh
                    System.out.println("Danh sach the muon ");
                    for (TheMuon tm : dsTM) {
                        tm.output();
                        System.out.println();
                    }
                    break;
                case 2:
                    System.out.println("----------------------------------------------------------");


                    // c.Dem tong so phieu muon tai thu vien
                    int dem = 0;
                    for (int i = 0; i < n; i++) {
                        dem += dsTM[i].getSoPhieuMuon();
                    }
                    System.out.println("So luong phieu muon: " + dem);
                    break;
                case 0:
                    System.out.println("----------------------------------------------------------");
                    System.out.println("Ket thuc chuong trinh");
                    break;
                default:
                    System.out.println("----------------------------------------------------------");
                    System.out.println("Lua chon khong dung, vui long chon lai");

                    // d. Xay dung lop loi ngay de xu ly ngoai le khi nhap vao han tra nho hon ngay muon

            }
        }
    }
}
