import tiemvang.*;

import java.util.Scanner;

public class QuanLyGiaoDichTiemVang {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // a, Nhap danh sach thong tin giao dich, in ra danh sach
        System.out.println("Nhap danh sach giao dich: ");
        int n = Integer.parseInt(sc.nextLine());

        // Khoi tao mang chua danh sach
        GiaoDichTienTe[] ds_giao_dich = new GiaoDichTienTe[n];

        // Nhap thong tin cho danh sach
        for (int i = 0; i < n; i++) {
            System.out.println("Giao dich thu " + (i + 1) + " ");
            //ds_giao_dich[i] = new GiaoDichTienTe("ac" + i, "12" + i, 23 + i, 15 + i, 12000 + i, "VND" + i);
            ds_giao_dich[i] = new GiaoDichTienTe();
            ds_giao_dich[i].input();
        }
        while (true) {
            System.out.println("------------------------------------------------------------------------");
            System.out.println("----------------------------------MENU----------------------------------");
            System.out.println("1. In danh sach giao dich vua nhap ra man hinh");
            System.out.println("2. Tinh tong tien te cac giao dich");
            System.out.println("0. Ket thuc chuong trinh");
            System.out.println("------------------------------------------------------------------------");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("------------------------------------------------------------------------");

                    // In ra man hinh
                    System.out.println("Danh sach giao dich: ");
                    for (GiaoDichTienTe giao_dich_tien_te : ds_giao_dich) {
                        giao_dich_tien_te.output();
                        System.out.println();
                    }
                    break;
                case 2:
                    ;
                    System.out.println("------------------------------------------------------------------------");


                    // b. Tinh tong tien te cua cac giao dich
                    double tong = 0;
                    for (GiaoDichTienTe giao_dich_tien_te : ds_giao_dich) {
                        if (giao_dich_tien_te instanceof GiaoDichTienTe)
                            tong += ((GiaoDichTienTe) giao_dich_tien_te).doiTien();
                    }
                    System.out.println("Tong tien te cua cac giao dich: " + tong);
                    break;
                case 0:
                    System.out.println("------------------------------------------------------------------------");
                    System.out.println("Ket thuc chuong trinh");
                    break;
                default:
                    System.out.println("------------------------------------------------------------------------");
                    System.out.println("Lua chon khong dung vui long chon lai");
            }
        }
    }
}
// Xam lai cau tinh tong so tien
