package tiemvang;
// DHT

import java.util.Scanner;

class GiaoDich {
    private String maGiaoDich;
    private String ngayGiaoDich;
    public int soLuong;
    public int donGia;


    // Constructor khong tham so
    public GiaoDich() {

    }


    // Constructor co tham so
    public GiaoDich(String maGiaoDich, String ngayGiaoDich, int soLuong, int donGia) {
        this.maGiaoDich = maGiaoDich;
        this.ngayGiaoDich = ngayGiaoDich;
        this.soLuong = soLuong;
        this.donGia = donGia;
    }


    // get/set

    public String getMaGiaoDich() {
        return maGiaoDich;
    }

    public void setMaGiaoDich(String maGiaoDich) {
        this.maGiaoDich = maGiaoDich;
    }

    public String getNgayGiaoDich() {
        return ngayGiaoDich;
    }

    public void setNgayGiaoDich(String ngayGiaoDich) {
        this.ngayGiaoDich = ngayGiaoDich;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public int getDonGia() {
        return donGia;
    }

    public void setDonGia(int donGia) {
        this.donGia = donGia;
    }


    // Input
    public void input() {

        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap ma giao dich: ");
        maGiaoDich = sc.next();
        System.out.println("Nhap ngay giao dich: ");
        ngayGiaoDich = sc.next();
        System.out.println("Nhap don gia");
        donGia = sc.nextInt();

        /*
        // Kiem tra so luong nhap vao
        int a = soLuong;
        if (a < 0 || a == 0) {
            // So luong nhap vao khong hop le
            System.out.println("So luong nhap vao khong hop le: ");
            System.out.println("Nhap lai so luong: ");
            a = sc.nextInt();
        }

         */
        // Kiem tra so luong nhap vao
        while (true) {
            try {
                System.out.println("Nhap so luong: ");
                soLuong = sc.nextInt();
                if (soLuong <= 0) {
                    throw new IllegalArgumentException("So luong khong duoc nho hon bang 0!");
                }
            } catch (Exception e) {
                System.out.println("Gap loi: " + e);
                System.out.println("Nhap lai so luong");
                System.out.println("Nhap so luong: ");
                soLuong = sc.nextInt();
            }
            break;
        }
    }


    // Output
    public void output() {

        System.out.println("Ma giao dich: " + maGiaoDich);
        System.out.println("Ngay giao dich: " + ngayGiaoDich);
        System.out.println("So luong: " + soLuong);
        System.out.println("Don gia: " + donGia);
    }
}


// Lop giao dich tien te ke thua lop giao dich
public class GiaoDichTienTe extends GiaoDich {
    public int tiGia;
    public String loaiTienTe;


    // Constructor khong co tham so
    public GiaoDichTienTe() {

    }


    // Constructor co tham so
    public GiaoDichTienTe(String maGiaoDich, String ngayGiaoDich, int soLuong, int donGia, int tiGia, String loaiTienTe) {
        super(maGiaoDich, ngayGiaoDich, soLuong, donGia);
        this.tiGia = tiGia;
        this.loaiTienTe = loaiTienTe;
    }


    // get/set
    public int getTiGia() {
        return tiGia;
    }

    public void setTiGia(int tiGia) {
        this.tiGia = tiGia;
    }

    public String getLoaiTienTe() {
        return loaiTienTe;
    }

    public void setLoaiTienTe(String loaiTienTe) {
        this.loaiTienTe = loaiTienTe;
    }


    // Override input
    @Override
    public void input() {
        super.input();

        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap ti gia: ");
        tiGia = sc.nextInt();
        System.out.println("Nhap loai tien te: ");
        loaiTienTe = sc.next();


    }


    // Override output
    public void output() {
        super.output();

        System.out.println("Ti gia: " + tiGia);
        System.out.println("Loai tien te: " + loaiTienTe);
    }


    // Doi ti gia tien
    public double doiTien() {
        double thanhTien = 0;
        if (loaiTienTe.equalsIgnoreCase("USD") || loaiTienTe.equalsIgnoreCase("EURO")) {
            return soLuong * donGia * tiGia;
        } else if (loaiTienTe.equalsIgnoreCase("VND")) {
            return soLuong * donGia;
        }
        return doiTien();
        /*
        if (loaiTienTe.equalsIgnoreCase("USD") || loaiTienTe.equalsIgnoreCase("Euro")) {
            thanhTien = soLuong * donGia * tiGia;
        } else if (loaiTienTe.equalsIgnoreCase("VND")) {
            thanhTien = soLuong * donGia;
        }
        return thanhTien;

         */

    }
}
