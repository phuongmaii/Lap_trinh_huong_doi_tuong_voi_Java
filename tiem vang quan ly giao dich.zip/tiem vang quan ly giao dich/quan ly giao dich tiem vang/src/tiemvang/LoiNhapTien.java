package tiemvang;

public class LoiNhapTien {
    public LoiNhapTien() {
        super();
    }
}
