import BaiKT_cau2.*;

import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);


        // Nhap vao danh sach n may tinh
        System.out.println("So luong may tinh: ");
        int n = Integer.parseInt(sc.nextLine());
        // Khoi tao mang chua n may
        MayChu[] dsMT = new MayChu[n];
        // Nhap thong tin cho tung may
        for (int i = 0; i < n; i++) {
            System.out.println("May thu " + (i + 1) + " ");
            dsMT[i] = new MayChu("", "", "", 0, 0, 0, "", "");
            dsMT[i].input();
        }


        while (true) {
            System.out.println("--------------------------------------------------------------------------");
            System.out.println("-----------------------------------MENU-----------------------------------");
            System.out.println("1. In ra danh sach cac may cua hang (Nhap ten hang tu ban phim) da su dung lon hon 5 nam");
            System.out.println("2. Thong ke may theo ten hang va so luong");
            System.out.println("3. Liet ke cac may da kiem ke nam 2023");
            System.out.println("0. Ket thuc chuong trinh");
            System.out.println("--------------------------------------------------------------------------");

            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("--------------------------------------------------------------------------");
                    System.out.println("Danh sach cac may cua hang (Nhap ten hang tu ban phim) da su dung lon hon 5 nam: ");
                    String hangSanXuat = sc.next();
                    for (int i = 0; i < n; i++) {
                        if (dsMT[i].getHangSanXuat().equals(hangSanXuat)) {
                            if (dsMT[i].namDaSuDung() > 5) {
                                dsMT[i].output();
                                System.out.println();
                            } else {
                                System.out.println("Nam su dung chua lon hon 5 nam");
                            }
                            break;
                        }
                    }
                    break;
                case 2:
                    System.out.println("--------------------------------------------------------------------------");
                    System.out.println("Thong ke may theo ten hang va so luong");
                    for (int i = 0; i < n; i++) {
                        System.out.println("Ten hang: " + dsMT[i].getHangSanXuat());
                        System.out.println("So luong: " + dsMT[i].getSoLuong());
                    }
                    break;
                case 3:
                    System.out.println("--------------------------------------------------------------------------");
                    System.out.println("Liet ke may kiem ke nam 2023");

                    for (int i = 0; i < n; i++) {
                        if (dsMT[i].getNamKiemKe() == 2023) {
                            System.out.println("Ma may: " + dsMT[i].getMaMay());
                            System.out.println("Ten may: " + dsMT[i].getTenMay());
                            System.out.println("Hang san xuat: " + dsMT[i].getHangSanXuat());
                        }
                        else {
                            System.out.println("Khong co nam kiem ke 2023");
                        }
                        break;
                    }
                    break;
                case 0:
                    System.out.println("--------------------------------------------------------------------------");
                    System.out.println("Ket thuc chuong trinh");
                    break;
                default:
                    System.out.println("Lua chon khong dung, vui long chon lai");

            }
        }
    }
}
