package BaiKT_cau2;

public class LoiNam extends Exception {
    public LoiNam(){
        super();
    }
}
