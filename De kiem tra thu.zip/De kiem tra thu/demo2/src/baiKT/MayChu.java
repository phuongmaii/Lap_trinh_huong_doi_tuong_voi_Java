package baiKT;

import java.util.Scanner;

class ThietBi {
    private String maMay;
    private String tenMay;
    private String hangSanXuat;
    private int soLuong;
    private int namDuaVaoSuDung;
    private int namKiemKe;

    public ThietBi(String maMay, String tenMay, String hangSanXuat, int soLuong, int namDuaVaoSuDung, int namKiemKe) {
        this.maMay = maMay;
        this.tenMay = tenMay;
        this.hangSanXuat = hangSanXuat;
        this.soLuong = soLuong;
        this.namDuaVaoSuDung = namDuaVaoSuDung;
        this.namKiemKe = namKiemKe;
    }

    public String getMaMay() {
        return maMay;
    }

    public String getTenMay() {
        return tenMay;
    }

    public String getHangSanXuat() {
        return hangSanXuat;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public int getNamDuaVaoSuDung() {
        return namDuaVaoSuDung;
    }

    public int getNamKiemKe() {
        return namKiemKe;
    }

    public void setMaMay(String maMay) {
        this.maMay = maMay;
    }

    public void setTenMay(String tenMay) {
        this.tenMay = tenMay;
    }

    public void setHangSanXuat(String hangSanXuat) {
        this.hangSanXuat = hangSanXuat;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public void setNamDuaVaoSuDung(int namDuaVaoSuDung) {
        this.namDuaVaoSuDung = namDuaVaoSuDung;
    }

    public void setNamKiemKe(int namKiemKe) {
        this.namKiemKe = namKiemKe;
    }

    public void input() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhap ma may: ");
        maMay = sc.next();
        System.out.println("Nhap ten may: ");
        tenMay = sc.next();
        System.out.println("Nhap hang san xuat: ");
        hangSanXuat = sc.next();
        System.out.println("Nhap so luong: ");
        soLuong = sc.nextInt();
        System.out.println("Nhap nam dua vao su dung: ");
        namDuaVaoSuDung = sc.nextInt();
        System.out.println("Nhap nam kiem ke: ");
        namKiemKe = sc.nextInt();
    }

    public void output() {
        System.out.println("Ma may: " + maMay);
        System.out.println("Ten may: " + tenMay);
        System.out.println("Hang san xuat: " + hangSanXuat);
        System.out.println("So luong: " + soLuong);
        System.out.println("Nam dua vao su dung: " + namDuaVaoSuDung);
        System.out.println("Nam kiem ke: " + namKiemKe);
    }
}

public class MayChu extends ThietBi {
    private String loaiMayChu;
    private String chucNang;

    public MayChu(String maMay, String tenMay, String hangSanXuat, int soLuong, int namDuaVaoSuDung, int namKiemKe, String loaiMayChu, String chucNang) {
        super(maMay, tenMay, hangSanXuat, soLuong, namDuaVaoSuDung, namKiemKe);
        this.loaiMayChu = loaiMayChu;
        this.chucNang = chucNang;
    }

    public String getLoaiMayChu() {
        return loaiMayChu;
    }

    public String getChucNang() {
        return chucNang;
    }

    public void setLoaiMayChu(String loaiMayChu) {
        this.loaiMayChu = loaiMayChu;
    }

    public void setChucNang(String chucNang) {
        this.chucNang = chucNang;
    }

    @Override
    public void input() {
        super.input();
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhap loai may chu: ");
        loaiMayChu = sc.next();
        System.out.println("Nhap chuc nang: ");
        chucNang = sc.next();
    }

    @Override
    public void output() {
        super.output();
        System.out.println("Loai may chu: " + loaiMayChu);
        System.out.println("Chuc nang: " + chucNang);
    }
}
