import java.util.Scanner;

import baiKiemTra.*;

public class main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);


        // Nhap vao danh sach n may tinh
        System.out.println("So luong may tinh: ");
        int n = Integer.parseInt(sc.nextLine());
        // Khoi tao mang chua n may
        MayChu[] dsMT = new MayChu[n];
        // Nhap thong tin cho tung may
        for (int i = 0; i < n; i++) {
            System.out.println("May thu " + (i + 1) + " ");
            dsMT[i] = new MayChu("", "", "", 0, 0, 0, "", "");
            dsMT[i].input();
        }

        String hangSanXuat = sc.next();
        for (int i = 0; i < n; i++) {
            if (dsMT[i].getHangSanXuat().equals(hangSanXuat)) {
                if (dsMT[i].namDaSuDung() > 5) {
                    dsMT[i].output();
                    System.out.println();
                } else {
                    System.out.println("Nam su dung chua lon hon 5 nam");
                }
            }
        }
        System.out.println("Thong ke may theo ten hang va so luong");
        for (int i = 0; i < n; i++) {
            System.out.println("Ten hang: " + dsMT[i].getHangSanXuat());
            System.out.println("So luong: " + dsMT[i].getSoLuong());
        }
        System.out.println("Liet ke may kiem ke nam 2023");

        for (int i = 0; i < n; i++) {
            if (dsMT[i].getNamKiemKe() == 2023) {
                System.out.println("Ma may: " + dsMT[i].getMaMay());
                System.out.println("Ten may: " + dsMT[i].getTenMay());
                System.out.println("Hang san xuat: " + dsMT[i].getHangSanXuat());
            } else {
                System.out.println("Khong co nam kiem ke 2023");
            }
        }
    }
}


