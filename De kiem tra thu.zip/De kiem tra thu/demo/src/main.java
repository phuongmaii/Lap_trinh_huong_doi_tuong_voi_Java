package huongdoituong.BTap;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

import huongdoituong.Bai7.SanPhamCaoCap;

public class DanhSach {
    private ArrayList<Nguoi> danhSach;

    public DanhSach(){
        this.danhSach = new ArrayList<Nguoi>();
    }

    public DanhSach(ArrayList<Nguoi> danhSach){
        this.danhSach = danhSach;
    }

    public void themSinhVien(){

        Scanner sc = new Scanner(System.in);
        System.out.println("Nhap vao ho ten: ");
        String mhoTen = sc.nextLine();
        System.out.println("Nhap ngay gioi tinh: ");
        String gioiTinh = sc.nextLine();
        System.out.println("Nhap vao ngay thang nam sinh: ");
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String ngay = sc.nextLine();
        LocalDate date = LocalDate.parse(ngay, formatter);
        System.out.println("Nhap vao ma sinh vien: ");
        String msv = sc.nextLine();
        System.out.println("Nhap vao lop: ");
        String lop = sc.nextLine();
        double dtb;

        do{
            System.out.println("Nhap vao diem trung binh: ");
            dtb = sc.nextDouble();
            if ( dtb < 0 || dtb > 10 ){
                System.out.println("Diem trung binh phai thuoc khoang 0 - 10");
            }
        }while(dtb < 0 || dtb > 10 );

        Nguoi n = new SinhVien(mhoTen, gioiTinh, date, msv, lop, dtb);
        danhSach.add(n);
    }

    public void inDanhSach(){
        System.out.println("╔═════╦══════════╦═══════════╦═══════════════════════════════╦══════════════════════╗");
        System.out.printf("║%-5s║%-10s║%-11s║%-15s║%-15s║%-9s║%-12s║\n", "STT", "Ho Ten", "Gioi Tinh", "Ngay Sinh", "Ma Sinh Vien", "Lop", "Diem TB");
        System.out.println("╠═════╬══════════╬═══════════╬═══════════════╬═══════════════╬═════════╬════════════╣");

        for (int i = 0; i < danhSach.size(); i++) {
            Nguoi sv = danhSach.get(i);
            System.out.printf("║%-5s║%-10s║%-11s║%-15s║%-15s║%-9s║%-12s║\n", i + 1, sv.getHoTen(), sv.getGioiTinh(), sv.getDate(), ((SinhVien)sv).getMsv(), ((SinhVien)sv).getLop(), ((SinhVien)sv).getDtb());
        }
        System.out.println("╚═════╩══════════╩═══════════╩═══════════════╩═══════════════╩═════════╩════════════╝");
        System.out.println();
    }

    public void inDiemLopNhapTuBanPhim(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhap ten lop: ");
        String lop = sc.nextLine();
        for (Nguoi sv : danhSach) {
            if (((SinhVien)sv).getLop().equals(lop)){
                System.out.println("╔═════╦══════════╦═══════════╦═══════════════════════════════╦══════════════════════╗");
                System.out.printf("║%-5s║%-10s║%-11s║%-15s║%-15s║%-9s║%-12s║\n", "STT", "Ho Ten", "Gioi Tinh", "Ngay Sinh", "Ma Sinh Vien", "Lop", "Diem TB");
                System.out.println("╠═════╬══════════╬═══════════╬═══════════════╬═══════════════╬═════════╬════════════╣");
                System.out.printf("║%-5s║%-10s║%-11s║%-15s║%-15s║%-9s║%-12s║\n",1, sv.getHoTen(), sv.getGioiTinh(), sv.getDate(), ((SinhVien)sv).getMsv(), ((SinhVien)sv).getLop(), ((SinhVien)sv).getDtb());
                System.out.println("╚═════╩══════════╩═══════════╩═══════════════╩═══════════════╩═════════╩════════════╝");

            }

        }
    }

    public void sapXepDanhSachGiamDan(){
        System.out.println("-----Danh sach sap xep giam dan theo diem trung binh -----");
        ArrayList<Nguoi> sortedList = new ArrayList<>(this.danhSach);
        Collections.sort(sortedList, new Comparator<Nguoi>() {
            @Override
            public int compare(Nguoi sv1, Nguoi sv2){
                if ( ((SinhVien)sv1).getDtb() > ((SinhVien)sv2).getDtb() ) {
                    return -1;
                } else if ( ((SinhVien)sv1).getDtb() < ((SinhVien)sv2).getDtb()) {
                    return 1;
                } else {
                    return 0;
                }
            }
        });
        this.danhSach = sortedList;
    }

    public void inDanhSachHocbong(){
        System.out.println("Danh sach hoc bong: ");
        for (Nguoi sv : danhSach) {
            if ( ((SinhVien)sv).getDtb() > 7){
                System.out.println("╔═════╦══════════╦═══════════╦═══════════════════════════════╦══════════════════════╗");
                System.out.printf("║%-5s║%-10s║%-11s║%-15s║%-15s║%-9s║%-12s║\n", "STT", "Ho Ten", "Gioi Tinh", "Ngay Sinh", "Ma Sinh Vien", "Lop", "Diem TB");
                System.out.println("╠═════╬══════════╬═══════════╬═══════════════╬═══════════════╬═════════╬════════════╣");
                System.out.printf("║%-5s║%-10s║%-11s║%-15s║%-15s║%-9s║%-12s║\n",1, sv.getHoTen(), sv.getGioiTinh(), sv.getDate(), ((SinhVien)sv).getMsv(), ((SinhVien)sv).getLop(), ((SinhVien)sv).getDtb());
                System.out.println("╚═════╩══════════╩═══════════╩═══════════════╩═══════════════╩═════════╩════════════╝");

            }
        }
    }
}

