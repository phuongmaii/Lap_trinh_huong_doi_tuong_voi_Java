import java.util.Scanner;
public class main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // Khai bao so nguyen
        System.out.println("nhap so nguyen n: ");
        int n = sc.nextInt();

        // Dieu kien tim so nguyen
        if(n >0 && n<=10000){
            if(n % 1 == 0 && )
        }

    }
}
